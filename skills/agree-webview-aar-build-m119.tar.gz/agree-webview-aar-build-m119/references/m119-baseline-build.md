# M119 基线构建（patches/ 六个 patch + 单 out 双 ABI）

M119 移植版（面向 119.0.6045.214、Android 7 API 24）与 M132 流程的差异都在这份文件；通用流程（sync、assets、资源 AAR）仍按 SKILL.md 主体。

## patch 集与预期结果

- `patches/001.java_port.patch`：64 个 Java 文件（包名替换 android.webkit.*→agree.webkit.*、WebViewDelegate 抽象、API 26 兼容：VERSION_CODES 常量→整数字面量、CompatChanges 降级 targetsAtLeastT、WebViewApi26/28/Q 隔离类）
- `patches/002.build_gn.patch`：android_webview/BUILD.gn + glue/BUILD.gn + support_library/BUILD.gn + build/android/gyp/dist_aar.py + build/config/android/rules.gni（--abi-mapping 双 ABI 支持）
- `patches/003.boundary_interfaces.BUILD.gn.patch`：boundary_interface_java 补 webkit_glue_java dep（javac 阶段暴露，见下）
- `patches/004.callback_java.BUILD.gn.patch`：callback_java 补 webkit_glue_java dep（同上，001 改了 SupportLibWebViewContentsClientAdapter 的 import）
- `patches/005.webview_delegate_wrapper_import.patch`：WebViewChromiumFactoryProvider.java 补 `import android.webkit.WebViewDelegateWrapper;`（001 漏了 import）
- `patches/006.glue_javac.patch`：glue 的 javac 阶段修复（setTextClassifier 形参改 Object、去掉 autofill/onProvideAutofillVirtualStructure 的 @Override、ApiHelperForM.onPageCommitVisible 改直接调用）
- 原三份 M130 patch 已删（git show 67e5096 可取回）；patches/README.md 是移植说明
- 应用后 `git status --short | wc -l` = **71**（64 Java + 5 GN + dist_aar.py + rules.gni）
- **验收分两层：gn gen（构建图）+ javac（Java 编译）**：移植作者只验证了 git apply --check / gn format / javac 静态扫描（手动编全部文件），gn gen 的 7 个阻断与 javac 的 4 类问题都没暴露

## 目录布局（两处拷贝，缺一 gn gen 报缺文件）

1. 仓库整体拷到 `src/android_webview/agree/`（BUILD.gn、java/、AndroidManifest.xml、proguard.flags）——draw_functor.cc 的 include 写死 `"android_webview/agree/java/src/draw_fn/xxx.h"`，jni 头 include 写死 `"android_webview/agree/draw_fn_impl_jni_headers/MyDrawFunctor_jni.h"`
2. 仓库 `java/res_webkit/` 并入 `android_webview/java/`——002 patch 的 `webkit_glue_resources` sources 是 `"java/res_webkit/..."`（相对 android_webview/）
- 不要整目录覆盖合并 java/：仓库 `java/src/org/chromium/android_webview/ProductConfig.java` 会与树内生成逻辑冲突（M119 树该目录没有它）

## gn gen 阻断与修复（M119 独有）

1. **skia 依赖用 `//skia`，不用 `//third_party/skia`**：M119 的 skia 集成在根目录 `//skia`（只 import shared_sources.gni）；`//third_party/skia` 的 BUILD.gn import 的 `gn/skia.gni` 在 declare_args 里无条件引用整棵树从未定义的 `is_wasm` → Undefined identifier。**别在 BUILDCONFIG.gn 定义 is_wasm=false**：`tools/binary_size/BUILD.gn` 的 `if (defined(is_wasm))` 会激活 wasm 分支，加载不存在的 `//build/toolchain/wasm/BUILD.gn`，这棵树刻意不定义它。正解 = 换 dep 标签
2. **`//android_webview:webkit_glue_java` 引用不解析**：M119 patch 的 glue/support_library deps 沿用了 M130 时代的 label，但移植时 target 已移进 `agree/BUILD.gn`。改为 `//android_webview/agree:webkit_glue_java`。**group() 转发不行**：java 模板要求目标自身生成 `__header`/`__compile_java`/`__validate` 等伴随 target，只有 android_library/java_library 才生成
3. **abi_mapping 用 scope 列表**：GN 2121 的 foreach 只支持列表（scope 报 "This is not a list. Instead I see a scope"），变量下标非法（"May only subscript identifiers"）。写法：`abi_mapping = [ { lib = _arm64_lib, abi = "arm64-v8a" }, { lib = _arm_lib, abi = "armeabi-v7a" } ]`；rules.gni 消费侧 `foreach(_e, invoker.abi_mapping) { rebase_path(_e.lib, root_build_dir) + "=" + _e.abi }`；dist_aar.py 的 "--abi-mapping"（GN list of "path=abi"）解析不用动
4. **删 `//components/sensitive_content`**（M130+ 才有，从新版 BUILD.gn 照抄的依赖，M119 目录不存在）
5. **`jni_zero_java` 换 M119 三件套**：`//third_party/jni_zero:jni_zero_java` 是 M126+ 的 target（M119 的 jni_zero/BUILD.gn 只有 test_mocker_java 与 native_library_loaded_status_java）。M119 的 `@JNINamespace`/`@NativeMethods` 在 **独立的 `//base:jni_java`**（不在 base_java 里）；生成代码 `MyDrawFunctorJni.java` 还引用 `org.jni_zero.JniStaticTestMocker`（`//third_party/jni_zero:test_mocker_java`）与 `org.chromium.build.annotations.CheckDiscard`（`//build/android:build_java`）
6. **删 `android_sdk_version = "35"`**：M119 的 dist_aar 模板不消费该变量 → "Assignment had no effect"；模板不转发的变量直接删，别改成 34（树的 SDK 也只有 android-34）
7. **删空 `srcjars = []`**：同样报 Assignment had no effect

## javac 阻断与修复（gn gen 通过后暴露）

1. **patch 改了 import 却没给 target 加 dep**：001 把 `ProfileBoundaryInterface` 的 import 改成 `agree.webkit.*`（CookieManager/WebStorage/WebResourceResponse/ServiceWorkerController/GeolocationPermissions），但 `boundary_interface_java` 的 deps 没加 webkit_glue_java → symbol not found。修复做成独立 patch 003；对 Chromium 树文件的修复一律 `git diff <单文件> > patches/00X.patch`（下次重放才生效）
2. **BUILD.gn sources 漏文件**：`WebViewApi26/28/Q` 被 WebView.java 4 处调用但没进 `webkit_glue_java` sources → 作者"手动 javac 全量编译"掩盖了 GN sources 缺漏。判别文件是否被引用：grep 类名调用点**不要**用 `grep -v` 排除含类名的行（把调用行一起过滤掉会误判成孤儿）
3. **text block 语法**：从新版 AOSP 拷贝的 `URLUtil.java` 用 Java 15 text block，M119 javac `-source 11` 不支持。修复 = Python 模拟 text block 语义（剥公共缩进 + 转义解码）生成普通字符串拼接，别手抄
4. **jni_java 依赖**（见 gn gen 阻断 5）：MyDrawFunctor.java 同时在 draw_fn_impl_java 与 webkit_glue_java 两个 target 编译，两处 deps 都要补

## 单 out 双 ABI（区别于 M132 双 out + merge_aars.py）

- 一个 out（target_cpu="arm64"）即可：`enable_agree_arm`（默认 true）+ abi_mapping 一次产出双 ABI AAR；M119 的 `android_secondary_abi_toolchain` 对 arm64 无条件定义（abi.gni:96-108），无 is_official_build 门控
- 构建前验证双 ABI 在图里：`ninja -C out/X -t targets all | grep libwebviewchromium` 应同时看到根目录 `libwebviewchromium.so: solink` 和 `android_clang_arm/libwebviewchromium.so: android_clang_arm_solink`
- 启动：systemd-run（`--property=Environment=PATH=...`，unit 不继承 PATH）

## M119 环境事实

- `default_min_sdk_version = 24`（config.gni:70，Android 7 原生默认，无需改 gn 参数）
- 官方构建默认 `android_static_analysis = "off"`（config.gni:84，args 里不用设；SKILL.md 里"不要设 off"是 M132 语境）
- SDK 平台只有 android-34，build-tools 34.0.0（compile_resources.py 的 aapt2 路径与 include-resources 用 34，不是 35）
- NDK 是精简版（~913MB，bin/ 只有 lldb）——M119 正常形态，完整性看 sysroot/usr/include
- **Python 必须 3.8-3.11**：M119 脚本用 `imp`（3.12 移除），系统 3.14 在 safe_browsing allowlist 生成处报 ModuleNotFoundError。`uv python install 3.11`（depot_tools 自带 uv）+ symlink /usr/local/bin/python3，systemd-run 单元 PATH 含 /usr/local/bin 即生效

## 验证手法

- 树是否等于上游 release：gitiles `?format=TEXT` + base64 -d 对比（chromium.googlesource.com `/+/refs/tags/119.0.6045.214/...`，skia 走 skia.googlesource.com 按 DEPS 里 skia_revision）。树与 tag 完全一致 = patch 应用前的干净基线
- patch 应用后先用 `git stash` 跑一次无 patch 的 gn gen 作对照，能区分「树本身的问题」与「移植引入的问题」（M119 干净树 gn gen 直接通过，is_wasm 报错是移植的 skia dep 引入的）
