# 支持 Android 版本下限（minSdk）与 iOS 对照

当用户报"产物不支持低于 Android X 的设备"时，先定位限制在哪一层，再决定改哪一层。**不要一上来就重新编译内核**——AAR 里没有 minSdk，重编数小时很可能不解决问题。

## Chromium 版本号怎么读（选基线的前提）

Chromium 版本号是 4 段 `MAJOR.MINOR.BUILD.PATCH`（M119 基线 = `119.0.6045.214`）：

| 段 | 值 | 含义 |
|---|---|---|
| MAJOR | 119 | 主版本（milestone），即"M119"；与 Chrome 稳定版同步，每 ~4 周递增 |
| MINOR | 0 | Chromium 恒为 0（Chrome 用它做小版本，Chromium 不用） |
| BUILD | 6045 | 分支点：从 trunk 的哪个位置切出；随 trunk 推进单调递增，同一 milestone 内不变 |
| PATCH | 214 | 该分支内的发布序号，单调递增 |

- **BUILD+PATCH 唯一确定一份代码**（官方："The BUILD and PATCH numbers together are the canonical representation of what code is in a given release"）；`6045.214` 是最短无歧义构建名。
- **BUILD 号越大代码越新**（trunk 单调推进），build 180 一定比 build 177 新。
- 选基线时：**MAJOR 决定功能/API 水平**（M119 vs M130 差别巨大），PATCH 只差安全补丁；同 BUILD 内 PATCH 越大越新。

用户若指出"问题是 AOSP 导入的那批 Java 代码"，先把两批**不同的** Java 代码分清，它们的可行性与修法完全不同：

| | 内容 | 位置 | 对低版本的影响 |
|---|---|---|---|
| ① agree 自研 API 层 | AOSP `android/webkit/*` 复制改包名的全套 API | `java/src/org/chromium/android_agree/webkit/`（agree 仓库自带） | 基本无。实测运行代码里 `Build.VERSION.SDK_INT` 出现 0 次（只有 javadoc 提 VERSION_CODES），也不引用 NotificationChannel / java.time / java.nio.file 等 API 26+ 类型 |
| ② Chromium glue 层 | `com.android.webview.chromium.*`，官方 support library 机制 | `android_webview/glue/`，被 002 patch 改 45 个文件 | **是隐藏 API 接触面**：glue 走 AOSP 私有 SDK，见下文第三层 |

① 是从早期 AOSP 复制的、没有版本门控的兼容代码；② 才是逐版本分家的隐藏 API 层。用户说的"AOSP 导入的 Java"可能指任一批，别默认是哪一批。

## 限制来源：四层，只有第三层能靠 gn 参数解决

| 层 | 机制 | 怎么改 |
|---|---|---|
| **App 的 build.gradle** | 宿主 App 的 `minSdkVersion` 决定安装下限，AAR 不参与 | 把 App minSdk 调到目标值；内核若无高 API 符号即可装 |
| **AAR 的 AndroidManifest** | `dist_aar` 产出的 manifest 通常**不声明** minSdk（agree 的 manifest 只有 package + 权限 + sandboxed service），所以 AAR 不携带限制 | 无需改；限制只可能来自 App |
| **Java glue 层的隐藏 API** | `glue_java` 用 `alternative_android_sdk_dep = "//third_party/android_sdk:public_framework_system_java"`，编译期解析的是 `third_party/android_system_sdk/cipd/android_system.jar`（AOSP 私有 SDK，含 @SystemApi/@hide），不是公开 android.jar | **编译期正常、运行期才炸**：低版本上隐藏 API 不存在或签名不同 → `NoSuchMethodError` / `NoSuchFieldError` / `AbstractMethodError` / `VerifyError`。见下方"隐藏 API 层"一节 |
| **内核 NDK API level** | `build/config/android/config.gni` 的 `default_min_sdk_version` 同时驱动 `min_supported_sdk_version` 下限与 `android32/64_ndk_api_level`（NDK 头文件、链接符号下限） | 只能改 gn 参数，见下 |

关键源码事实（以 M132 为例，换大版本时重新 grep 确认）：

- `build/config/android/config.gni`：`min_supported_sdk_version = 21`；`default_min_sdk_version = 26`。即**默认值 26 但可下调，编译下限是 21**。
- `build/config/android/rules.gni`：`_MIN_SDK_VERSION` 宏由 `default_min_sdk_version` 注入，**全树可见**；改它 = blast radius 是整棵树。
- `android_webview/BUILD.gn`：`min_sdk_version = default_min_sdk_version`（跟默认走，无需单独覆盖）。
- agree 的 `dist_aar("webview_aar")` 里 `android_sdk_version = 35` 是 **compileSdk**，与 minSdk 无关，不要动它。
- `android_webview/glue/BUILD.gn` 的 `glue_java` 里 `alternative_android_sdk_dep` 指向 `public_framework_system_java`；**agree 的 001/002/003 三个 patch 都不碰这个依赖**，所以编出来的 glue 字节码仍然引用 AOSP 隐藏 API。glue 层是唯一"编译期静默、运行期才暴露"的限制层，`git apply --check` 全绿不代表它兼容低版本。

## 排查顺序（Step 0，不编译，先做）

```bash
# 1) App 的真实 minSdk / targetSdk / 已打包 ABI
aapt2 dump badging your-app.apk | grep -E 'sdkVersion|targetSdkVersion|native-code'
# 2) 内核 .so 需要的最低 API（.note.android.ident 段）
readelf -n out/<dir>/libwebviewchromium.so | grep -A2 'Android'
```

- App 报 `sdkVersion:26` → **限制在 App 层**，先只改 App 验证，不用重编内核。
- `readelf` 显示 `Android ABI: 26` → 内核 NDK api level，走 gn 参数方案。

## 方案 A：gn 参数下调 NDK api level（同一份源码）

```bash
gn gen out/AarRelease --args='target_os="android" target_cpu="arm64" is_official_build=true chrome_pgo_phase=0 use_gio=false default_min_sdk_version=24'
```

- 必加的就是 `default_min_sdk_version=24`（Android 7.0）；`android_static_analysis="off"` 在 official 构建下本就是默认（`config.gni: if (is_official_build) android_static_analysis = "off"`），可省。
- **`android32/64_ndk_api_level` 没有独立开关，它们就是 `= default_min_sdk_version` 的别名**（`config.gni:198/201`），只在两处例外覆盖：`default_min_sdk_version < 21` 时 64 位被抬到 21、`riscv64` 被抬到 35。所以**先 grep 基线自身的默认值再决定是否传参**——M119 的 `default_min_sdk_version` 已经是 24（`min_supported_sdk_version = 21`），传 `default_min_sdk_version=24` 是空操作，不需要改任何 `.gni`，也不需要动 args。只有 M128/M132/M138（默认 26）这类才需要显式下调。
- **已有预编译 `.so` 的 `.note.android.ident` 是 26 而基线默认是 24 时，说明上次构建的 `args.gn` 里显式覆盖过**，不是源码默认如此：去 `out/<dir>/args.gn` grep `ndk_api_level` / `min_sdk` 删掉覆盖，再 `gn clean` 重编即可，别去改 `config.gni`。
- 改后必须做 blast-radius 检查：`ninja -C out/<dir> -n webview_aar | tail -3` 的 edge 数就是失效规模；再扫未定义符号确认没用 24+ 才有的 API：`nm -D --undefined-only libwebviewchromium.so | head`。
- **只改 min_sdk 参数时要 `gn clean`（或删 out 目录），增量缓存不会因配置变化自动失效**：`libapp.so` 式的陈旧产物复用会让新 .so 仍然打着旧的 API level 烙印，症状是「改了参数、读了配置都对、`readelf` 还是旧值」。重编后第一件事就是 `readelf -x .note.android.ident` 复核。

## 方案 B：降 Chromium 基线（仅当方案 A 验证失败）

若 `readelf`/实测表明内核用了 24+ 符号（libc++、`pthread_getname_np`、`std::filesystem` 之类）或 libc++ 在低 API 上跑不起来，gn 参数救不了，只能降基线：

- **M119 是官方最后一个完整支持 Android 7 的 WebView 大版本**（Chrome/WebView 支持窗口）。各版本 `default_min_sdk_version` 实测（`curl "https://chromium.googlesource.com/chromium/src/+/refs/tags/<版本>/build/config/android/config.gni?format=TEXT" | base64 -d | grep -A1 default_min_sdk_version`）：

  | 版本 | default_min_sdk_version | 对应系统 |
  |---|---|---|
  | **M119** | **24** | Android 7.0 ✅ 最后一个支持 Android 7 的版本 |
  | M120 | 26 | Android 8.0（**M120 起放弃 Android 7**） |
  | M124 / M128 / M129 | 26 | Android 8.0 |
  | M130 / M132 / M133 | 26 | Android 8.0 |
  | M140 | 29 | Android 10 |
  | master | 29（Chrome）/ **24**（`is_cronet_build`） | — |

  所以"用更高版本兼容 Android 7"默认不可行——M120+ 官方门槛已是 26。真要下探只能反向移植（改 `default_min_sdk_version` + 补 bionic 缺失符号 shim + Java 层 `SDK_INT` 门控），U4/X5 走的就是这条路（U4 用 Chromium 100 基线支持 API 19+，自研 glue 层 + 动态下发内核），代价是一个内核团队数年的持续投入。
- **换基线不是"降 minSdk 参数"**：同一大版本里改 `default_min_sdk_version` 只是改 NDK 链接下限，M132 的默认值 26 已经覆盖 Android 8；要真正下探到 Android 7 或绕开新版本的 native 路径，只能换大版本。
- **目标 API 的 minSdk 事实必须逐版本 grep 核实，不能凭记忆**：各版本的 `default_min_sdk_version` 不同（M119=24、M128/M132/M138=26），且随版本演进会变。核实方法：

  ```bash
  curl -sS "https://chromium.googlesource.com/chromium/src/+/refs/tags/<版本>/build/config/android/config.gni?format=TEXT" | base64 -d | grep -n default_min_sdk_version
  ```

- 换基线的代价：外部 patchset（如 agree 2.0.0 针对 132）大概率 `git apply --check` 大面积失败，java 垫片层要按官方 API 变化手工移植，按周计。
- **移植前的可行性核查清单**（先查这几项，任一不符就重估）：
  1. patch 依赖的目标文件在目标版本是否存在（如 `android_webview/support_library/` 是否还有）——`curl` gitiles 单文件查存在性，比拉全树快。
  2. 依赖的 GN 机制是否已引入（如 agree 的 BUILD.gn 依赖 `third_party/jni_zero`；该目录在 M119 已存在，但更早版本可能还是 `build/android/jni_generator`）。
  3. glue 接口面差异：对比目标版本与 patch 版本 `android_webview/glue/java/...` 的文件数与关键类（如 `Profile`、`SafeBrowsingResponseAdapter`），差异越大移植越重。
  4. patch 中已被作者注释掉的代码块（如 `DrawGLFunctor` 里的 `setChromiumAwDrawGLFunction` 被注释）是作者已知踩过的坑，移植时优先看这些位置。
- **先验证 host 能否编目标平台，再拉源码/移植**：`docs/android_build_instructions.md` 的 System requirements 明文写着 `Building the Android client on Windows or Mac is not supported and doesn't work.`。macOS host 的失败点在**依赖拉取阶段**（`gclient sync` 拉 `third_party/android_toolchain/ndk` 这个 CIPD 包时，解压 `toolchains/llvm/prebuilt/linux-x86_64/...` 报 `lstat ... no such file or directory` → `SYNC_EXIT=1`），而不是 `gn gen`。**先 curl 那一行 grep `not supported`（30 秒），再决定要不要拉 27GB 源码**——过不了就改租 Linux 云主机（官方支持路径，成功概率高得多），不要在 macOS 上无限投入。已拉下的源码树 `tar` 打包传过去，git 对象和 `.gclient` 均可复用，不浪费。

### 换基线的工作量统计与方案评估

**工作量用 patch 文件实测统计，不要凭感觉**：

```bash
cd <agree 仓库>/patches
python3 -c "
import re, os
for f in sorted(os.listdir('.')):
    t = open(f).read()
    files = re.findall(r'^diff --git a/\\S+ b/(\\S+)', t, re.M)
    hunks = len(re.findall(r'^@@ ', t, re.M))
    print(f'{f}: {len(set(files))} 文件, {hunks} hunk')
"
```

agree 2.0.0 实测：001 support_library = 21 文件 / 21 hunk；002 glue = 45 文件 / 75 hunk；003 BUILD.gn = 1 文件 / 9 hunk。共 67 文件 / 105 hunk / +667 -301 行。绝大部分是 `com.android.webview.chromium.*` → `agree.webkit.*` 的 import 机械替换，不是逻辑改写——移植时按"上下文不匹配 → `--reject` 手工重做；目标版本新增 API → 删 hunk；目标版本缺少 API → 手工补"三类处理。

**阶段化工期与失败概率**（给用户决策用）：

| 阶段 | 工期 | 失败概率 |
|---|---|---|
| 环境（depot_tools + 源码） | 0.5 天 | 低（host 若是 macOS 会在这里失败，见方案 B 的 host 关卡） |
| **host 能否编目标平台** | 0.5 小时（查官方文档一行）/1 天（实际跑 sync 验证） | **高（60%）** |
| 移植 patch | 2-3 天 | 中 |
| 编译调试 | 1-3 天 | 中高 |
| 打包 + 验证 | 1.5 天 | 高（可能编出来还是崩） |
| **合计** | **6-9 天** | **整体 ≈ 25-35%** |

**替代路径对比**（用户不一定知道有更快的路）：

| 方案 | 工期 | 成本 | 成功概率 |
|---|---|---|---|
| M119 + 移植（macOS 主机） | 不可行 | — | **0**（官方不支持，依赖拉取即失败） |
| M132/M119 + 移植（Linux 云主机） | 4-6 天 | 低 | 70-80% |
| 问 patchset 作者要低版本 AAR | 1-2 天 | 0 | 取决于作者 |
| 现有 AAR + `default_min_sdk_version=24` 重编（Linux） | 4-5 天 | 低 | 待实测 |

**推荐顺序**：先查官方文档确认 host 可行（30 秒），再把源码树/bug 拉取并行推进。重编同一版本（M132）的确定收益只有"拿到带符号的 .so 可调试 native CHECK"；但若只需 `default_min_sdk_version=24`，改一行 gn 参数就够，不必换大版本。

## 方案 C：只放宽 App（最省）

若 Step 0 定位到 App 层，直接改 App `minSdkVersion` 到 24 并装机验证即可，零编译成本。**优先验证这条**。

## 方案 D：glue 层隐藏 API 降级（仅当日志指向 Java 层）

先拿日志定性，别凭猜测改 Java：`NoSuchMethodError` / `NoSuchFieldError` / `AbstractMethodError` 的栈顶在 `com.android.webview.chromium.*` → 走本方案；栈在 native → 走方案 A；装不上（`INSTALL_FAILED_OLDER_SDK`）→ 走方案 C。

**没有构建机也能做全量扫描**：不需要 ninja/gn，用本机 `javac` + 目标 API 级别的 `android.jar` 当 classpath 直接编 agree 的 java 源码，编译器会把所有超出该 API 的调用一次性报出来。这比逐个 grep 可靠，比改 BUILD.gn 重编快几个数量级。有构建树时等效做法是把 `glue_java` 的 `alternative_android_sdk_dep` 换回公开 `android.jar` 再 ninja，同样是一次性全量扫描。

### D1. 全量扫描（javac + 目标 API android.jar）

```bash
javac --release 17 -cp "<目标API_android.jar>:<deps...>" -d /tmp/out $(find <agree java src> -name '*.java') 2>&1 | grep -v "R.java"
```

- `--release` 必须 ≥15（源码用了文本块 `"""`）；用 `--release 8/11` 会因文本块报错——那是语言级别问题，不是 API 问题，别被误导。
- R 类由 AGP 生成、源码树里没有 → `cannot find symbol R` 是噪声，用桩 R 类或 grep 过滤。
- **不要把 `agree/java/` 与 chromium 的 `base/android/java/src/` 一起联合编译来做 API 判定**：两者包名空间对不上（agree 用的是改名后的 `agree.webkit.*`，而 `base` 里是原 `org.chromium.base.*`），联合编译会产出上百条与 API 兼容无关的内部依赖错误（`org.chromium.android_webview.common`、`components.embedder_support`、`content_public.browser` 全找不到），真正的 API 问题被完全淹没。**判 API 只看目标文件自己的报错**：按文件名把 javac 输出分组，再筛掉 `程序包 org.chromium…不存在`/`找不到符号` 这类跨包依赖噪声——剩下的才是目标 API 真缺的东西。想彻底消噪就给 `org.chromium.base.*` 单独准备 jar（原 AAR 的 classes.jar 里就有），而不是把源码树整个拉进来。
- **必须看 javac 退出码和生成的 `.class` 数量**：javac 中文区域会输出 `错误:`（不是 `error:`），只 grep `error:` 会得到 "0 错误" 的假象；输出目录里 `find -name '*.class' | wc -l` 为 0 就是根本没编成功。
- **`-source 8` 会因源码里的文本块 `"""` 直接报「不支持文本块」而整体失败**，第一条错误就把真正的 API 问题挡住。`-source 17 -target 17` 配 `-cp <目标api>android.jar` 是能跑的组合；但 **`-bootclasspath` 与 `-target 17` 互斥**（`目标 17 不允许选项 --boot-class-path`），要指定目标 API 就用 `-cp` 而不是 `-bootclasspath`——`-cp` 下 `android.*` 照样从该 jar 解析，效果满足符号判定。
- **要证明「Java 层对目标 API 干净」，别去数总错误数，而是按错误来源分类后看 `android.*` 那一格是否为 0**。合理预期是错误很多且全部来自构建期依赖（缺 androidx、缺生成的 R 类、缺 `org.chromium.base`/JNI 桩、`@Nullable`/`@NonNull`），这些由 GN 构建保证，不是 API 兼容问题。一条命令拿到这个结论：把 javac 输出按 `错误:` 分行，取每条的上下文 3~4 行，正则 `android\.[a-z]` 命中且不含 `androidx` 的才算真问题。实测 agree 60 个文件在 API 24 下该计数为 **0**，可直接回「Java 层无 API 24 阻塞」；反过来若这格非 0，那几条就是要改的完整清单。
- **缺依赖会掩盖真实 API 错误**：agree 的 `java/` 单独编时会因 `org.chromium.base.*`、`org.jni_zero.*`、R 类全部找不到而失败，报错量以"找不到符号"为主，真正的高 API 调用被淹在里面。先造齐桩（`org.chromium.base.Callback/ThreadUtils`、`org.jni_zero.JNINamespace/NativeMethods/CalledByNative`、从源码 `grep -o 'R\.\w*\.\w*'` 反推出的桩 R 类）再扫，否则结论不可信。
- 桩的签名要跟真实调用一致（如 `MyDrawFunctorJni.draw(...)` 返回 `int[]` 而非 void），桩写错会制造假错误，耗费一轮排查。
- 报错清单 = 所有超出目标 API 的调用，**这就是要改的完整列表**。实测 agree `java/` 57 个文件在 API 24 下只有 **45 处错误、集中在 4 个文件**（WebView 27 / WebViewProvider 15 / WebViewDelegateWrapper 2 / MyDrawFunctor 1 桩问题）——93% 的文件已兼容，**不需要从 AOSP 重导，也不需要先换基线就能算出完整改造面**。这个扫描应该在任何编译尝试之前做，几秒钟就会给出答案。

### D2. 分层编译（关键——只编一版会漏）

- **用高 API（如 35）编出全部类** → 拿到完整 class 文件用于打包
- **用目标 API（如 26）再编一次做检查** → 只有这一版能暴露低版本运行时会炸的调用

**最危险的是 `super.xxx(...)`**：用 API 31+ 编译时父类有该方法、编译通过；API 26 上父类没有 → `NoSuchMethodError`。字节码里是 `invokespecial <父类>.<方法>`，**高 API 编译永远发现不了**，必须用低 API 的 android.jar 检查或反编译字节码确认调用目标。

### D3. 隔离类 + SDK_INT 门控（处理 API 26+/29+ 的方法）

对低版本走不到的方法不要删，抽到隔离类：

```java
// 主类：只做版本判断，不出现高 API 调用
// 用字面量，不要用 VERSION_CODES.O / .Q
if (Build.VERSION.SDK_INT >= 26) {   // Build.VERSION_CODES.O
    WebViewApiO.setupAutofillDefaults(this);
}
if (Build.VERSION.SDK_INT >= 29) {   // Build.VERSION_CODES.Q
    WebViewApiQ.setupContentCaptureDefaults(this);
}
```

```java
// 隔离类：整个类只在 API 29+ 被加载，内部可直接用高 API
@TargetApi(Build.VERSION_CODES.Q)
final class WebViewApiQ {
    static void setupContentCaptureDefaults(WebView webView) {
        if (webView.getImportantForContentCapture() == View.IMPORTANT_FOR_CONTENT_CAPTURE_AUTO) {
            webView.setImportantForContentCapture(View.IMPORTANT_FOR_CONTENT_CAPTURE_YES);
        }
    }
}
```

隔离类**自己**用高 API 编译会报错——这是预期的，别试图让它"编译通过"；它的加载由主类的 `SDK_INT` 门控保证，低版本永远不会加载。打包用高 API 编出的 class 即可。验证方法：低 API 编译时**只允许隔离类报错**，主类集合必须 0 错误——按文件名把报错分组，非隔离类出现任何一条就是没改完。

**隔离类内部也必须用反射，不能直接调高版本方法**（这一条纠正上例）：只要目标是让**整棵树在 `android-24.jar` 下编译通过**（而不是"只允许隔离类报错"），`webView.getImportantForContentCapture()` 写在隔离类里照样编译失败——javac 不认注解、只认 bootclasspath。正确形态是隔离类内 `View.class.getMethod("getImportantForContentCapture").invoke(webView)`，并把 `IMPORTANT_FOR_CONTENT_CAPTURE_AUTO/YES` 等常量改写成字面量（`0` / `1`）。同理 `@RequiresApi(Build.VERSION_CODES.Q)` 里的 `VERSION_CODES.Q` 本身在 API 24 jar 里不存在 → 改 `@RequiresApi(29)` + 注释写常量名，或干脆去掉注解。**判断标准**：想做到"8 个 API 级别全绿、0 错误"就用反射；接受"隔离类报错、只保证主类干净"就直接调。

三个必须记住的机制：

1. **门控用字面量，不用 `VERSION_CODES.O/Q`**。`VERSION_CODES.O`(26)、`.Q`(29) 是 API 26/29 才有的常量，在 API 24 的 `android.jar` 里不存在，`if (SDK_INT >= VERSION_CODES.Q)` 直接**编译失败**。写 `26` / `29` 加行尾注释即可。

   **这条不只是门控处，是每一处 `VERSION_CODES.X` 都会挡编译——包括 `@RequiresApi` 的注解参数。** 注解参数会被写进 class 常量池，`@RequiresApi(Build.VERSION_CODES.Q)` 在目标 API 的 `android.jar` 下同样是 `找不到符号: 变量 Q`，和代码里的裸常量同等致命。验证方法（一条命令确认，别靠推理）：拿目标 API 的 `android.jar` + androidx annotation jar 编一个只含 `@RequiresApi(Build.VERSION_CODES.Q)` 的空类，编译失败即证实。改成 `@RequiresApi(29)` 后立刻通过。所以批量清理时的 grep 模式要覆盖注解位置，不能只扫 `if (SDK_INT >= ...)`：

   ```bash
   grep -rn 'VERSION_CODES\.\(N_MR1\|O\|O_MR1\|P\|Q\|R\|S\|T\|U\|V\|W\)\b' <src dirs>
   ```

   实测 API 26 下 agree 的 glue + support_library 有 **44 处 / 20 个文件**，其中相当一部分是 `@RequiresApi`。替换成 API level 整数（`N_MR1`=25 `O`=26 `O_MR1`=27 `P`=28 `Q`=29 `R`=30 `S`=31 `T`=33 `U`=34 `V`=35 `W`=36），一次 `re.sub` 批量做完，比逐个文件改快且不会漏。
2. **`CompatChanges` 是独立的类级缺口，不在 `VERSION_CODES` 清扫范围内**。`android.app.compat.CompatChanges`（API 31+）在低版本 android.jar 里整个包都不存在 → 运行期 `NoClassDefFoundError`。它常以这种形态出现：

   ```java
   if (BuildInfo.isAtLeastT()
           ? CompatChanges.isChangeEnabled(WebSettings.ENABLE_SIMPLIFIED_DARK_MODE)
           : BuildInfo.targetsAtLeastT()) { ... }
   ```

   `VERSION_CODES` 清扫扫不到它（不含该字样），只扫 import 才看得见。语义降级：`CompatChanges.isChangeEnabled` 是"按 target SDK 的兼容开关决定行为"，在没有该类的老系统上等价于 `targetsAtLeastT()`，所以整条三元式塌缩成 `if (BuildInfo.targetsAtLeastT())`，行为与 API 31 之前的原生 WebView 一致。**找法是按 android.* import 逐个在目标 android.jar 里查类存在性**（见 D1 的扫描变体），这才是不依赖 grep 关键词的兜底。
2. **跨包访问不到隔离类时改用反射**。隔离类通常是 package-private（放在 `agree.webkit`），而 `android.webkit.WebViewDelegateWrapper` 在别的包，`instanceof`/方法调用都引用不到。做法是 `Class.forName("android.graphics.RecordingCanvas")` + `isAssignableFrom`，`ClassNotFoundException` 时返回 `false`——语义与 `instanceof` 完全等价，且不产生编译期/类加载期的类引用。
3. **纯系统回调且低版本不存在的，直接删比门控更干净**。判断依据是 AOSP 对照（见 D6）：官方 Android 7 的 `WebView.java` 里 `autofill`/`TextClassifier`/`ContentCapture`/`Translation` 关键字出现 **0 次**，说明 agree 那批是从高版本 AOSP 抄来的，删掉即回到原生行为，不是"阉割功能"。删一个 `@Override` 方法时**连带删 import**，否则残留 import 照样报错；`WebViewProvider.ViewDelegate` 这类接口里的 `default` 方法删掉后，要同步删实现类的 `@Override`（先 `grep -rln <方法名> <src>` 确认范围）。

### D4. 重新打包 AAR（只替换改动的类）

**不要**用只编了部分源码的 jar 整体替换原 classes.jar（条目数差一个数量级 = 漏了大量类）。正确做法：以**原 classes.jar 为基底**，只覆盖改动的 .class（保持包路径），再重新打包。

- **不要把桩 R 类打进产物**：AGP 会为 AAR 重新生成 R 类，冲突。检查时用精确路径（`org/chromium/.../R.class`），别用宽泛 grep（会匹配到 `RenderProcessGoneDetail` 之类的名字）。
- 打包后核对条目数与原 jar 同量级。

### D4b. 方法签名级不兼容（比 `super.*` 更难，反射救不了）

`super.*` 只是方法体里的 `invokespecial`；还有一类更根固：**方法签名本身引用了目标 API 不存在的类型**，例如

```java
public void setTextClassifier(TextClassifier tc)            // TextClassifier = API 28
public void autofill(SparseArray<AutofillValue> values)     // AutofillValue = API 26
public void dispatchCreateViewTranslationRequest(..., ViewTranslationRequest ...)  // API 31
```

javac 在 `-cp android-24.jar` 下把它们报成 `程序包 android.view.autofill 不存在` / `找不到符号 类 TextClassifier`。注意这与 D1 里“少了依赖包”的报错长得很像，但换 stub 也治不了——是目标 API 真的没有这个类。

**JVM 实测的崩溃时机（决定能不能靠反射/门控绕过）**：

| 场景 | 结果 |
|---|---|
| 类只被 `Class.forName` 加载 | ✅ 成功 |
| 执行该类任意入口（`main` / 实例化后有代码路径执行） | ❌ `NoClassDefFoundError` |
| **枚举/解析方法**（`getDeclaredMethods()`） | ❌ `NoClassDefFoundError` |
| **接口**方法签名含缺失类型，实现类实例化 + 调其他方法 | ✅ 成功（但反射枚举方法表仍崩，见 D4d） |

**结论：反射救不了签名级不兼容**——签名在类的常量池里，ART 只要校验这个类就会解析。所以 D3 的“隔离类 + `SDK_INT` 门控 + 跨包反射”手法**只适用于方法体内的调用**，对签名本身引用高版本类型的无效。（实验复现：造一个 `Absent` 类 + 引用它的 `Sub`，`javac` 后删掉 `Absent.class` —— `Class.forName("Sub")` 成功，`Sub.main` 与 `getDeclaredMethods()` 都抛 `NoClassDefFoundError`。）

三条出路（按代价排序）。**先说结论：`@Override` 的方法只能走第 1 条，非 `@Override` 的走第 2 条，第 3 条只在真要零破坏时才考虑**——这个分类决定了整个改造是 4 小时还是 5 天：

1. **删掉这些方法**。判断依据：参数类型在目标 API 上根本不存在 → 宿主代码在目标 API 下**编译不过**，因此**不可能调用**，删掉对目标 API 零影响。代价是同一 AAR 在高版本设备上也少了这个方法（真正的功能退化），需用户拍板。

   **`@Override` 的方法只能走这条**（如 `autofill` / `onProvideAutofillVirtualStructure` / `isVisibleToUserForAutofill` / translation 全系）：签名由父类写死，改不成 `Object`。删掉后系统改调父类默认实现 → **Autofill Framework 与 API 31+ Translation 在该 AAR 上永久失效**；HTML `<input>` 基础输入不受影响（走 Chromium 引擎 `.so`，不经这条虚方法）。所以"支持 API 24"与"保住 autofill/translation"在单类实现下**不可兼得**，这不是没做好的借口而是结构性冲突，要把这句话原样告诉用户。
2. **签名改 `Object` + 转发到隔离类**：`setTextClassifier(Object tc)` 内部 `SDK_INT >= 28` 时调 `WebViewApi28.setTextClassifier(this, tc)`（后者强转后调用）。参数位用 `Object` 对 Java/Kotlin 调用方**双向兼容**，只丢编译期类型检查；**返回位**改 `Object` 会让 Java 宿主的 `TextClassifier tc = w.getTextClassifier();` 编译失败，需补一次 `(TextClassifier)` 强转——注意：**能写出这行代码的宿主项目必然 `compileSdk >= 28`**（`TextClassifier` 是 API 28 类型），所以强转在源码层面永远可行，属于"多写一次类型转换"而非"功能丢失"。转发层再往下（`WebViewProvider.setTextClassifier`）也要一并放宽为 `Object`，否则隔离类里一出现 `TextClassifier` 就又回到签名级不兼容。
3. **拆 API 分级继承链**（`WebView` → `WebViewApi26` → ……，AOSP 官方做法）。零破坏但等于重写单类（agree 的 `WebView.java` 3250 行），按周计，不推荐。

**取舍时先问用户，别自己决定删公开 API**：功能退化（页面翻译、智能文字分类、自动填充）是要用户拍板的业务决策；但“这些 API 在目标 API 上宿主根本无法引用”是可以拿事实断定的，说清楚即可。

**给用户报影响时说准层次，别把“API 24 上不存在”和“高版本上的功能”混成一句**。以 Autofill 为例，失效的只是 **Android Autofill Framework（密码管理器）与 WebView 虚拟视图结构**的集成；网页里 `<input>` 的输入、密码框、表单提交全部走 Chromium 引擎 `.so`，**一点不受影响**。用户听到“自动填充失效”很容易以为网页表单坏了，这是最常见的一次误报——先讲清这条边界，再谈代价。

**落地顺序（档位 B 的完整步骤，实测 3 文件改动 + 3 个新隔离类即可全绿）**：

1. 构造器里的高版本默认值设置（`getImportantForAutofill` / `getImportantForContentCapture`）先把**方法体**下沉到隔离类，主类只留 `if (SDK_INT >= <字面量>)`。这一步不改签名，最容易见效。
2. 非 `@Override` 的公开方法（`setTextClassifier` / `getTextClassifier`）签名放宽为 `Object`，**同时把 provider 接口层的同名方法一起放宽**——只改一头会在隔离类里重新引入 `TextClassifier`，回到签名级不兼容。
3. `@Override` 那批（autofill / onProvideAutofillVirtualStructure / isVisibleToUserForAutofill / translation 全系 / onProvideContentCaptureStructure）整体删除，按 D4c 全树反查接口 `default` 方法 + 实现类 `@Override`，三处一起清。
4. 删完后逐个**同步删 import**（`android.view.autofill.*`、`android.view.textclassifier.*`、`android.view.translation.*`）——残留 import 一样报 `程序包 … 不存在`。
5. 隔离类内全部改反射 + 常量字面量（见 D3 的纠正段），`@RequiresApi(N)` 用数字不用 `VERSION_CODES.X`。
6. 跑 D8 的跨 API 循环验收：24/26/28/29/31/33/34/35 全部 0 错误、`.class` 数一致（agree 是 108 个）。

删除处**必须留块注释写明“为什么删、删了影响什么、想恢复该怎么做”**，因为下一个读这段代码的人（包括未来的自己）看不到被删的方法，只看得到一片空白，会以为是漏改。

### D4c. 删 `@Override` 方法后必须全树反查

删 `WebView.setTextClassifier` 这类方法时，同一签名往往还在接口里（`WebViewProvider.ViewDelegate` 的 `default` 方法）和实现类里各有定义。

```bash
grep -rln '<方法名>' <agree java src>   # 先看范围，再决定删哪几处
```

漏删任一侧都会留一个引用高版本类型的签名，D4b 的崩溃照旧。

### D4d. 接口方法签名含高版本类型：能编译但别留着

实测补充：**接口里的方法签名引用不存在的类型，不会导致实现类加载失败**——`class C1 implements IFace { @Override public void f(Absent a){} }` 在 `Absent` 缺失时仍能 `new C1()` 并调用其他方法，只有反射枚举方法表（`getDeclaredMethods()`）才抛 `NoClassDefFoundError`。这与"类/父类方法"（D4b 表格里必然崩）不同。

但**依然必须清掉**，因为：① javac 在低 API 下直接编译失败；② AAR 的 classes.jar 里留着无效签名，对 ART 校验是隐患。清理时按 D4c 全树反查：`WebViewProvider.TextClassifier` 这类**普通接口方法**放宽成 `Object`，`ViewDelegate` 里的 `default` 方法（autofill/translation 那批）直接删。删完记得同步删实现类的 `@Override`，否则实现类自己又留一份高版本签名。

### D5. 补 protobuf 依赖

glue 初始化时若 classes.jar 缺 protobuf → `NoClassDefFoundError: GeneratedMessageLite`（表现为 `AwBrowserProcess.setWebViewPackageName` 类初始化失败）。补 `protobuf-javalite`，并在 App 侧加 packaging 规则排除重复文件（AAR 内可能已带 `.proto` 资源）。

### D6. AOSP 对照（判断某方法能否安全门控）

拿不准某个 API 29+ 的方法能否降级时，对照 AOSP 官方对应分支的源码。AOSP `android10-release` 的 `WebView.java` **只有 Autofill、没有 ContentCapture** → agree 里的 ContentCapture 调用是作者自己加的，不是官方逻辑，可安全门控掉。按分支拉单文件对照（`android.googlesource.com/platform/frameworks/base/+/refs/tags/<tag>/core/java/android/webkit/WebView.java`），别整仓拉。

**AOSP 分支的选择规则：取与目标 minSdk 同一个 API 级别的分支。** 实测对比：

| AOSP tag | API | `WebView.java` | 与低一级的差异 |
|---|---|---|---|
| android-7.0.0_r36 | 24 | 2686 行 / 158 方法 | — |
| android-7.1.2_r39 | 25 | 2702 行 / 158 方法 | WebView API 完全相同；但 `View` 多了 `setRevealOnFocusHint`/`getRevealOnFocusHint` |
| android-8.0.0_r36 | 26 | 2961 行 / 169 方法 | **多 11 个方法**（Autofill / TextClassifier / RendererPriority / getCurrentWebViewPackage 等） |

要点：

- **7.0 与 7.1.2 的 webkit API 表面一致**（WebView/WebSettings/WebChromeClient 方法数全等），差异在基类 `View`。若只比 WebView 就断言"两版本等价"会漏掉基类。拿低级别那个分支（目标 minSdk 同级）做基准最安全。
- **不能用高一级的 AOSP 源码去支持低一级设备**：API 26 的 `WebView.java` 比 API 25 多 11 个方法，系统会把它们当作 `@Override` 回调入口，在 API 25 设备上 → `NoSuchMethodError`（与最初 Android 8 崩溃同机制，只是提前了一级）。
- **但也不能整批重导 AOSP**：`WebViewDelegateWrapper` 在 `android.webkit` 包，它引用 agree 的 `org.chromium.*` 隔离机制、以及 `MyDrawFunctor` 等非 AOSP 类，直接覆盖会把自研层冲掉。先跑 D1 扫描——实测 93% 的文件本来就兼容，需要动的只有 4 个，重导是浪费。
- 用 gitiles 目录 JSON 接口机械化列文件，比猜更可靠：

  ```bash
  curl -sS "https://android.googlesource.com/platform/frameworks/base/+/refs/tags/<tag>/core/java/android/webkit/?format=JSON" \
    | tail -c +5 | python3 -c "import json,sys; d=json.load(sys.stdin); print(len([e for e in d['entries'] if e['type']=='blob']))"
  ```

- 批量下载时网组会偶发返回非 base64 内容（表现为 `b64decode` 静默得到空串）：下载后断言文件里含 `class`/`interface` 关键字，失败的单个重试即可，不要当成文件不存在。

### D7. 能砍的层先砍

`support_library`（001 patch，21 个文件）是给 androidx.webkit 跨 provider 调用用的，App 内嵌场景没有 provider 边界，本就不需要——砍掉能直接去掉一大块隐藏 API 接触面。但 glue 核心路径仍依赖一部分隐藏 API，砍不干净，不能只靠这一步。

陷阱：

- `git apply --check` 三个 patch 全绿 **不能** 作为"兼容低版本"的证据——隐藏 API 问题编译期不报，只在运行期炸。
- 看到 glue 里有 `@RequiresApi` / `@SuppressLint` 别以为已经门控好了：这些只是**编译期注解**，低版本走到该分支仍会 `NoSuchMethodError`。
- 判断"某个 Java 文件能不能在低版本跑"要看**运行代码**里的 `Build.VERSION.SDK_INT`，javadoc 里成百上千处 `VERSION_CODES` 引用是噪声。
- **`super.*` 调用必须单独反查**：高 API 编译全绿不代表低版本安全（见 D2）。

### D8. 全绿验证脚本（跨 API 级别回归）

改完后一次性验证"一套源码 N 个 API 级别全绿"，不要只验目标那一个——**改 low 端很容易顺手把 high 端改坏**（例如把 `getTextClassifier` 放宽成 `Object` 后忘了同步 provider 层、或删 `@Override` 时误删了别的 `@Override`）。

```bash
for API in 24 26 28 29 31 33 34 35; do
  AJ="$ANDROID_SDK/platforms/android-$API/android.jar"
  mkdir -p /tmp/out-$API
  javac -nowarn -source 17 -target 17 \
        -cp "$AJ:$ANNOTATION_JAR:$CHROMIUM_BASE_JAR" \
        -d /tmp/out-$API $(find <agree java src> -name '*.java') /tmp/rstub/.../R.java \
        > /tmp/log-$API.txt 2>&1
  [ $? -eq 0 ] && echo "API $API OK ($(find /tmp/out-$API -name '*.class'|wc -l) classes)" \
                || { echo "API $API FAIL"; grep '错误:' /tmp/log-$API.txt|head -5; }
done
```

要点：

- **必须补 R 桩类**（`R.id/view/menu/string`），否则 `程序包 R 不存在` 混在真错误里。从源码反推字段：`grep -o 'R\.\w*\.\w*' <两处引用的文件>`。
- **必须给 `org.chromium.base.*` 的 jar**（原 AAR 的 classes.jar 里就有 394 个类），否则"程序包 org.chromium.base 不存在"淹没真实报错。
- 每级都要断言 `.class` 数量相同（如 108 个）；只判 exit code 会漏掉"编译通过但少编了一批"。
- **期望结果：所有级别同一份源码、0 错误、class 数一致**。这比"只验 API 24 通过"强得多，因为它同时证明了高版本没退化。本技能 `scripts/verify_api_compat.sh` 是这个循环的可执行版本。

## Native 层运行期诊断（.so 能否在低版本跑）

Java 层修完后若仍崩在 native，用下列手段定位，不要靠猜。**这是链式暴露**：每修好一层，装机复测后会露出下一层的问题（Java 隐藏 API → 缺依赖 → native CHECK），别在第一层修完就宣布完成。

1. **`.note.android.ident`**：NDK 写入的 API level 烙印（`readelf -n`；macOS 自带 readelf 不全时自己解析 ELF note 段读 `ANDROID_API_LEVEL`）。**它是构建配置写进去的，不等于 .so 真的兼容该版本**——只说明链接时用的 NDK api level。
2. **符号强弱**：`nm -D --undefined-only libwebviewchromium.so`。`w`（weak）= 运行时可选，低版本缺失不崩；`U`（strong）= 必须存在，缺失则加载失败。Chromium 对高版本 API 多用弱引用，所以 `.so` 常能在低版本加载成功、却崩在别处。
3. **崩溃点性质**：ARM64 的 `BRK` 指令（`(ins & 0xFFE0001F) == 0xD4200000`）= Chromium 的 `CHECK()` / `IMMEDIATE_CRASH()` 断言失败，日志为 `Fatal signal 5 (SIGTRAP), code 1 (TRAP_BRKPT)`——不是空指针。
4. **定位 CHECK 位置**：`.so` 被 strip 时无符号表。用崩溃 pc 偏移（落在 `.text` 段）反汇编，找函数序言（`stp x29,x30,[sp,#-N]!`，如 `0xa9bf7bfd`）定函数起点；含多个 BRK 的短函数（~176 字节）就是 CHECK 展开桩；再搜 `BL` 指令找调用者。**这条路效率很低**——优先找构建产物里未 strip 的 .so 或带符号的 tombstone。
5. **排除 GPU 干扰**：把 `--disable-gpu --disable-features=Vulkan` 写进 App 的 `files/webview-command-line`（`adb shell run-as <pkg> sh -c 'cat > files/webview-command-line'`）可确认崩溃是否在 GPU 路径；但 Chromium 初始化早期就探测 Vulkan，命令行不一定能完全关掉。

**官方支持窗口**：Chrome/WebView 对 Android 8/9 的支持到 **M138** 为止（M139 起要求 Android 10+）。M132 在官方窗口内，理论上应能在 Android 8 上跑；若 native 初始化就 CHECK 失败，更可能是构建配置不一致（`.note` 写 26 但实际用高 API 头文件编）或该版本未在 Android 8 上测过，而不是"官方不支持"。

## agree 自研层成分（决定移植重心）

回答"patch 之外还要导入多少东西"时，先分清哪些是抄的、哪些是原创——这直接决定移植时哪些要小心：

| 成分 | 规模 | 来源 |
|---|---|---|
| AOSP `android/webkit/*` API 副本 | **53 个 java / 13.5k 行（约 99%）** | 逐文件带 `Copyright (C) … The Android Open Source Project` |
| **draw_fn C++ 渲染层** | **6 个文件 / 971 行** | 改造自 Chromium `android_webview/test/shell/src/draw_fn/`（头文件 include guard 仍写着 `ANDROID_WEBVIEW_TEST_SHELL_SRC_DRAW_FN_CONTEXT_MANAGER_H_`） |
| `MyDrawFunctor.java` | 66 行 | agree 自写的 JNI 桥（`@JNINamespace("draw_fn")`） |
| `ProductConfig` / `BuildConfig` / `NativeLibraries` | 77 行 | Chromium gyp 脚本自动生成，仓库里是快照 |
| `res_webkit/`、manifest、proguard.flags、BUILD.gn、3 个 patch | — | 自研胶水 |

推论：

- **Java 层几乎全是 AOSP 拷贝**，所以"目标 API 降级"主要是在 AOSP 副本上做门控/删除，不是重写。
- **`draw_fn` 的 971 行 C++ 是真正的移植风险点**：它直接调 Chromium 内部 API（`base/android/scoped_java_ref.h`、`ui/gl/android/scoped_a_native_window.h`、`scoped_java_surface.h`），换大版本时这些接口会变，编译不过也多在这里。评估换基线工作量时把这块单独算，别只看 patch 的 67 个 hunk。
- 版权头是**区分"AOSP 拷贝"与"agree 原创"的唯一可靠依据**，但 `Copyright 2019 The Android Open Source Project`（无 `(C)`）与 `Copyright (C) 2019 The Android Open Source Project` 两种写法都有——只匹配一种会把 5 个 AOSP 文件误判成原创。

## 集成侧必须同步的三处

1. 宿主 `build.gradle`：`minSdkVersion 24`
2. `androidResources { noCompress 'bin','pak' }`（否则 assets 被压缩、WebView mmap 加载失败）
3. 5-AAR 交付形态不变（主 AAR + 4 辅助），无需改动

## iOS 对照（同一批内核的双端支持边界）

iOS 没有"minSdk"概念，等价物是 **Deployment Target**（Xcode → Target → General → Minimum Deployments），但它**不拦安装**：系统 WebView 内核由 iOS 本身提供（WKWebView 走系统版本），宿主 App 只受 App Store 的最低系统版本要求约束。所以"内核不支持老系统"在 iOS 上表现为**宿主 App 跑在哪个系统上就用哪个系统内核**，无法像 Android 那样打包内核降门槛。双端需求应对齐时，Android 侧可以打包内核下探到 24，iOS 侧的等价手段只有**宿主 App 的 Deployment Target**（影响能否装，不影响内核能力）。

## Pitfalls

- AAR 的 manifest 不写 minSdk → "AAR 不支持低版本" 的直觉是错的，先查 App 和 .so 的 ident 段再下结论。
- **别把"只验目标 API 编译通过"当成交付标准**：改动会同时影响高低两端，必须跑 D8 的跨 API 循环（同一份源码 24→35 全绿、class 数一致）。
- **删 `@Override` 前先确认它是不是真 `@Override`**：用 `grep -B4` 看紧邻的注解行。`onProvideContentCaptureStructure` 看着人畜无害（签名只用到 `ViewStructure`/`int`），但它重写的 `View` 方法直到 API 29 才存在 → API 24 下 `@Override` 直接编译失败。同理 `View.autofill`(26)。判断"某个 `@Override` 能否保留"的唯一依据是**父类在该目标 API 上有没有这个虚方法**，不是参数类型是否安全。
- 四层限制里**只有 Java glue 层是编译期静默的**：patch 校验、编译、`git apply --check` 都发现不了，必须先拿到目标设备的崩溃栈再动手，否则改 gn 参数或改 App minSdk 都是白干。
- 用户说"是 AOSP 导入的 Java 代码导致的"时，先分清是自研 android.webkit 复制层（基本兼容，0 处 SDK_INT 门控）还是 glue 隐藏 API 层（真凶），两者的工作量差一个数量级。
- **agree 那 53 个类是配 `.so` 的接口层，不是可以随便换的 AOSP 源码**：它们比 AOSP 7.0 多出 `RenderProcessGoneDetail`(26) / `SafeBrowsingResponse`(27) / `TracingController`(28) / `WebViewRenderProcess`(29) 等类，`WebView.java` 也比 7.0 多 564 行。整合 AOSP 7 的源码会破坏与 `.so` 的 JNI 签名契约 → `UnsatisfiedLinkError`。AOSP 老版本源码的位置是**参考手册**（查某 API 在老版本长什么样），不是替换材料。
- AOSP 7.0 与 agree 的 webkit 包**双向有别**：7.0 有 `WebViewDelegate`/`WebViewProviderInfo`/`MimeTypeMap`/`Plugin` 等 agree 没有的类（高版本已删），agree 有 7.0 没有的 9 个新类。比对时两个方向都要看，只查缺不缺会漏掉"agree 多出来的是它自己的必需件"。
- `default_min_sdk_version` 一改，全树 `_MIN_SDK_VERSION` 宏与 NDK 头文件同步变化，个别目标若单独写了 `min_sdk_version` 会各自保留——排查时 grep 一下 `min_sdk_version =` 在 android_webview/ 与 third_party/ 的覆盖点。
- 不要靠 `strings libwebviewchromium.so | grep -i sdk` 判断 API level，噪声极大且不可靠；用 `readelf -n` 的 `.note.android.ident`。
- 降基线（方案 B）前先确认 patchset 是否还有维护中的低版本分支——直接重编比移植快的情况确实存在。
- 评估"要不要换基线/AOSP 重导"之前，先跑 D1 的 javac 全量扫描。实测 agree `java/` 57 个文件在 API 24 下只有 45 处错误、集中在 4 个文件——多数情况下改造面比预想小一个数量级，"从 AOSP 重导"或"换 M119"可能是多余的。
- **AOSP 分支选择：取与目标 minSdk 同一个 API 级别，不是"最新的那个次版本"**。目标 API 26 用 `android-8.0.0_r*` 而不是 `8.1.0`；目标 API 24 用 `android-7.0.0_r*` 而不是 `7.1.2`。差一级就可能引入多余 API（7.0→7.1.2 的 WebView 表面相同，但基类 `View` 多了两个方法）。**判断前必须实际比对同名类的公开方法集合，而不是看版本号或行数**——行数差可能只是注释。
- **AOSP 版权头有两种写法**：`Copyright (C) 2019 The Android Open Source Project` 与 `Copyright 2019 The Android Open Source Project`（无 `(C)`）。只匹配一种会把 5 个文件误判成原创，评估"自研成分"时漏算。
- 删 `.git`、换目录、重新 `git init` 后，不要用 `git log` 判断源码是否就位（未 checkout 时永远报 "branch 'main' does not have any commits yet"）；直接 `cat chrome/VERSION` + `ls build/config/android/config.gni` 验证版本与关键文件在。
- 用户问"这样改会不会影响功能"时，逐项对照 AOSP 同版本源码给出"官方本来就没有"的证据，而不是笼统回答"不影响"——功能取舍（如 Autofill / 页面翻译）需要用户自己拍板，但"这是抄高版本带来的重负，删掉等于回到原生"是可以拿事实断定的事。
