# 改 API 包名 / dist_aar target 名的完整文件面（M119 实测）

用户要求改 agree 的 API 包（宿主 App import 的那个包，如 `agree.webkit`）或 `webview_aar` target 名时，按本文执行。全链路实测于 2026-11 的 `org.chromium.android_agree.webkit → agree.webkit` 改名。

## 改包名：必须同步的文件面（全量清单）

| 位置 | 改动 | 备注 |
|---|---|---|
| 56 个 Java 文件（`java/src/<包路径>/`） | `package` 声明行全部替换；显式跨类 import 仅 6 处（`WebView.java`→MyDrawFunctor；`UrlInterceptHandler.java`/`UrlInterceptRegistry.java`→CacheManager.CacheResult；`WebViewProvider.java` 3 个 WebView 嵌套类） | R 引用是同包解析（JsDialogHelper/FindActionModeCallback 的 R import 是注释掉的），无需显式改；目录 `git mv` 镜像新包路径 |
| `BUILD.gn` | `webkit_glue_resources` 的 `custom_package`、`webkit_glue_java` 的 `resources_package`（R 类包，必须与代码同包）、57 条 sources 路径前缀、`MyDrawFunctor.java` 路径（generate_jni/draw_fn_impl_java） | AAR 输出文件名由 `output` 变量决定，与包名无关，可不动 |
| `patches/001/002/003/005` | 001：178 处；002：`custom_package` + 注释；003：注释；005：3 行 context import | 004/006 无引用。**patch 列表不是只有 001**——002 的 `custom_package` 漏改会让资源 R 类包与代码分家 |
| `AndroidManifest.xml` | `package="..."` 属性改为新包基名 | AGP 对 AAR manifest package 基本忽略，但保持一致 |
| `proguard.flags` | **无需改**（实测只 keep glue 类 + `org.chromium.build.BuildConfig`，不引用 API 包） | 先 grep 确认再跳过 |
| 文档 | README（import 示例 + 包镜像说明）、FILES.md、patches/README.md | |
| 技能快照 | SKILL.md + references + `scripts/port_agree_patch.py` 的映射行（`android.webkit.{cls} → 新包.{cls}`，移植生成器必须同步）+ `make_res_aars.py` 注释；重新打包 tar | 只改文档不改脚本，下次移植新类会写回旧包名 |

## 绝不能动的（动了断链）

- `android.webkit.WebViewDelegateWrapper`：`WebViewFactory` 按这个名字反射查找
- `com.android.webview.chromium.*` glue 包 + `WebViewFactory.java` 的反射常量 `CHROMIUM_WEBVIEW_FACTORY`（要连 glue 一起改名 = 工作量翻倍：001 全部 64 文件的 package 声明与内部 import + proguard 全部 keep 规则 + 反射常量，别一起做）
- `org.chromium.content.app.SandboxedProcessServiceN`（manifest 服务类，绑 content 层）
- `org.chromium.build` / `org.chromium.android_webview`（占位配置类）

## 坑（都踩过）

- **先跟用户确认目标包名再动手**：用户可能意图是「父包 + 类名」（`agree.webkit` 包 + `WebView` 类 = `agree.webkit.WebView`），比显而易见的完整包短一截。批量改名跑错目标 = 整个周期白费
- **sed 必须同时覆盖点号与斜杠两种形式**：`org.chromium.android_agree.webkit`（package/import）与 `org/chromium/android_agree/webkit`（javadoc 里的 `ClassNotFoundError` 注释示例，如 WebViewApiQ.java）。最终残留检查也要 grep 两种形式，否则一条旧 javadoc 字符串活到下次
- **树的已应用 patch 状态会与 patch 文件漂移**：对已 patch 覆盖的文件做树内手修后不更新 patch，清树重打时 gn gen 以矛盾报错暴露旧内容（实测：rules.gni 的 abi_mapping 迭代仍是 scope 下标写法，与 BUILD.gn 的 scope 列表格式矛盾 → `rebase_path requires a list or a string`；此前一直靠树内手修掩盖）。修复 = 更新 patch（固化）+ 同步更新 skill 里记录该格式的 reference，再重打
- **改包名 = 重链 .so（双 ABI）**：jni_zero 符号哈希含包名 → 生成的 jni 头全变 → 仓库 C++ 重编 → 双 ABI ThinLTO 重链（~178 edge、30+ 分钟），不是只重编 Java。见 SKILL.md Pitfalls「改 API 包名必须重编 C++」
- **改包名不改变 5-AAR 拆包**：4 个辅助 AAR 的 manifest package 仍是 `org.chromium.*`（对应内核引用的 R 包）；API 包自己的 R（`agree.webkit.R`）依旧没有任何 AAR 提供（已知限制，JS 默认对话框会崩，修复方案见 references/rclass-package-mismatch.md）
- **`git mv` 目录前先 `mkdir -p` 目标父目录**：git mv 不自动创建中间目录，目标缺父级直接 `fatal: renaming ... failed: No such file or directory`，且它作为 `&&` 链首失败会让后面所有 sed 都不执行（看起来"改了"实为没改，残留检查才暴露）。长命令链先单独跑第一步验证成功再串
- **全局改名用占位符保护要保留的路径引用**：文档/脚本里项目名与 checkout 路径（`/root/crwebview`、`../crwebview/patches`）共存时，先 `s|/root/crwebview|@@CO@@|g` 占位 → 全局替换项目名（`s/crwebview/agree/g`）→ 还原占位符；否则全局 sed 把路径一起改掉（G 类改名暂缓时尤其必要）

## 改 dist_aar target 名（如 `webview_aar`）的级联

`ninja webview_aar` 的短名 = BUILD.gn 的 `dist_aar("webview_aar")` target 名。改名后：
- GN 派生产物 `gen/android_webview/agree/webview_aar.build_config.json` **跟随 target 名** → `make_res_aars.py` 与 `rebuild_res.py` 里硬编码的该路径必须同步（**rebuild_res.py 的路径少了 `agree/` 层级，是历史遗留的不一致**）
- SKILL.md / FILES.md 的 ninja 命令与 compile_resources FileArg 示例
- AAR 输出文件名（`output` 变量）与 target 名无关，可独立改

## 改名后的构建与验证流程

1. 仓库侧：git mv 目录 → 批量替换（两种形式）→ BUILD.gn/patches/manifest/文档/技能 → 提交
2. 树侧：`git checkout -- android_webview build`（重置 patch）→ 删 untracked 的 `android_webview/agree` 与 `android_webview/java/res_webkit` → rsync 仓库（排除 .git）→ 重新合并 `java/res_webkit` → 重打 001~006 → `gn gen`（**此处报错 = 有未固化的手修**）→ systemd-run 起 ninja
3. 发布链路照常：compile_resources（/usr/local/bin/python3）→ make_res_aars → add_aar_assets → recompress
4. 验证（全部要过）：classes.jar 无旧包 `L...` 引用、新包类在、`新包.R$layout` 引用在（js_prompt/webview_find）、manifest package、jni 双 ABI、testzip、辅助 AAR 包名不变
