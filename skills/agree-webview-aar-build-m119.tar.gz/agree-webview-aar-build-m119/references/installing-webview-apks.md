# Installing & validating a built WebView APK on device/emulator

Rules and diagnosis for the always-on gates in SKILL.md §6.

## ABI facts

- Device ABIs: `adb shell getprop ro.product.cpu.abilist` (primary: `...cpu.abi`).
- APK ABIs: `aapt dump badging <apk> | grep -E 'native-code|package:|sdkVersion'`.
- APK manifest flags (multiArch / extractNativeLibs): `aapt dump xmltree <apk> AndroidManifest.xml | grep -iE 'multiArch|extractNativeLibs'`.
- aapt / apksigner live in `third_party/android_sdk/public/build-tools/<ver>/` (the ver is visible in `aapt --version` or `ls` of that dir).
- Multi-ABI devices + single-ABI WebView APK → `INSTALL_FAILED_INTERNAL_ERROR: ... multiArch app's native libs don't support all the natively supported ABIs of the device`. The multiArch flag is baked into the WebView manifest on purpose; do not rebuild to "fix" it — install with `adb install --abi arm64-v8a <apk>`.

## Dump the signing cert WITHOUT java

apksigner (`--print-certs`) and keytool both exec java, which build servers often lack. The reliable route is the KEYSTORE the build used, not the APK's signing block:

1. Find which keystore the build signed with: `grep -n 'default_android_keystore_path' build/config/android/config.gni` → debug builds default to `//build/android/chromium-debug.keystore` (alias `chromiumdebugkey`, password `chromium`; cert subject `CN=Unknown`).
2. Parse the JKS with `scripts/jks_dump_cert.py <keystore> <out.der>` (pure python, no java).
3. `openssl x509 -inform DER -in <out.der> -noout -subject -issuer -fingerprint -sha256`.

The APK Signing Block (v2/v3) hand-parse is fragile — ID is u32 with value length = psize-4, the block carries zero-padding pairs, and the size-field offsets are easy to get wrong. Never build a parser when the keystore path is known.

## Provider acceptance & selection

- `adb shell cmd webviewupdate get-webview-packages` — valid providers; `Invalid package ... reason: Incorrect signature` = cert mismatch (see SKILL.md §6).
- `adb shell dumpsys webviewupdate` — what the framework considers valid plus the current selection.
- `adb shell cat /system/etc/webview_packages.xml` (older images; `/product/etc/...` on newer) — the expected package → signature mapping. The device's current WebView cert is also obtained by `adb shell pm path <webview-pkg>`, pulling that APK, and dumping its cert.
- Select: Settings → Developer options → WebView implementation, or `adb shell cmd webviewupdate set-webview-implementation com.android.webview`.

## Re-sign with the AOSP platform key (AOSP images / AOSP-signed ROMs only)

- Key files `platform.pk8` / `platform.x509.pem` ship in AOSP `build/target/product/security/` (public).
- Needs java for apksigner: `apksigner sign --key platform.pk8 --cert platform.x509.pem --out out.apk in.apk` (zipalign first if the APK is not 4-byte aligned).
- Re-signing does not change the APK's ABI — `--abi arm64-v8a` still applies on multi-ABI devices.
- This does NOT help on retail Google/OEM phones: their expected key is private.
