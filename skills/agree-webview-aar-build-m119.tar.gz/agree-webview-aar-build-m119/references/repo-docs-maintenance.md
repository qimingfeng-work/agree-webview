# 仓库文档维护与文件改名（agree）

用户把 agree 仓库的文档当权威索引：仓库结构一变（加/删文件、改行数、改 patch、改名），FILES.md 与技能文档必须同步；修正要 commit 回仓库并 push（origin = https://github.com/qimingfeng-work/agree.git）。

## FILES.md 核查：每个数值断言都对仓库实测

文档里的数字是"当时的快照"，会漂移。被要求"修正 FILES.md"时逐项重算，不要相信文档自带数值：

- **行数标注** → `wc -l <file>`。实测遇到过全部文件同时差 ±1 的系统性偏差（17 处行数全比 `wc -l` 多 1）；一处对不上就**全部重算**，别只修一个。文件是否以换行结尾用 `tail -c1 <file> | xxd -p` 确认（0a = 有）
- **文件/目录计数** → `find <dir> -type f | sort` 后数。注意 Java 总数可能被拆到多个 target（`webkit_glue_java` 57 个 + `copy_webkit_java` 3 个），对账按 BUILD.gn 的 sources 块而不是目录总行数
- **patch 覆盖断言**（如"71 个文件变更 = 64 Java + 5 GN + 2 其他"）：
  ```bash
  for p in patches/00*.patch; do echo "$p: $(grep -c '^diff --git' $p)"; done   # 每 patch 文件数，求和
  grep -h '^diff --git' patches/00*.patch | sed 's|^diff --git a/||; s| b/.*||' | sort | uniq -c  # 跨 patch 重复
  # 唯一文件数 = 总和 − 重复数（一个文件被两个 patch 都碰 = 计数两次）
  ```
  再对账"Java + GN + 其他"分类：GN 文件数 = 各 patch 里 BUILD.gn 路径去重数；"其他" = dist_aar.py、rules.gni 这类非 Java 非 GN
- **tar.gz 内容断言** → `tar -tzf <tar>`（文件清单/脚本数）；`tar -xOzf <tar> <顶层目录>/SKILL.md | wc -c`（体积）
- **manifest 服务数** → `grep -c '<service android:name="org.chromium.content.app.SandboxedProcessService' <manifest>` 才是真实条数；`grep -c 'SandboxedProcessService'` 会把注释和 meta-data 行一起算进去（42 ≠ 40）
- **BUILD.gn target 表** → `grep -nE '^\s*(dist_aar|copy|android_resources|generate_jni|android_library|java_library)\("' BUILD.gn`，数 target 并核对每个的描述
- **文档引用的路径在仓库里不存在** → 先 `git log --oneline` 查删除提交：删除可能是有意的（如 assets/ 被 commit 删除，是文档过时而非仓库缺文件），别把文档当真相去"恢复"

## 改名流程（例：webkit_AndroidManifest.xml → AndroidManifest.xml）

1. **先全仓 grep 引用**：`grep -rn '<旧名>' . --include='*'`（排除 .git 输出）
2. **构建侧文件名几乎不硬编码**：dist_aar 模板的 `android_manifest` 是 GN 变量（rules.gni），dist_aar.py 走 `--android-manifest` CLI 参数，patch/脚本极少写死文件名——先查构建树模板确认（`grep -n manifest /root/chromium119/src/build/config/android/rules.gni /root/chromium119/src/build/android/gyp/dist_aar.py`），确认后改名**不需要动 patch**
3. `git mv` 旧名 新名；更新 BUILD.gn 里的引用 + FILES.md
4. **同步技能文档**：live skill（/root/.hermes/skills/software-development/chromium-agree-aar-build-m119/）的 SKILL.md 与 references/*.md 里同样 grep 旧名并替换（示例命令、拷贝清单），顺带清掉同清单里已删除文件的残留引用（如 assets/）
5. **残留检查**：`grep -rn '<旧名>' . --include='*' | grep -v '^\.git'` 应为空
6. commit + push；下次构建直接生效

## 技能快照同步（skills/*.tar.gz ↔ live skill）

- 仓库 `skills/agree-webview-aar-build-m119.tar.gz` 是 live skill 目录的**再导出**，源头是 /root/.hermes/skills/software-development/chromium-agree-aar-build-m119/，别直接改 tar 里的文件
- live 技能文档有改动（或仓库改动波及技能文档）后：改 live → 重新导出 → 校验 → commit：
  ```bash
  cd /root/.hermes/skills/software-development
  tar -czf /root/agree-webview/skills/agree-webview-aar-build-m119.tar.gz --exclude='__pycache__' chromium-agree-aar-build-m119
  mkdir -p /tmp/t && tar -xzf /root/agree-webview/skills/agree-webview-aar-build-m119.tar.gz -C /tmp/t \
    && diff -r chromium-agree-aar-build-m119 /tmp/t/chromium-agree-aar-build-m119
  ```
- 校验时 live 目录多一个 `scripts/__pycache__` 是正常的（导出时排除）；出现任何其他 diff 说明源与导出版不同步，先解决再 commit
