# Evaluating third-party Chromium build repos (AAR exporters, patchsets)

When someone points at an external repo that "builds Chromium for you" (WebView/AAR SDKs, patched android_webview variants), verify it against the LOCAL checkout before recommending or adopting. READMEs for these projects are thin and routinely hide the real version coupling.

## Procedure

1. **Enumerate the repo, don't read the README.** GitHub tree API: `curl -sL "https://api.github.com/repos/<owner>/<repo>/git/trees/<branch>?recursive=1"` and list non-test files. A repo that is only `java/` + `BUILD.gn` + `patches/` is a *patchset*, not a build system — it must be dropped into a Chromium source tree and built there.
2. **Read the BUILD.gn to learn the mechanism.** A `dist_aar` target with `native_libraries = [ "$root_build_dir/libwebviewchromium.so" ]` plus a repackaged android.webkit API (own `org.chromium.*.webkit` package) = an embed-in-your-app engine (WebLayer-style). That distinction decides everything downstream: an in-app engine has NO system WebView provider/signature gates, while a system WebView APK does. They are different goals — clarify which the user wants before promising anything.
3. **Check every referenced GN target label against the local tree.** Grep the label inside the owning BUILD.gn: `grep -c '"glue_java"' android_webview/glue/BUILD.gn`. Do NOT `[ -e '//dir:label' ]` — a label is not a file path and the check silently reports missing. A label absent from the local version is version skew (deps are renamed/removed across Chromium majors).
4. **Decisive compatibility test: apply the patches.** Download each patch and run `git apply --check <patch>` from the checkout root. A failure on a SUBSTANTIVE hunk (file renamed/moved, big sections gone) means the patchset targets a different Chromium major — ground truth. But one or two rejected hunks on an otherwise-clean apply is usually trivial context drift (e.g. an adjacent import line that the newer version added): apply with `git apply --reject` and hand-fix the rejected hunks by reading what the diff wanted (often a pure import swap). android_webview's glue/support_library/BUILD.gn churn between majors, so use the repo's last-push/release dates only as a rough hint of the target major (a 2025-01 release ≈ M13x, not M156).

   **`git apply --3way` does not work on `--no-history` / `--depth=1` checkouts** — it errors `repository lacks the necessary blob to perform 3-way merge` and silently falls back to direct application, so it never rescues a hunk. Don't burn a cycle on it; go straight to `--reject`.

### Quantifying the port: classify every rejected file before writing any code

Run `git apply --check` per patch, then parse the `error: <path>: patch does not apply` lines to count rejected files. Then classify each one by what the diff actually does — the taxonomy decides the work, and the split is usually lopsided:

```bash
# per-patch reject list
git apply --check <patch> 2>&1 | grep -oP 'error: \K[^:]+(?=: patch does not apply)' | sort -u
```

| Class | How to recognize | Action |
|---|---|---|
| **Semantic rewrite** | diff body is only `android.webkit.X` → `org.chromium.<pkg>.webkit.X` import swaps | Redo the swap directly on the target file; ignore the patch's context lines entirely |
| **NOOP** | patch touched the file but added no reference to the ported classes | Skip — the hunk was cosmetic upstream |
| **Manual** | `BUILD.gn` / `*.gni` — target labels, deps, resource wiring | Hand-port against the target version's actual GN structure; no mechanical shortcut |

Measured on agree 2.0.0 (M132) ported to M119: 67 patch files → 53 needed only the semantic import swap, 9 were NOOP, 5 were BUILD.gn (all manual), and only 19 had actually failed `git apply --check`. So the scary "28% of files failed" collapses to "4 GN files need real work" once you classify.

**The swap must be gated by a whitelist of classes the port actually provides.** Blanket-rewriting `android.webkit.*` breaks the build by pointing at classes that were never copied. Derive the whitelist from the repo's own package directory and match on the fully-qualified name with a trailing word boundary so `android.webkit.WebView` doesn't eat `android.webkit.WebViewClient`:

```python
classes = {n[:-5] for n in os.listdir(f"{repo}/java/src/org/chromium/{pkg}/webkit") if n.endswith(".java")}
for cls in sorted(classes, key=len, reverse=True):        # longest first
    content = re.sub(re.escape(f"android.webkit.{cls}") + r"\b",
                     f"org.chromium.{pkg}.webkit.{cls}", content)
```

Keep the target-tree edits reversible: snapshot each file to `<file>.pre-port` before writing, so `git checkout` isn't the only way back in a tree you have also been hand-editing.
5. **Drive the file layout from the build, not from guessing.** After applying patches, copy the repo's java/res files and run `ninja -C out/<dir> -n <aar-target>` — the `missing and no known rule to make it: <path>` errors enumerate EXACTLY which repo files still need copying to which location. Patches can reference the same resource from two paths (e.g. agree's 3 res xml must land in BOTH `java/res_webkit/` for `webkit_glue_resources` AND `java/res/` for the pre-existing android_resources target) — the dry-run surfaces both. Loop dry-run → copy → dry-run until clean.
5. **Scan the issue tracker for goal-relevant breakage before recommending**: ABI coverage (these AARs commonly ship arm64-only; 32-bit support is a frequent open request), crash reports, and whether build steps are public or gated behind paid support (a project that answers "how to build?" with "purchase support" has no reproducible build path you can rely on).
6. **Cost reality**: an AAR still requires compiling all of `libwebviewchromium.so` — same C++ cost as the APK build. Porting the patchset to a different major is manual work on the java shim layer (the shims are copies of the android.webkit API surface, which changes with API level) — assume real work, not a flag flip.

## Pin the exact target version from a released artifact

When the repo ships a prebuilt AAR/APK, the exact Chromium version is inside it — extract and grep, don't guess from dates:

```bash
curl -sL -o agree.aar <release-asset-url>
python3 -c "import zipfile; z=zipfile.ZipFile('agree.aar'); open('libwebviewchromium.so','wb').write(z.read('jni/arm64-v8a/libwebviewchromium.so'))"
strings libwebviewchromium.so | grep -oE '[0-9]{2,3}\.[0-9]+\.[0-9]+\.[0-9]+' | sort -u
```

The version line among the noise (IPs, test data) is the one matching the project's release window — e.g. agree 2.0.0 ships `132.0.6834.86`. That tag name is exactly what the gitiles archive URL takes (`+archive/refs/tags/132.0.6834.86.tar.gz`); `curl -sI` on it returning HTTP 200 confirms the tag exists before committing a multi-GB download.

If you adopt the patchset, the patch file paths map the integration layout: for agree, repo `java/` goes to `android_webview/java/` and its BUILD.gn target definitions merge into `android_webview/BUILD.gn` — the patches reference `//android_webview:webkit_glue_java`, so the shim targets must live under that label, not in a standalone repo dir.

## Producing a new patchset for a different Chromium major

When the user decides to keep the patchset architecture (`git apply`-able patches) rather than switch to file overrides, the deliverable is a **new patch directory** that cleanly applies to the target tree. Do it in this order; the ordering is what keeps it verifiable.

1. **Apply the old patch with `--reject` to get the ported baseline**, then reset the tree and re-derive. Working from `git diff` is what makes the output a patch rather than a pile of edits.
2. **Hand-port the rejected files** (the semantic-rewrite + manual classes from the taxonomy above). Do these as direct edits on the target tree, not by editing patch text — you cannot reliably edit hunk context by hand.
3. **Generate the patchset from `git diff`, split by file type**, not by original patch number. The natural split that survives version churn is: one patch for all `.java`, one for all `.gn`/`.gni`. Splitting by the ORIGINAL patch boundaries reproduces upstream's grouping, which is meaningless in the new tree.
4. **Verify by resetting and re-applying — never by inspecting the diff.** The only proof that a patchset is portable is a clean `git checkout -- .` followed by `git apply --check` on every patch, then a real `git apply`. Report the file count and line delta as the invariant:

   ```bash
   git checkout -- . && git status --short          # must be empty
   for p in patches/*/*.patch; do git apply --check "$p" || echo "FAIL $p"; done
   for p in patches/*/*.patch; do git apply "$p"; done
   git status --short | wc -l                        # compare against expected count
   ```

   Re-run this loop after EVERY edit round. A patch that was verified twice then edited once is unverified.

5. **Validate GN syntax with the tree's own `gn`, not by eyeballing braces.** `gn format --dry-run <file>` returns 0 for syntactically valid GN. If it returns 2, run `gn format <file>` (it rewrites in place and exits 0 on success) and re-check — brace balance being zero is necessary but not sufficient.

   ```bash
   <src>/buildtools/<host>/gn format --dry-run android_webview/BUILD.gn
   ```

6. **For the Java side, prove API compatibility separately per target level.** A patchset that applies is not a patchset that runs on the target Android version. Run the javac scan at the target API (see `references/min-sdk-and-platform-support.md` D1/D8) against the applied tree.

**Before declaring coverage, diff the OLD patchset for content the new one dropped.** A re-derived patchset is built from `git diff` of the current tree, so it only contains what you actually edited. Changes the original patchset made that you did not re-make — most often *commented-out* toggles and disabled flags, which look like no-ops when skimming — silently vanish. Grep the old patch for removed lines (`^-` lines that are not matched by an added line) and confirm each one is either intentionally re-applied or genuinely obsolete in the target major. A disabled build flag that quietly comes back on produces no build error at all, only a runtime one.

### Drift-check: confirming the new patchset actually covers the old one

After generating, it is tempting to reverse-apply each old hunk (`git apply --check --reverse`) to prove coverage. **This produces false negatives and should not be used as the acceptance criterion.** Reverse-apply only succeeds if the tree content matches the hunk *exactly*; any additional hand-port edit on the same file (which is expected — you added API-gating comments, fixed imports) makes the reverse check fail even though the change is fully present.

Use it only as a rough inventory. The real acceptance criteria are: (a) the new patchset applies cleanly to a pristine tree, (b) `gn format --dry-run` passes on every touched GN file, (c) the target-API javac scan is clean for the files the patchset touches. State explicitly which of these were run and which were not (e.g. "not verified: full compile and on-device boot need the Linux build host") — do not let "patch applies" imply "works".

### GN `resources` blocks are the most version-brittle part

Hand-porting `BUILD.gn` by reusing the old patch's hunk context fails specifically on `android_resources` / `resources` targets, whose `sources = [...]` lists are pruned aggressively between majors (measured: a 9-entry list in the source version is a 6-entry list in the target version). Symptoms are a hunk that reports "succeeded" for every preceding hunk then fails only on the resource list.

Do not try to repair the context — **replace the whole block**. Read the target version's actual block, keep its existing entries, append only what the port genuinely needs, then re-emit the added `android_resources` / `java_strings_grd` targets below it. Adding entries the target version no longer has will fail the build later.

#### Before adding a resource entry: prove the file exists in BOTH trees

A re-derived `resources` block is the single place where a port most often adds *phantom* entries, because the source-version patch's list is copied wholesale while the files it names never existed there either. Check every entry against two locations before writing it:

1. the target Chromium tree's `java/res/` (does the source-version file actually live here?)
2. the external repo's own `java/` / `java/res*/` (is it supplied by the repo instead?)

An entry present in NEITHER is a hallucinated reference — it came from nobody, and no amount of build-config work will make it appear. Measured on agree 2.0.0→M119: of the 5 entries the old patch's `resources` block implied, `layout/js_prompt.xml`, `layout/webview_find.xml`, `menu/webview_find.xml`, `values/styles.xml` were absent from both trees while only the drawable PNGs and `raw/histograms_allowlist.txt` genuinely existed. M119's `java/res/` has no `layout`, `menu`, or `values` directory at all.

#### Overlapping resource blocks: verify by resource-id, then keep the correct owner

Two `android_resources` targets can legitimately list the same XML while only one has the right `custom_package`. Picking by name or by "the old patch did it this way" silently ships duplicate resource definitions.

Decide by matching the ids the Java code actually references against each candidate block's `custom_package`:

```bash
grep -rn 'R\.\(id\|layout\|menu\|style\)\.' <java src>   # what the code asks for
# then: which block's custom_package matches the code's package?
grep -n 'custom_package' <BUILD.gn>
```

**A class that references bare `R.*` with no explicit `R` import belongs to its own package's `R`** — that is the deciding evidence for which block owns the resource, and it is usually the block whose `custom_package` equals that class's package. Keep that one, drop the duplicate. Shipping both generates two `R` classes for one resource id in two packages (build-time resource conflict) and doubles the resource payload for no benefit.

Also confirm the duplicate is not merely *unreferenced*: sweep for the resource **type** the block would supply. If no Java file references `R.style.*` at all, a `values/styles.xml` entry in that block is dead weight even where the file does exist — drop it rather than porting it forward.

#### Before deciding a ported resource block is "needed", check whether the target version already has an equivalent

A ported `android_resources`/`java_strings_grd` target can be **wholly redundant** — the target major may already declare an identical block under its own name, already wired into the build. Verify with three greps, then delete rather than wire:

```bash
# 1) does the target tree already have a block with this content?
grep -rn 'android_resources("content_java_resources")' --include='BUILD.gn' .
# 2) does the ported block's package collide with an existing one?
grep -n 'custom_package' <ported BUILD.gn>  # same custom_package in two blocks = duplicate R class
# 3) do the parties that consume it already get it from upstream?
grep -rln 'import org.chromium.content.R' content/public/android/java/src | wc -l
```

Measured on agree→M119: `agree_content_resources` duplicated M119's `content/public/android:content_java_resources` entry-for-entry (same 20 sources, same `custom_package = "org.chromium.content"`, downstream `content_main_dex_java` already depends on it), and `agree_ui_android_resources` duplicated `//ui/android:ui_java_resources`. The repo's own Java referenced none of them: 0 hits for `org.chromium.content.R`, `org.chromium.embedder_support.delegate.R`, `org.chromium.ui.R` across all 60 of its files, while the target tree's own code had 19 and 16 hits respectively — those R classes come from the tree, not the port. **A `custom_package` that equals an existing upstream block's package is the decisive signal**: two blocks supplying one package produce duplicate `R` classes at build time.

**File-name drift inside a copied block is corroborating evidence, not a separate bug.** If a ported block's `sources` list contains one to a handful of files that are absent in the target tree (`color_picker_dialog_view.xml`, `ic_paste_as_plain_text.xml`, `values/ids.xml` — renamed or removed upstream), the block was copied from a *different major* and never adapted. Small-miss count + duplicate package + zero consumers from the repo's own code = delete the block outright; do not chase the missing files.

#### A resource block is only half-done until it is reachable from the build

`android_resources` / `java_strings_grd` targets that exist but are in no other target's `deps` are **islands**: GN accepts them, `gn gen` succeeds, and their resources never reach the AAR. Porting the block faithfully is not enough — you must also wire it into the library that produces the artifact.

Check reachability for every block you port, by grepping the target name as a dep reference (distinct from its definition site):

```bash
# definition vs. reference sites — a target with a definition and no reference is an island
for t in webkit_glue_resources agree_content_resources; do
  grep -n "deps.*:$t" android_webview/BUILD.gn || echo "$t: UNREFERENCED"
done
```

Measured on agree→M119: `webkit_glue_resources`, `agree_embedder_support_resources` and `agree_content_resources` were all defined and all unreferenced, while `agree_ui_android_resources` was referenced only by an island — a whole disconnected chain. Only `:resources` reached `common_java`. The runtime symptom is the nastiest kind: the build succeeds, then `JsDialogHelper` / `FindActionModeCallback` crash on a missing resource id at runtime. So resolve islands before declaring the port done, and decide per island whether to wire it up or delete it.

#### The artifact target itself can be missing the repo's whole Java library

Grep islands **inside the `dist_aar` target's own `deps`**, not only in the tree-wide BUILD.gn. The nastiest version of this bug is the artifact target depending on the repo's helper libraries (`:copy_webkit_java`, `:copy_snapshot_blob`) but NOT on the `android_library` that holds the actual API implementation:

```bash
# the artifact's deps must contain the library that owns the repo's .java files
grep -n -A 40 'dist_aar("' BUILD.gn | grep -E ':(webkit_glue_java|copy_webkit_java)'
```

Measured on agree→M119: `dist_aar("webview_aar")` listed `:copy_webkit_java` and `:copy_snapshot_blob` but **not** `:webkit_glue_java` — the 58-file library that holds `WebView.java`, `JsDialogHelper.java`, `MyFindActionModeCallback` and friends. That library *did* declare `:webkit_glue_resources` in its own deps, so the resource wiring looked correct in isolation while the classes were guaranteed absent from the AAR. Two consequences from one missing line: no agree classes in `classes.jar`, and (because the resource dep hangs off that library) no resources either.

Acceptance test before packaging: the transitive dep closure of the artifact target must include a target whose `sources = [...]` covers the repo's `java/` files. A quick proxy: `ninja -C out/<dir> -n <aar-target> | grep -c '<pkg>/webkit/'` — zero means the API classes are not being compiled at all.

#### Prefixed (`agree_*`) target names are a rename signal, not a definition

When a ported `deps` entry names a target with the repo's own prefix, do not assume the port forgot to add the definition — check whether the target version has the **unprefixed** upstream equivalent, and repoint the dep instead of creating a duplicate. Resolving which one is right is a `grep` of the grd/grdp filename, not a guess from the name:

```bash
grep -rn 'android_ui_strings.grd' --include='BUILD.gn' ui/   # -> ui/android/BUILD.gn: java_strings_grd("ui_strings_grd")
```

Measured: `agree_ui_strings_grd` was referenced twice in `deps` and **defined nowhere** in the whole BUILD.gn, and the external repo shipped no `.grd`/`.grdp` at all — so it could never be created. The target it meant is M119's `//ui/android:ui_strings_grd` (same `java/strings/android_ui_strings.grd`). A `deps` reference to an undefined target is a hard `gn gen` failure (`target not found`), so this class of dangling reference is caught immediately — which is exactly why islands are the more dangerous of the two.

## Porting the repo's OWN `java/` and `BUILD.gn` (a separate phase from the patches)

On a major bump there are TWO porting surfaces, and the patchset is only the first:

| Surface | What it is | How to port |
|---|---|---|
| `patches/*.patch` | Edits to the **chromium tree** (`android_webview/glue`, `support_library`, `BUILD.gn`) | Section above — re-derive from `git diff` split by file type |
| repo `java/` + repo `BUILD.gn` | The **repo's own** API-shim sources and its target definitions | Never covered by the patches; verify against the target tree separately |

After the new patchset applies cleanly, the repo's own files are still unvalidated. Sweep them with three mechanical checks — all cheap, all catch real build blockers:

1. **Every `//path:label` dep in the repo's BUILD.gn must resolve in the target tree.** Grep the label inside the owning `BUILD.gn`. Expect false "missing" verdicts for targets defined via templates or generator macros — grep the macro name (`libwebviewchromium_tmpl`, `androidx_android_aar_prebuilt`, `mojom`, `_jni_registration`) before declaring a dep dead. In practice the genuinely-missing set is small and each one has a mechanical fix: a renamed/relocated dep, or a component that simply did not exist yet in the target major (delete it — nothing references it either).

2. **Every `org.chromium.*` / `org.jni_zero.*` import in the repo's java must exist in the target tree.** The jni-annotation package is the classic trap: annotation classes live under `org.chromium.base.annotations` in older majors and were relocated to `org.jni_zero` later, and they are provided by `//base:jni_java` — **not** `//base:base_java` and not a `jni_zero` java target. Find the owning target by grepping the annotation filename in `base/BUILD.gn`, then reading upward to the enclosing `java_library(`/`android_library(` line. Do not guess the target name from the directory.

3. **Every file the BUILD.gn lists must exist, and every new file must be listed.** Diff the `sources = [...]` list against the actual tree. Unlisted `.java` files compile-fail with missing-symbol errors; listed-but-absent files are usually a commented-out line that a naive regex counted (check for a leading `#` before treating it as a real gap).

### JNI generation: verify what `generate_jni` actually emits before "fixing" it

A repo that feeds its own java class into `generate_jni` and wires the result via `srcjar_deps` is **not** broken, even though the target name says `..._jni_headers`. In source mode (`sources = [...]`, not `classes = [...]`), the generator emits BOTH the C++ `_jni.h` and a `$target_name.srcjar` containing the generated `<ClassName>Jni.java` — `jni_generator.py` names the java stub `<fully-qualified-class>Jni.java`. Read the generator template's output section (`outputs +=`, `--srcjar-path`) before concluding a java-side JNI class is missing; that mistake costs a wasted rewrite.

The real gap to look for is elsewhere: **the native `.cc` implementations of those JNI methods may be referenced by no target at all.** Detect by listing the repo's non-`.java` sources and grepping each filename in the BUILD.gn — a `java/src/<feature>/*.{cc,h}` set with zero hits is dead weight and will `UnsatisfiedLinkError` at runtime. Wiring it in needs three coordinated edits, and the third is the one that is easy to miss:

- a native target (e.g. `source_set`) listing the sources, depended on by the library template that produces the `.so`;
- the JNI-registration list (in official WebView this is `webview_java_for_jni_targets`) must include the ported java target, or the registration never scans the ported classes;
- **`remove_uncalled_jni` must be disabled.** That flag strips JNI symbols present on the native side but unreferenced from the java side; an AAR/`dist_aar` build has a non-1:1 java↔native mapping, so leaving it on deletes precisely the symbols just wired in. This is a silent runtime failure, not a build error, and it is a change the ORIGINAL patchset usually already made — when re-deriving a patchset, diff the old patch against the new one for these commented-out toggles rather than assuming the new port captured them.

#### Derive the required directory layout from the `.cc` include paths, not from where the repo "looks like" it goes

Where a ported native source must be copied to is **not a free choice** — it is fixed by the literal `#include` strings inside those sources, because GN only puts `<gen>/jni_headers` and the tree root on the include path. Two include forms pin two different things:

```bash
# 1) tree-relative include of the source's own headers -> pins the COPY DESTINATION
grep -h '#include "android_webview/.*"' agree/java/src/draw_fn/*.cc
#    "android_webview/agree/java/src/draw_fn/allocator.h"
#    => the repo must be copied to src/android_webview/agree/ (NOT android_webview/java/)

# 2) generated-JNI include -> pins where the generate_jni target must LIVE
grep -h 'jni_headers/' agree/java/src/draw_fn/*.cc
#    "android_webview/agree/draw_fn_impl_jni_headers/MyDrawFunctor_jni.h"
#    => echo '<target_gen_dir relative to root_gen_dir>/<target_name>' must equal that path
```

For (2), `jni_zero.gni` sets `_jni_output_dir = "$jni_headers_dir/$_subdir/$target_name"` where `_subdir = rebase_path(target_gen_dir, root_gen_dir)` — i.e. the path mirrors the BUILD.gn's own directory. So an include of `android_webview/agree/draw_fn_impl_jni_headers/...` proves the `generate_jni("draw_fn_impl_jni_headers")` target must be defined in `android_webview/agree/BUILD.gn`. A repo whose BUILD.gn sits at its root but must deliver targets under `android_webview/agree/` has to be copied into that subdirectory wholesale — BUILD.gn included — or the generated header lands somewhere the `.cc` never finds it.

Do this derivation **before** writing the `source_set`; getting it backwards produces a `file not found` at compile time after a long configure, and the include string is a 5-second grep.

## The manifest is a porting surface too (third layer, invisible to GN and javac)

After patches and the repo's own `java/`+`BUILD.gn` are validated, the repo's hand-written `AndroidManifest.xml` is still unvalidated — and it is the surface where a ported mobile WebView most often ships something that builds fine and is dead on device. The target major does not keep a static manifest for this: WebView's is generated by `jinja_template` from `android_webview/nonembedded/java/AndroidManifest.xml` (driven by `android_webview/system_webview_apk_tmpl.gni`), so a static copy in the external repo was frozen at whatever major it was copied from and never tracked again.

Locate the template and diff against the repo's file:

```bash
grep -n 'jinja_template' -A 5 android_webview/system_webview_apk_tmpl.gni   # -> input = //android_webview/nonembedded/java/AndroidManifest.xml
```

| Item | Why it breaks | Fix |
|---|---|---|
| `android:exported` on `SandboxedProcessService*` / `JsSandboxService0` | The template sets `exported="true"` **plus** `android:externalService="true"`. With `false`, the system cannot `bindServiceAsUser` the sandboxed renderer process — pages render blank with no build error | match the template exactly |
| `NUM_SANDBOXED_SERVICES` + the service list length | Template emits **40** services (`{% set num_sandboxed_services = 40 %}` + a loop) with a matching `<meta-data>`. A hand-written file with 3 services caps concurrent renderers at 3; multi-WebView hosts starve | emit the full 40-service block, meta-data value included |
| `multiArch` / `extractNativeLibs="false"` | Miss `extractNativeLibs=false` and the `.so` is unpacked from the AAR instead of mapped | copy both attributes |
| `WebViewLibrary` meta-data | Some embedder libs probe `com.android.webview.WebViewLibrary` to detect the implementation | copy it |
| stale permissions (`RECORD_VIDEO` etc.) | `RECORD_VIDEO` is not a real permission (never existed in Android); `WRITE_EXTERNAL_STORAGE` is dead on 10+. Extra permissions trigger lint and scare integrators | prune to what the engine actually needs (`INTERNET`, `ACCESS_NETWORK_STATE`, `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS`, `CAMERA`, `WAKE_LOCK`) |

**Expand the 40-service loop mechanically, then assert it.** Hand-writing 40 near-identical `<service>` blocks invites an off-by-one that only shows up as a starved renderer under load. Generate them from a script, then verify three things before moving on — a mismatch between the meta-data count and the declared services is silent at build time:

```python
import re, xml.etree.ElementTree as ET
t = open("AndroidManifest.xml").read()
ET.fromstring(t)                                                         # 1) well-formed
svc = sorted(int(x) for x in re.findall(r'SandboxedProcessService(\d+)"', t))
assert svc == list(range(40)), svc                                       # 2) 0..39 contiguous
assert 'android:value="40"' in t                                        # 3) meta-data matches
assert t.count('exported="false"') == 0                                 # 4) none disabled
```

The contiguity assert matters: `re.findall` order is document order, so a dropped or duplicated index in the middle is invisible to a plain `len(...)` check.

The manifest `package` must equal the repo's java package root (`org.chromium.<name>`), which is also what the generated `R` class package is keyed off — verify with `grep -rh '^package ' java/src/ | sort -u` against the manifest's `package=`.

Service classes named in the manifest need **not** exist as files: `SandboxedProcessService0..N` are generated from `content/public/android/java/src/org/chromium/content/app/SandboxedProcessService.java`. A `find` that reports them missing is not evidence of a bad manifest — check for the template class before "fixing" a service name.

### Check `proguard.flags` is actually wired, not merely present

A repo that ships `proguard.flags` at its root but has **zero** references to it in `BUILD.gn` distributes no keep-rules in the AAR. `dist_aar` does not auto-pick it up; it must be named explicitly (`proguard_configs = [ "proguard.flags" ]`) on the target that produces the artifact.

```bash
grep -c 'proguard.flags' BUILD.gn    # 0 = not wired
```

This matters most for closed-source AAR delivery: without keep-rules the client's R8 strips the reflection/JNI-adjacent call points in Chromium, and the resulting NoSuchMethod/ClassNotFound failures surface only in the integrated app — not in this repo's own build.

## Pitfalls

- "The referenced targets still exist" is necessary but NOT sufficient — the patches that wire them together are the actual coupling, and only `git apply --check` reveals it.
- Missing deps in a newer checkout are not always fatal: some (e.g. old `com.android.support` annotations) are removed upstream and must be swapped for their androidx equivalent in the BUILD.gn — a small edit, but a real one.
- An AAR built for one Chromium version is not a drop-in for another; the engine ABI and API shims both shift between majors.
- Rejected hunk ≠ incompatible version. A reject whose diff body is pure import swaps is context drift; one that references files/APIs that don't exist at all in the target tree is real skew. Read the `.rej` content before declaring the port infeasible — and note that a single missing adjacent import line in the target (e.g. `ValueCallback` absent from M119's `ProfileBoundaryInterface`) is enough to fail a whole hunk that would otherwise apply cleanly.
- The ported repo's `java/` directory is mostly a copy of AOSP `frameworks/base/core/java/android/webkit/` — check the copyright headers before assuming it's hand-written. Sizing a port by "files touched" overcounts the work; sizing it by "files whose content is not upstream" is closer to the truth.
