# Fat (multi-ABI) builds: system WebView APK vs dist_aar

How to add arm32 support, and why it behaves differently per major and per packaging path.

## Host prerequisite for the 32-bit build: 32-bit glibc

The v8 generator host tools under `clang_x86_v8_arm/` (bytecode_builtins_list_generator, torque, gen-regexp-special-case) are i386 ELF binaries whose interpreter is `/lib/ld-linux.so.2`. On a 64-bit-only host they fail to exec mid-build, and the failure is MISLEADING: ninja shows a `FAILED:` edge and `v8/tools/run.py` raises `FileNotFoundError: ... '<tool>'` even though the file exists. Diagnose with `file clang_x86_v8_arm/<tool>` — "cannot execute: required file not found" = missing 32-bit loader. Fix: `apt-get install -y libc6-i386 lib32gcc-s1` (the second provides 32-bit libgcc_s; without it you get "error while loading shared libraries: libgcc_s.so.1"). Verify by executing the tool directly, then resume ninja — only the failed edges re-run. 64-bit builds never hit this (their host tools are x86_64).

## How the secondary (32-bit) ABI is gated — differs by Chromium major

Read the version's `build/config/android/abi.gni` before promising anything:
- M156: `enable_android_secondary_abi = is_official_build` — fat builds only under official builds.
- M132+: the secondary ABI is defined UNCONDITIONALLY for a 64-bit `target_cpu` (`android_secondary_abi_cpu="arm"`, `android_app_secondary_abi="armeabi-v7a"`); the arg that skips 32-bit is `skip_secondary_abi_for_cq` (default false = 32-bit gets built).

Secondary ABI only exists for 64-bit primaries (`arm64`→`arm`, `x64`→`x86`); you cannot fat-build from a 32-bit target_cpu.

## Where the 32-bit .so lands

Each toolchain gets its own output subdir — no collision with the 64-bit `.so`:
- 64-bit: `out/Aar/libwebviewchromium.so`
- 32-bit: `out/Aar/android_clang_arm/libwebviewchromium.so`

Don't guess the path — ask gn:
`gn desc out/Aar '//android_webview:libwebviewchromium(//build/toolchain/android:android_clang_arm)' outputs --toolchain=//build/toolchain/android:android_clang_arm`

## System WebView APK (fat)

With a 64-bit target_cpu, `system_webview_apk` aliases to the `_32_64` fat target and yields an APK with BOTH `lib/armeabi-v7a` and `lib/arm64-v8a`; `system_webview_64_apk` stays 64-bit-only. The APK template wires the 32-bit lib in via `secondary_abi_shared_libraries = [ "//android_webview:libwebviewchromium($android_secondary_abi_toolchain)" ]` (an android_apk-only option).

## dist_aar (WebView-as-AAR) is SINGLE-ABI — the gap

`build/android/gyp/dist_aar.py` requires `--abi` and drops every native lib into `jni/<abi>/`; it has no secondary-ABI option (that is android_apk-only). To ship a fat AAR:

### Implemented variant: `--abi-mapping` (single build, single AAR, M119 verified)

Instead of two builds + merge, teach `dist_aar.py` per-library ABIs. Add
`--abi-mapping` (a GN list of `"path/lib.so=abi-name"` entries; libraries not
listed fall back to `--abi`), parse it into `{normpath: abi}`, and inside the
native-library loop use
`abi = abi_mapping.get(os.path.normpath(lib)) or options.abi` as the `jni/<abi>/
` component. Relax the original guard
`if native_libraries and not options.abi` → `... and not options.abi_mapping`,
otherwise the mapping-only call is rejected. In `rules.gni`'s `dist_aar` template,
accept `abi_mapping` as a **list of scopes** (`{ lib = path, abi = name }`) and
expand it to `--abi-mapping=[...]` rebasing each `_lib.lib` via `rebase_path`;
keep `--abi=$android_app_abi` as the else branch
so existing targets are untouched. GN 2121's `foreach` does NOT iterate scopes
(the original scope-subscript form was replaced for this reason — the fix is
固化 in 002.build_gn.patch; a tree-side revert loses it and `gn gen` fails with
`rebase_path requires a list or a string`).

GN side — do NOT hardcode `$root_build_dir/arm/`. Ask gn
(`build/config/android/build_vars.gni:24-29` does exactly this):

```gn
_arm_lib = get_label_info("//base($android_secondary_abi_toolchain)", "root_out_dir") + "/libwebviewchromium.so"
native_libraries = [ "$root_out_dir/libwebviewchromium.so", _arm_lib ]
abi_mapping = [
  { lib = "$root_out_dir/libwebviewchromium.so", abi = "arm64-v8a" }
  { lib = _arm_lib, abi = "armeabi-v7a" }
]
```

Guard with `defined(android_secondary_abi_cpu)` (only 64-bit primaries have it)
and add `//android_webview:libwebviewchromium($android_secondary_abi_toolchain)`
to the dist_aar `deps`, or the 32-bit `.so` is never built and packaging fails on
a missing file. `get_label_info` requires a resolvable label — a made-up target
name errors out; `//base` is a safe stand-in since only its `root_out_dir` is read.

GN gotcha: you cannot subscript `invoker.x` directly (`May only subscript
identifiers`); assign `_m = invoker.abi_mapping` first. With the list-of-scopes
form, iterate `foreach(_lib, _m)` and read `_lib.lib` / `_lib.abi` — do not
re-introduce scope-subscript iteration (`_m[_lib]`), it is a runtime error.

Verification that needs no build tree: create two fake `libwebviewchromium.so`,
run `dist_aar.py --native-libraries=[...] --abi-mapping=[...]` with relative
paths (the depfile writer asserts `not os.path.isabs`), then assert the zip has
both `jni/arm64-v8a/` and `jni/armeabi-v7a/`. Omitting `--abi-mapping` must still
produce the original single-ABI layout.

### Alternatives (when you cannot patch the build scripts)

1. Add the 32-bit lib target to the dist_aar `deps`: `"//android_webview:libwebviewchromium(//build/toolchain/android:android_clang_arm)"` — this adds ~15k CXX edges (build time roughly doubles, plus disk).
2. Package: either patch `dist_aar.py` + the template to accept a secondary `--abi`/libs pair (mirroring create_apk's `--secondary-native-libs-dir`), or post-process the arm64 AAR by zip-merging the 32-bit `.so` into `jni/armeabi-v7a/`. The merge is sufficient: assets (paks/ICU/snapshot) and java are ABI-independent, only the `.so` differs, and its filename is unchanged so no `NativeLibraries.java` change.
3. Verify: list the AAR and confirm BOTH `jni/arm64-v8a/` and `jni/armeabi-v7a/` are present.

Adding 32-bit mid-build is incremental, not a restart: edit BUILD.gn deps, re-run `gn gen` (regenerates build.ninja with the new edges), resume `ninja` — the arm64 objects stay cached and only the 32-bit .so plus the repackaged AAR rebuild.

### Alternative for custom dist_aar targets: separate out dirs + zip merge

For a custom/rebranded `dist_aar` target, the same-dir dep approach above pollutes the primary build graph with ~15k extra edges and forces the 32-bit compile into the same out dir. The cleaner variant (what the agree custom target actually does) is two independent single-ABI builds, with NO BUILD.gn edit:

1. `out/Aar`   with `target_cpu="arm64"` → arm64 AAR (`jni/arm64-v8a`)
2. `out/AarArm` with `target_cpu="arm"`  → arm32 AAR (`jni/armeabi-v7a`), same sources
3. Merge: python3 zipfile — copy every entry of the arm64 AAR, overwriting/adding `jni/armeabi-v7a/libwebviewchromium.so` from the arm32 AAR. assets/pak/java are ABI-independent and the .so filename is unchanged → no `NativeLibraries.java` change. Save as `-fat.aar`.
4. Verify: list the fat AAR and confirm BOTH `jni/arm64-v8a/` and `jni/armeabi-v7a/` are present.

Cost: arm32 is a FULL build in its own out dir (all C++ recompiled for the second ABI) — same total CPU as the same-dir approach plus one extra `gn gen`.

**Never link both ABIs concurrently on a memory-constrained host** — each ThinLTO link is among the heaviest memory peaks in the build; two running at once exceed a 12-16G cap and get OOM-killed. Serialize the two builds (and delete debug out dirs between release builds if disk is tight).
