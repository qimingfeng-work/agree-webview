# R 类包名映射：GN custom_package vs AAR manifest package

## 机制

AGP 只为每个 AAR 的 **manifest package** 生成一个 R 类；GN 侧 `android_resources` 的 `custom_package` 决定编译期 R 类包名。两者不一致时，代码引用的 R 包在运行期不存在 → `NoClassDefFoundError`。

## M119 的具体缺口

| 项 | 值 |
|---|---|
| `webkit_glue_resources` 的 `custom_package` | `agree.webkit` |
| 代码引用（同包解析，import 被注释） | `agree.webkit.R`（`JsDialogHelper`、`FindActionModeCallback`） |
| 主 AAR manifest package | `agree.webkit`（R.txt 0 字节） |
| 4 个辅助 AAR package | `org.chromium.ui` / `org.chromium.content` / `org.chromium.android_webview` / `org.chromium.components.embedder_support.delegate` |
| `make_res_aars.py` 的分组 | `obj/android_webview/agree/webkit_glue_resources.resources.zip` 命中 `obj/android_webview/` 前缀 → 进 `android_webview` 组（package `org.chromium.android_webview`） |

→ `agree.webkit.R` **没有任何 AAR 提供**。

## 症状链（JS 对话框白屏）

```
渲染进程 prompt()
  → mojo → AwJavaScriptDialogManager::RunJavaScriptDialog
  → AwContentsClientBridge::RunJavaScriptDialog  [UI 线程]
      pending_js_dialog_callbacks_.Add(callback)
  → JNI handleJsPrompt → AwThreadUtils.postToCurrentLooper
  → JsResultHandler → glue WebViewContentsClientAdapter.handleJsPrompt
  → mWebChromeClient.onJsPrompt(...)
  → 返回 false → showDefaultJsDialog → JsDialogHelper.showDialog
  → R.layout.js_prompt  ← NoClassDefFoundError: org/chromium/android_agree/webkit/R$layout
  → receiver.cancel() 永不执行 → pending_js_dialog_callbacks_ 里的 callback 不会被 Run
  → 渲染进程 JS 一直挂起 → 白屏
```

`FindActionModeCallback`（查找操作栏）同理：`R.menu.webview_find` / `R.layout.webview_find` → 崩。

## 为什么不是死锁

- `onJsPrompt` 在 UI 线程被调（native 侧 `DCHECK_CURRENTLY_ON(BrowserThread::UI)` + `AwThreadUtils.postToCurrentLooper`）。
- `confirm()`/`cancel()` → `JsResultHandler` → `PostTask.runOrPostTask(TaskTraits.UI_DEFAULT)` → 同线程直接执行 → JNI → `AwContentsClientBridge::ConfirmJsResult`（UI 线程）→ `callback.Run()` → mojo 异步回渲染进程。
- 全链在 UI 线程、mojo 异步，无互相等待 → 不存在死锁。渲染进程 JS 挂起是 `prompt()` 的语义（等结果），不是 bug。

## 修复选项

| 方案 | 改动 | 评价 |
|---|---|---|
| A | 恢复 `JsDialogHelper.java` / `FindActionModeCallback.java` 里被注释的 `import org.chromium.android_webview.R;`；BUILD.gn 的 `webkit_glue_resources.custom_package` 改成 `org.chromium.android_webview`；给 `webkit_glue_java` 补 `//android_webview:resources` 依赖（否则编译期 R 类不在） | 改动小，但要动仓库源码 + 重编 Java |
| B（推荐） | `make_res_aars.py` 加第 5 个分组：把 `obj/android_webview/agree/webkit_glue_resources.resources.zip` 单独拆出，打成 package=`agree.webkit` 的辅助 AAR，宿主一起接入 | 与 GN 构建的 `custom_package` 一致，不动源码，只重打包 |

## 验证

- 编译产物常量池：解包主 AAR 的 classes.jar，找 `org/chromium/android_agree/webkit/R$layout`（`JsDialogHelper.class`、`FindActionModeCallback.class` 都有）。
- 运行期：logcat 搜 `NoClassDefFoundError`；若 App 自己实现 `onJsPrompt` 并调 `confirm()`，则搜 `Unexpected JS dialog confirm`（`aw_contents_client_bridge.cc` 的守卫日志，说明 `pending_js_dialog_callbacks_.Lookup(id)` 未命中）。
