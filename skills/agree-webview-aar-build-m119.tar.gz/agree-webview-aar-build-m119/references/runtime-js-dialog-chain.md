# JS 对话框运行链路与白屏排查（prompt/alert/confirm/beforeunload）

## 机制：渲染进程的 JS 线程是被「同步 mojo」冻结的

`third_party/blink/renderer/core/page/chrome_client_impl.cc` 的
`OpenJavaScriptPromptDelegate` / `OpenJavaScriptConfirmDelegate` / `OpenJavaScriptAlertDelegate`
都是 **synchronous mojo call**（源码注释原文）：

```cpp
// Synchronous mojo call.
frame->GetLocalFrameHostRemote().RunModalPromptDialog(..., &success, &result);
```

`prompt()` 打开期间，渲染进程主线程（JS 线程）一直阻塞，直到浏览器回复。
**"JS 线程卡住"是设计语义，不是 bug**；白屏 = 浏览器侧一直没回复。

## 完整链路（M119）

```
[渲染进程] RunModalPromptDialog（同步 mojo，阻塞）
  ↓
[浏览器 UI 线程] RenderFrameHostImpl::RunJavaScriptDialog (render_frame_host_impl.cc)
  GetProcess()->SetBlocked(true)                  ← 渲染进程被冻结
  → WebContentsImpl::RunJavaScriptDialog (web_contents_impl.cc)
    → AwJavaScriptDialogManager::RunJavaScriptDialog (aw_javascript_dialog_manager.cc)
      → AwContentsClientBridge::RunJavaScriptDialog (aw_contents_client_bridge.cc)
        pending_js_dialog_callbacks_.Add(callback)   ← 结果回调挂起
        JNI handleJsPrompt
  → AwContentsClientBridge.handleJsPrompt (AwContentsClientBridge.java)
    AwThreadUtils.postToCurrentLooper(...)        ← 确保 UI 线程、无 native 栈
  → WebViewContentsClientAdapter.handleJsPrompt
    mWebChromeClient.onJsPrompt(...)              ← App 回调
  ↓  App result.confirm(...) / cancel()
  → JsResult.wakeUp → JsPromptResultReceiverAdapter.onJsResultComplete
  → JsResultHandler.confirm/cancel (JsResultHandler.java)
    PostTask.runOrPostTask(TaskTraits.UI_DEFAULT, ...)   ← UI 线程
  → AwContentsClientBridge.confirmJsResult/cancelJsResult
  → native ConfirmJsResult/CancelJsResult (aw_contents_client_bridge.cc)
    pending_js_dialog_callbacks_.Lookup(id)       ← 关键守卫
    callback.Run(success, prompt_text)
  → CloseDialogCallbackWrapper::Run → WebContentsImpl::OnDialogClosed
  → RenderFrameHostImpl::JavaScriptDialogClosed
    GetProcess()->SetBlocked(false)
  → mojo 回复 → 渲染进程 RunModalPromptDialog 返回 → JS 恢复
```

## 链路本身没有死锁

- `onJsPrompt` 在 UI 线程被调（native 侧 `DCHECK_CURRENTLY_ON(BrowserThread::UI)` + `AwThreadUtils.postToCurrentLooper`）。
- `confirm/cancel` 经 `PostTask(TaskTraits.UI_DEFAULT)` 同线程直接执行；mojo 回复是异步的。
- 全链在 UI 线程、无互相等待 → 不存在死锁。

## 结果丢弃的守卫（任一命中 → 白屏）

| # | 守卫 | 位置 | 日志特征 |
|---|---|---|---|
| 1 | App 的 `onJsPrompt` 没调 confirm/cancel（返回 true 但没调） | App 代码 | 无 |
| 2 | App 的 `onJsPrompt` 抛异常（glue 的 handleJsPrompt 无 try-catch） | `WebViewContentsClientAdapter.handleJsPrompt` | AndroidRuntime / JNI 异常 |
| 3 | `pending_js_dialog_callbacks_.Lookup(id)` 未命中 | `aw_contents_client_bridge.cc` | `Unexpected JS dialog confirm/cancel` |
| 4 | `mNativeContentsClientBridge == 0`（bridge 已销毁） | `AwContentsClientBridge.java` | 无（静默 return） |

另：App 返回 false 走默认对话框时，`JsDialogHelper.showDialog` 的 R 类若缺失会崩（见 references/rclass-package-mismatch.md），`receiver.cancel()` 不执行 → 同样白屏。

## 排查命令

```bash
adb logcat | grep -iE "Unexpected JS dialog|onJsPrompt|AndroidRuntime|AwContentsCB|JsResultHandler"
```

- 命中 `Unexpected JS dialog confirm` → 守卫 3（回调 id 丢失：bridge 重建 / 对话框被提前 Cancel）。
- 命中 `AndroidRuntime` + `onJsPrompt` 栈 → 守卫 2（App 异常）。
- 都没有 → 先确认 App 的 `onJsPrompt` 是否真的调了 confirm/cancel（守卫 1）。
