# Carrying a source tree to the build host (migrating between machines)

Use when a tree was prepared on one machine (typically macOS, which cannot build Android targets) and the actual build will happen on another (Linux cloud host, or a fresh local checkout). The goal is to carry the irreplaceable work and let the target machine re-derive the rest.

## Classify first: regenerable vs irreplaceable

| Content | Typical size | Carry it? | Why |
|---|---|---|---|
| `.gclient` + `.gclient_entries` | ~80 KB | **Yes — mandatory** | Pins every DEPS revision. Without them the new tree resolves different versions and patch porting work is invalidated. |
| The custom patch set + custom `java/` sources | a few MB | **Yes — mandatory** | Original work, not re-downloadable. |
| Hand-written porting/verification scripts | a few KB | **Yes** | Same reason; also record the command lines actually used. |
| Local source modifications (Java downgrades, applied patches) | a few MB | **Yes** | Original work. |
| `src/` git-tracked content | ~27 GB | Optional | Platform-independent, but re-downloading costs hours. Worth carrying when upload bandwidth is good. |
| `depot_tools/` | ~744 MB | **No** | Python scripts + platform binaries; re-cloning on the target takes ~2 minutes and avoids stale/broken shims. |
| `src/third_party/android_toolchain/ndk/` | ~764 MB | **No** | Toolchain is host-specific and is frequently present-but-truncated (see `sync-recovery.md`). Re-sync it. |
| `.cipd/` | small | **No** | Pure cache, rebuilt on next sync. |
| `out/` | tens of GB | **No** | Platform-and-config specific; also required to keep alongside AAR backups when you need to re-add assets — see the parent SKILL.md pitfall. |

## Restoring on the target machine

```bash
# 1. depot_tools (always fresh, never copied)
git clone https://chromium.googlesource.com/chromium/tools/depot_tools.git
export PATH="$PWD/depot_tools:$PATH"
export DEPOT_TOOLS_UPDATE=0

# 2. restore pinned deps metadata BEFORE the first sync
mkdir chromium && cd chromium
gclient config --unmanaged https://chromium.googlesource.com/chromium/src.git
tar xzf /path/to/meta.tar.gz        # .gclient + .gclient_entries

# 3a. either re-sync from scratch (slow, small upload)
gclient sync -D --no-history -j8

# 3b. or unpack the carried src/, then sync only the gaps (fast, big upload)
tar xzf /path/to/src.tar.gz         # restore src/ without the ndk/ subdir
cd src && git checkout -- .
cd .. && gclient sync -D --no-history -j8   # backfills NDK + anything missing
```

Branch 3a and 3b are interchangeable; pick by upload bandwidth. Branch 3b always ends in a `gclient sync` anyway, because the NDK was deliberately excluded.

## Verify before applying ports or starting the build

1. `SYNC_EXIT=0` and the sync process has exited.
2. NDK structurally complete — `bin/` has `clang`/`clang++`/`lld`, `sysroot/usr/include/` has thousands of entries (see `sync-recovery.md`). A present-but-truncated NDK passes every size check and fails at `gn gen`/compile time.
3. `git status --short` on `src/` shows only the intended local modifications.
4. `gn gen` on the target out dir before committing to a multi-hour build — it is seconds and catches a broken toolchain immediately.

## The absolute minimum set (when the user asks "what is the smallest backup")

The table above is the *safe* answer. The **mathematically minimum** set is smaller, and the difference matters because users often assume `.gclient_entries` alone pins the tree — it does not.

`.gclient_entries` records **dependencies**, not the main repo. Its `'src'` key holds only the URL, with **no `@revision`** — compare the sibling entries, which all carry `@<hash>`. So the main tree's version lives nowhere in that file. It lives in `src/.git/HEAD`, which is lost when you copy only the metadata files.

Minimum set (a few MB):

| Item | Note |
|---|---|
| `git rev-parse HEAD` output from `src/` | **the one truly mandatory item**; without it the target resolves `main` and the entire target-version premise evaporates |
| The custom repo / patch set + local modifications | original work |
| (optional) `.gclient_entries` | falls out of `gclient sync --revision src@<hash>` anyway |

`.gclient` itself is one command to rebuild, and `gclient sync --revision src@<hash>` recomputes every dep revision from DEPS — which is exactly why `.gclient_entries` is redundant here.

```bash
# on the source machine
cd src && git rev-parse HEAD > src_commit.txt

# on the target
 gclient config --unmanaged https://chromium.googlesource.com/chromium/src.git
 gclient sync --revision "src@$(cat src_commit.txt)" -D --no-history -j8
```

**Prerequisite to state explicitly**: the hash must exist on the remote. A `--no-history` shallow clone of a clean upstream commit is fetchable; a commit that only exists locally (rebased, cherry-picked, amended) is *not*, and the target sync will fail. Check with `git log -1 --format='%H %ci'` and confirm the tree is clean (`git status --short` empty) before promising this works.

## Pitfalls

- **`/tmp` is not a backup location.** Reference material and generated sources staged under `/tmp` disappear on reboot or cleanup. Collect everything worth keeping into one durable directory before packing.
- **Never pack `src/third_party/android_toolchain/ndk/`** — carrying a truncated toolchain across machines propagates a silent failure that surfaces hours later at link time.
- **AOSP reference snapshots ARE worth carrying** even though they never participate in compilation. They are per-file downloads from specific AOSP branch tags — re-fetching them means re-discovering which tags and which class list you compared. A few MB. Keep them labelled as reference-only so nobody mistakes them for replaceable source (they are not — see the parent skill's note that replacing agree's classes with AOSP's breaks the JNI contract with the `.so`).
- **Do not pack `depot_tools/`.** Copied trees carry platform-specific entry points and skip the target's bootstrap; a stale copy produces confusing `python3_bin_reldir.txt`-class errors.
- **`.gclient_entries` is only meaningful as an input**, never as proof a sync finished; restore it, don't verify with it.
- **A `--no-history` tree cannot `git apply --3way`** (blobs absent) and silently falls back to a plain apply — plan on `--reject` plus semantic redo instead.
- **Sanity-check the target host against the hardware bar before migrating**: Android Chromium builds want 16 GB+ RAM *for the build itself* and ~145 GB free disk leaves too little margin for a 27 GB tree plus 40–60 GB of `out/`. A VM carved out of a 16 GB machine gives the build ~10 GB and will OOM or crawl — migrating to it is not the cheap option it looks like.
- **The host-OS gate comes first**: macOS cannot build Android Chromium targets at all (see the parent SKILL.md hard-limit section). Migrating the tree is the fix; retrying parameters on macOS is not.
