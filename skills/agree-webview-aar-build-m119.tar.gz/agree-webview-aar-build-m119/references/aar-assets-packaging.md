# agree AAR: dist_aar omits assets/ — packaging fix

Applies to any `dist_aar`-based WebView AAR (e.g. the agree project: `dist_aar("webview_aar")` in `android_webview/BUILD.gn`, package `agree.webkit`, output `agree.webkit.webview-v1.0.0.aar`).

## Why the AAR ships without assets

`dist_aar` (`build/config/android/rules.gni` + `build/android/gyp/dist_aar.py`) packages exactly: `classes.jar`, `R.txt`, `proguard.txt`, `AndroidManifest.xml`, `res/` contents of dependency res zips, and `jni/<abi>/<so>`. It has NO assets code path (grep the whole file: nothing reads `android_assets` build configs). So the `//android_webview:pak_file_assets`, `//android_webview:locale_pak_assets`, `//third_party/icu:icu_assets`, `:copy_snapshot_blob` deps get BUILT by ninja but their outputs never enter the AAR. A missing-assets AAR is the template's fixed behavior, NOT a BUILD.gn omission — the upstream agree BUILD.gn has the same deps and its release AAR only has assets because the author merges them in an un-published build step (the repo holds only BUILD.gn + java + assets/, no CI config).

## Why the host app crashes

WebView init hardcodes APK-assets loads in `android_webview/common/aw_resource_bundle.cc`:
- `ui::LoadMainAndroidPackFile("assets/resources.pak", ...)` — assets ROOT (not a subdir)
- locale paks from `assets/stored-locales/` (`ui::SetLocalePaksStoredInApk(true)`)
- renderer side also takes `assets/chrome_100_percent.pak`; icudtl.dat and v8 snapshots live there too.

AAR `assets/` merges into the host app's APK assets on gradle packaging. Missing them = `ResourceBundle` init failure = crash on launch.

## Fix: merge assets after every build

Run after EVERY `ninja <target>_aar` (and on any merged allabi AAR):

```bash
python3 /root/scripts/add_aar_assets.py --aar <AAR> --out <build_out_dir>     # in place
python3 /root/scripts/add_aar_assets.py --aar <AAR> --out <build_out_dir> -o <copy>
# e.g.
python3 /root/scripts/add_aar_assets.py --aar out/AarRelease/agree.webkit.webview-v1.0.0.aar --out out/AarRelease
```

Idempotent (skips entries already present). Canonical copy: this skill's `scripts/add_aar_assets.py`; the host working copy at `/root/scripts/` may lag — prefer the skill copy.

## Asset manifest (arm64 == upstream release layout, 86 entries / ~10.4 MB)

| out/ source | AAR entry |
|---|---|
| `gen/android_webview/chrome_100_percent.pak` | `assets/chrome_100_percent.pak` |
| `gen/android_webview/resources.pak` | `assets/resources.pak` |
| `icudtl.dat` | `assets/icudtl.dat` |
| `gen/android_webview/snapshot_blob_64.bin` | `assets/snapshot_blob_32.bin` (arm32) / `assets/snapshot_blob_64.bin` (arm64) — per-ABI trap below |
| `v8_context_snapshot_64.bin` | `assets/v8_context_snapshot_64.bin` |
| `android_webview/locales/*.pak` (81) | `assets/stored-locales/*.pak` |

- All entries must be STORE (compress_type 0) — matches upstream; .pak/.bin get mmap'd, compression breaks them.
- arm32 (`target_cpu="arm"`): NO `v8_context_snapshot` — `use_v8_context_snapshot` is off for 32-bit (verify in `gen/tools/v8_context_snapshot/buildflags.h`), so a context-snapshot asset is not required and its absence is not a defect. BUT the main snapshot entry MUST be named `assets/snapshot_blob_32.bin`; an arm32 AAR whose only snapshot is named _64 still crashes V8 init (85 assets is the complete set only with the _32 name — see the per-ABI trap below).
- v8 snapshots (`snapshot_blob_64.bin`, `v8_context_snapshot_64.bin`) are BUILD-SPECIFIC: always use the local out/ copies, never the upstream release's. Sizes legitimately differ from the upstream AAR (e.g. 79092 vs 79197); a mismatched snapshot crashes the renderer even when assets are present.

## The per-ABI snapshot naming trap (32-bit crash)

`gen/android_webview/snapshot_blob_64.bin` is a FIXED NAME for every arch: the
`copy_snapshot_blob` target in `android_webview/BUILD.gn` copies the build's
arch-specific `snapshot_blob.bin` to that _64-named path. Its CONTENT follows
the build arch; its NAME does not. The asset name a process actually reads is
decided by the process arch: `content/app/content_main_runner_impl.cc` maps
`__LP64__` (compile time) to descriptor `v8_snapshot_32_data` or
`v8_snapshot_64_data`, and `content/browser/v8_snapshot_files.cc` binds those
to `assets/snapshot_blob_32.bin` / `assets/snapshot_blob_64.bin` exactly. A
32-bit process reads ONLY `assets/snapshot_blob_32.bin`; if it is absent
`gin/v8_initializer.cc` logs `FATAL: Error loading V8 startup snapshot file`.
Both `_32` and `_64` path strings are compiled into EVERY .so — finding them
in the binary proves nothing about which name the runtime requests; check the
buildflags and the descriptor selection instead.

Identification rule: a snapshot file's real content is decided by MD5 against
`out/<dir>/snapshot_blob.bin`, NEVER by its _32/_64 name or by comparing sizes
across builds (arm32 blob 82791 B vs arm64 blob 79092 B here — legitimately
different). Renaming a misnamed blob is safe ONLY when its MD5 matches the out
dir of the same arch; a genuinely wrong-arch blob crashes on load (format
mismatch) — it does not fall back to the other name.

Minimal fix without rebuilding (Python zipfile, no unzip binary; back the AAR
up first, then verify with `z.testzip() is None` + MD5 of the blob vs its
build source):
- arm32-only AAR: RENAME the `assets/snapshot_blob_64.bin` ENTRY to
  `assets/snapshot_blob_32.bin` (mutate `ZipInfo.filename`, keep compress_type
  STORE and the bytes) — the content is already the arm32 blob.
- allabi AAR: ADD `assets/snapshot_blob_32.bin` from the ARM out dir's
  `snapshot_blob.bin` and keep `_64` — in an allabi built from an arm64 dir the
  `_64` entry is the genuine arm64 blob, so renaming THAT one would not work.
- arm32 never needs `v8_context_snapshot_32.bin` (buildflag off).

The skill's `scripts/add_aar_assets.py` now names the snapshot per-ABI itself
from `out/args.gn` `target_cpu` (arm32 → `_32`, drops a stale `_64` entry;
arm64 → `_64` + context). After editing the skill copy, also copy it over
`/root/scripts/add_aar_assets.py`, the path the project's documented
invocation uses.

## Verification

Python zipfile (no unzip binary needed): `z.namelist()` asset count, `z.testzip() is None` for integrity, and sha256 of `assets/resources.pak`/`icudtl.dat`/`chrome_100_percent.pak` against a known-good reference AAR — those three are content-stable across builds; the two v8 snapshots are NOT and must not be compared.

## Host-app requirements

- The embedding app's build.gradle MUST set `androidResources { noCompress 'bin', 'pak' }` (upstream agree README), or the assets are deflated in the APK and WebView's mmap load fails even with assets present.
- Keep the build out dir: a stale AAR backup with no matching out dir cannot be patched (no source files to merge). Debug AARs need their own build dir; don't expect to patch a debug AAR from a release out dir (v8 snapshot abi/file names differ).
