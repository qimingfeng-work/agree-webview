# Sync recovery playbook

When the standard `gclient sync` cannot complete — OOM kills, killed git fetches, or network that is slow/broken to googlesource.

## gitiles-archive snapshot (replaces a full src git fetch)

A gitiles `+archive` tarball contains every file tracked in the src repo at that ref, but NOT the DEPS-managed deps (v8, boringssl/src, angle, …) — those still come from `gclient sync`. This avoids git pack generation on the server entirely, so it survives where a fetch dies.

1. Download: `https://chromium.googlesource.com/chromium/src/+archive/<ref>.tar.gz` (a tag like `156.0.8078.25` or a branch) — ~1.4 GB.
2. Extract into `src/`, then snapshot it (no history) — MANDATORY, not cosmetic:
   ```
   cd src && git init -q && git add -A && git commit -q -m "snapshot"
   ```
   gclient requires the solution dir to BE a git repo: with no `.git` present, `gclient sync` clones the full `chromium/src.git` into a `_gclient_src_*` staging dir even with `"managed": False` in .gclient — tens of GB, exactly the download the archive was meant to avoid. If you already started sync: stop it, `rm -rf <checkout>/_gclient_src_*`, git-init the extraction, re-run. (Commit is ~490k files / a few minutes; harmless LF/CRLF warnings.)
3. Run `gclient sync` on top to pull all DEPS deps into place.

Signs this path is needed:
- `git fetch --depth=1 origin <sha>` fails with `fatal: Cannot fetch both <sha> and refs/tags/<name> to refs/tags/<name>` — a tag-name collision with an existing ref; fetch to a bare ref (`... <sha>`) and `git update-ref refs/tags/<name> FETCH_HEAD` instead.
- Fetch killed mid-transfer (`error: git-remote-https died of signal 15`, `early EOF`, `invalid index-pack output`) — the server-side pack for a full src fetch can exceed available RAM.

## Stuck per-dep fetch (VK-GL-CTS is the classic)

gclient logs `Still working on: <dep>` for many minutes then the whole sync gets OOM-killed. Fetch the pinned SHA manually with a retry loop, then re-run `gclient sync` — it resumes the rest:

```
cd <dep-dir>            # e.g. src/third_party/angle/third_party/VK-GL-CTS
for i in $(seq 1 15); do
  git fetch --depth=1 origin <sha> && { git checkout -q -B main FETCH_HEAD; exit 0; }
  sleep 10
done
```

Before re-running sync, delete any `_gclient_src_*` staging dirs an interrupted sync left inside deps — otherwise `gclient sync` refuses with "uncommitted changes".

## Completeness verification after a "successful" sync

Do not trust the sync's own output, and **do not trust `.gclient_entries`** — gclient writes it *before* syncing starts, so it exists (fully sized) while src is still only a few GB. Confirm: the sync process exited with `SYNC_EXIT=0`, and the NDK is not just present but structurally complete (see next section).

## The NDK can be present-but-truncated — never judge it by `du` or by the directory existing

The CIPD package `chromium/third_party/android_toolchain/android_toolchain` unpacks a large file tree; an interrupted or failing unpack leaves `third_party/android_toolchain/ndk/` at a plausible-looking size (measured: 764 MB) while the toolchain itself is missing. That size looks like success and is not.

Probe the two paths that actually matter, not the directory:

```
ls third_party/android_toolchain/ndk/toolchains/llvm/prebuilt/linux-x86_64/bin/
ls third_party/android_toolchain/ndk/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include/ | wc -l
```

Healthy = `bin/` holds the real toolchain (`clang`, `clang++`, `lld`, `ar`, `strip`, …) and `sysroot/usr/include/` holds thousands of entries. Truncated = `bin/` holds only `lldb` and `lldb.sh` (~2 files) and `include/` holds a few dozen directories (measured: 53).

Consequences: a truncated NDK **must not be copied to another machine** — the copy is equally broken because the files were never there. Let the target machine's `gclient sync` re-fetch it. Conversely, a source tree whose only defect is the NDK is still worth carrying across, since everything else is complete and platform-independent.
