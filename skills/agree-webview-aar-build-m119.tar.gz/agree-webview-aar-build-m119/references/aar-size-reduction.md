# agree AAR 体积优化（编译与打包角度）

dist_aar 产物默认全部 STORE（未压缩），AAR 体积 ≈ 各 entry 之和。实测构成（M119 双 ABI，主 AAR 238.5 MiB）：

| 部分 | 大小 | 占比 |
|---|---|---|
| `jni/arm64-v8a/libwebviewchromium.so` | 119.1 MiB | 50% |
| `jni/armeabi-v7a/libwebviewchromium.so` | 67.5 MiB | 28% |
| `classes.jar`（14566 个类，未 R8） | 41.4 MiB | 17% |
| `assets/`（86 项） | ~9.8 MiB | 4% |

arm64 `.so` 内部：`.text` 77.9 MiB、`.eh_frame`+`.eh_frame_hdr` 21.0 MiB、`.rodata` 8.7 MiB、`.rela.dyn` 3.8 MiB。arm32 对应 `.text` 50.8 MiB、`.ARM.exidx` 3.3 MiB。`.so` 已 strip（无 `.debug_*`/`.symtab`，只有 `.dynsym`），体积大头是代码与 unwind 表。

## 编译参数（要 gn gen + 全量重编，约 7h）

| 方案 | 收益 | 代价 |
|---|---|---|
| `exclude_unwind_tables = true`（写进 args.gn） | **省 ~25 MiB（10%）** | crash 栈回溯降级：`NO_UNWIND_TABLES` + frame-pointer 回退。Chromium 在 Android 上默认保留 unwind 表就是为了让 debuggerd 的 crash dump 有用 |
| 去 `-fno-omit-frame-pointer` | 省 ~2-4 MiB | profiling/栈回溯受影响 |
| `-flto=thin` → `-flto=full` | 省 ~5-10 MiB | 链接时间数倍 |
| 去 `-fstack-protector` / `-mbranch-protection` | 省 ~2-3 MiB | 安全性下降 |

**`exclude_unwind_tables` 的覆盖方式**：它在 `build/config/compiler/compiler.gni` 里是**普通赋值（非 declare_args）**，默认 `is_official_build && !is_android`（Android 恒 false）。但**在 args.gn 里直接写 `exclude_unwind_tables = true` 可以覆盖它**（实测 gn gen 通过，且 cflags 出现 `-fno-unwind-tables -fno-asynchronous-unwind-tables -DNO_UNWIND_TABLES`）。改完必须 `gn gen` + 全量重编（cflags 变，所有 .o 失效）。验证生效：`grep NO_UNWIND_TABLES out/AarRelease/toolchain.ninja`。

## 打包压缩（不重编，几分钟）

实测 DEFLATE（zipfile compresslevel=9）压缩率：

| entry | 现在 | DEFLATE 后 | 省 |
|---|---|---|---|
| `classes.jar` | 41.4 MiB | 7.8 MiB | 33.6 MiB（14%） |
| arm64 `.so` | 119.1 MiB | 46.1 MiB | 73.0 MiB |
| arm32 `.so` | 67.5 MiB | 37.2 MiB | 30.3 MiB |

- **classes.jar 压缩无副作用**（AGP 集成时重新 dex），立即可做。
- **`.so` 压缩有硬约束**：APK 内 .so 压缩后，宿主必须设 `android:extractNativeLibs="true"`（或 AGP `androidResources { useLegacyPackaging true }`），否则系统直接 mmap APK 内 .so 会失败。minSdk 24 下两种加载方式都可行，但要在交付说明里写清楚。
- **assets/*.pak|bin 必须保持 STORE**（mmap 加载），别压。
- 用 `scripts/recompress_aar.py` 执行（只压 `.so`/`.jar`/`.dex`，其余保持原压缩方式）。

## 其他

- 只出 arm64：省 67.5 MiB（28%），失去 32 位支持。
- `classes.jar` 做 R8：dist_aar 模板**不跑 R8**（只把 `proguard.txt` 随包给宿主），14566 个类原样进 AAR；加 `dist_dex` 步骤预计省 25-30 MiB。
