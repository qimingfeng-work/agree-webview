---
name: agree-webview-aar-build-m119
description: "Use when building the agree WebView AAR on Chromium M119."
version: 2.8.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [chromium, webview, aar, agree, android, gclient, ninja]
---

# agree 定制 WebView AAR 构建全流程（Chromium M119 基线）

自包含版：已把原 chromium-android-builds 与 chromium-webview-aar-resources 两个技能的全部内容整合进本文与 references/、scripts/，可直接交给任何 agent 独立执行。

把官方 Chromium **119.0.6045.214** 变成可集成进任意 App 的 WebView AAR SDK（非系统 WebView provider）：内核 libwebviewchromium.so 打进 AAR 的 jni/<abi>/，宿主 App 直接加载；API 包为 agree.webkit.*（import 替换 android.webkit.*）。交付形态是 5-AAR 拆包：主 AAR（arm64+arm 双 ABI 单包）+ 4 个辅助纯资源 AAR。目标最低 Android 7（API 24，M119 的 default_min_sdk_version=24 原生默认，不用改 gn 参数）。

**按 Chromium 大版本分技能是本用户的交付约定**：升到下一个大版本（如 M126+）时新建独立技能，不改写/混入本技能，保持各版本数据互不干扰。M132 版技能已按用户决定删除（M132 构建不再保留），本技能是当前唯一的构建技能。

## When to Use

- 重新构建/发布 M119 版 agree AAR（改代码、改版本号）
- 换机器或环境重建 M119 构建链
- 排查产物缺陷（缺 assets、R.txt 空、无 res/、32 位崩溃）
- **用户报 JS 对话框白屏 / `onJsPrompt` 没回调 / JS 线程卡住** → 先读 references/runtime-js-dialog-chain.md：渲染进程的 `RunModalPromptDialog` 是**同步 mojo**（JS 线程被冻结是 `prompt()` 的设计语义），白屏 = 浏览器侧没回复；按该文的 4 个"结果丢弃"守卫逐个排查
- **用户报"产物不支持低于 Android X 的设备"** → 先读 references/min-sdk-and-platform-support.md 定位限制在哪一层（App minSdk / AAR manifest / **Java glue 隐藏 API** / 内核 NDK api level），**别直接重编**：AAR 不携带 minSdk，重编数小时很可能不解决问题
- **用户要求改 API 包名 / `webview_aar` target 名** → 读 references/package-rename.md：先确认目标包名（可能是父包 + 类名，如 `agree.webkit` + `WebView` 类），再按文件面清单执行；改包名必然重链双 ABI .so
- **用户要求"重写支持另一个 Chromium 大版本的 patch"** → 走 references/evaluating-external-build-repos.md 的 "Producing a new patchset" 段（本技能的 patches/ 就是该流程的产物）；验收关口是 gn gen（见 Pitfalls）
- **patch 打完不等于移植完成**：agree 还有两个未被 patch 覆盖的移植面——仓库自己的 `java/` 源码与仓库根 `BUILD.gn`。按 references/evaluating-external-build-repos.md 的 "Porting the repo's OWN `java/` and `BUILD.gn`" 做三项机械扫描（依赖 label 解析 / `org.chromium.*`+`org.jni_zero.*` import 存在性 / sources 与文件双向对齐）再谈交付。**GN 扫描通过后还有两类「静默」缺口要单独查**：定义了但没人 `deps` 的资源/原生 target（孤岛，`gn gen` 不报错、产物里就是没有，崩在运行期）与拷贝目的地/`generate_jni` 所在目录（由 `.cc` 的 `#include` 字面量反推，见 references 的 "Derive the required directory layout from the `.cc` include paths"）。**孤岛检查要一路查到 artifact target 自己的 `deps`**：`dist_aar` 列出了辅助库却漏掉 `android_library("webkit_glue_java")` 时，资源接线看起来正常而 AAR 里根本没有 API 类——判据与验收命令见 references 的 "The artifact target itself can be missing the repo's whole Java library"
- **`generate_jni` 同时产 `_jni.h` 和 `<target>.srcjar` 里的 `<类名>Jni.java`**（source 模式）：看到 `srcjar_deps` 指向名为 `..._jni_headers` 的 target 并不是 bug，别急着重写。真正要查的是 native `.cc` 实现有没有被任何 target 编译，以及 `remove_uncalled_jni` 是否还开着（开着会把这些 JNI 符号静默剥掉，运行期 UnsatisfiedLinkError）
- **移植面的第三层是仓库根的手写 `AndroidManifest.xml`，GN 扫描和 javac 扫描都看不见它**：`dist_aar` 的 `android_manifest` 直接吃这个文件。M119 移植已核对：`exported` 改 true + externalService（系统 bindServiceAsUser 拉起 renderer，false 白屏）、`NUM_SANDBOXED_SERVICES` 3→40。逐项对比方法见 references/evaluating-external-build-repos.md 的 "The manifest is a porting surface too"
- **`proguard.flags` 躺在仓库根 ≠ 已生效**：`dist_aar` 不会自动拾取它，必须在目标定义里显式 `proguard_configs`。0 处引用就是混淆规则没随 AAR 分发，客户端 R8 会把 Chromium 的反射调用点剥掉——这类闭源交付场景属于硬需求，扫 manifest 时一并 grep 一遍
- **用户说"是 AOSP 导入的那批 Java 代码导致的"时，先分清是哪一批**：agree 自研的 `agree.webkit.*`（运行代码 0 处 `SDK_INT` 门控，基本兼容低版本）≠ `com.android.webview.chromium.*` glue 层（用 `android_system.jar` 私有 SDK，隐藏 API 运行期才炸）。后者才是"编译期静默"的限制层，patch 校验与编译都发现不了。注意：自研 API 层里**53/57 个文件本身就是 AOSP 拷贝**（约 13.5k 行），真正的原创只有 `draw_fn` 的 971 行 C++ + 66 行 `MyDrawFunctor.java`——评估移植量时别把拷贝当自研
- **没有构建机、不想重编内核，但需要产物兼容更低 Android 版本** → 走 references/min-sdk-and-platform-support.md 方案 D：本机 `javac` + 目标 API 的 `android.jar` 全量扫描 + 隔离类门控 + 只替换改动类的 AAR 重打包，全程不需要 Chromium 构建树
- **拿不到目标设备崩溃栈之前不要动 glue 层**：`NoSuchMethodError` 栈顶在 `com.android.webview.chromium.*` → 改 Java（方案 D，先换公开 SDK 重编拿全量编译错误清单）；栈在 native → 改 gn 参数（方案 A）；装不上 → 改 App minSdk（方案 C）。三条路成本差一个数量级，别猜
- **评估某台机器能否编译 Chromium（macOS/ARM/内存不足）** → 见"硬性限制：macOS host"段与 references/min-sdk-and-platform-support.md 的方案对比表

配套技能：**消费侧**（把已建好的 AAR 集成进 App、R 类/5-AAR 拆包的 AGP 机制、装机验证）——本技能内已含 references/rclass-package-mismatch.md（R 类包名 / 5-AAR 机制）与 references/runtime-js-dialog-chain.md（运行期排查）；本技能只负责构建与打包。

## 产物与关键路径

- 源码树：/root/chromium119（.gclient 固定 119.0.6045.214，managed=False）
- 定制仓库：/root/agree-webview（git clone https://github.com/qimingfeng-work/agree-webview；**M119 构建修正已固化在仓库（含补丁与自研源码）**，clone 后直接用）
- 构建目录：out/AarRelease（**单 out 双 ABI**：target_cpu="arm64" + webview_aar 的 abi_mapping 一次产出 arm64-v8a + armeabi-v7a）
- 构建启动：systemd-run --unit=agree119（日志 /root/chromium119/aar_build.log）
- 打包脚本：本技能 scripts/ 为权威副本（add_aar_assets.py / assemble_aar.py / make_res_aars.py / rebuild_res.py / merge_aars.py）
- 交付目录：/root/dist
- 最终产物（预期）：
  - agree.webkit.webview-v1.0.0.aar（双 ABI：jni/arm64-v8a + jni/armeabi-v7a + assets）
  - agree-res-ui.aar / agree-res-content.aar / agree-res-android_webview.aar / agree-res-embedder_support.aar

## 步骤 1：拉取 Chromium M119 源码并初始化环境

```bash
# .gclient（managed=False = 固定版本快照，不跟踪分支）
solutions = [
  {
    "name": "src",
    "url": "https://chromium.googlesource.com/chromium/src.git@119.0.6045.214",
    "deps_file": "DEPS",
    "managed": False,
    "custom_deps": {},
    "custom_vars": {},
  },
]
target_os = ["android"]

export PATH=/root/depot_tools:$PATH
gclient sync
```

环境要点：
- depot_tools 未 bootstrap 会报 python3_bin_reldir.txt not found，跑 ./ensure_bootstrap
- sync 前确保有 swap（本机 /swapfile 16G；sync 曾被 OOM 杀，元凶 VK-GL-CTS 大仓库）；sync 中断/被杀后的完整恢复流程见 references/sync-recovery.md（含 gitiles-archive 快照替代全量 git fetch 的方案）
- **gperf 必须装 3.1 且路径可达**：blink 的 color_data.gperf 生成必需，ninja 跑起来后第一个 FAILED 就是它（FileNotFoundError: 'gperf'）。apt 的 3.3 会破坏生成（M132 实测），本机 2026-11 从 https://mirror.sjtu.edu.cn/gnu/gperf/gperf-3.1.tar.gz 源码构建装到 /usr/local/bin（ftp.gnu.org 被墙，交大镜像可达）；**systemd-run 单元的 PATH 必须含 /usr/local/bin**（unit 不继承 shell PATH，漏了会再次 FileNotFoundError）
- **Python 必须 3.8-3.11，不能是 3.14**：M119 脚本用 `imp` 模块（Python 3.12 移除），系统 3.14 会在 safe_browsing allowlist 生成处报 `ModuleNotFoundError: No module named 'imp'`（构建跑到 ~2 万 edge 才炸）。修复 = `uv python install 3.11`（depot_tools 自带 uv）装独立版本，symlink 到 `/usr/local/bin/python3`——systemd-run 单元 PATH 已含 /usr/local/bin 即自动生效，Hermes 自身 venv 的 python3 排前面不受影响
- apt 依赖：pkg-config libglib2.0-dev libnss3-dev libdbus-1-dev libatk1.0-dev libgtk-3-dev libpango1.0-dev；32 位构建额外要 libc6-i386 lib32gcc-s1（host 侧 v8 工具是 i386 ELF，缺了报 FileNotFoundError clang_x86_v8_arm/*，详见 references/fat-multi-abi-builds.md）。**Ubuntu 24.04+ 装 32 位库前必须先 `dpkg --add-architecture i386 && apt-get update`，否则报 Unable to locate package libc6-i386（整个 apt 调用 rc=100，前面已列的所有包也一起装不上）**
- sync 完整标志见 §A1（进程退出 + SYNC_EXIT=0 + NDK 目录，三者齐；**不要**拿 `.gclient_entries` 判完成）。M119 的 NDK 是精简版（~913MB，bin/ 只有 lldb 无 clang，编译器用树内 llvm-build）——完整性判据是 sysroot/usr/include 存在，不能用 bin/clang* 判

## 步骤 2：同步 agree 补丁与布局

M119 用仓库 `patches/` 六个 patch（原三份 M130 patch 已从仓库删除）：
- `001.java_port.patch`：64 个 Java 文件（包名替换、WebViewDelegate 抽象、API 26 兼容：VERSION_CODES 常量→整数字面量、CompatChanges 降级 targetsAtLeastT）
- `002.build_gn.patch`：android_webview/BUILD.gn + glue/BUILD.gn + support_library/BUILD.gn + build/android/gyp/dist_aar.py + build/config/android/rules.gni（--abi-mapping 双 ABI 支持）
- `003.boundary_interfaces.BUILD.gn.patch`：boundary_interface_java 补 webkit_glue_java dep（javac 阶段暴露，见下）
- `004.callback_java.BUILD.gn.patch`：callback_java 补 webkit_glue_java dep（001 改了 SupportLibWebViewContentsClientAdapter 的 import）
- `005.webview_delegate_wrapper_import.patch`：WebViewChromiumFactoryProvider.java 补 `import android.webkit.WebViewDelegateWrapper;`（001 漏了 import，javac 报 could not resolve）
- `006.glue_javac.patch`：glue 的 javac 阶段修复（`setTextClassifier` 形参 `TextClassifier`→`Object`、去掉 `autofill`/`onProvideAutofillVirtualStructure` 的 `@Override`、`ApiHelperForM.onPageCommitVisible` 改直接调用仓库 `WebViewClient`）
- `patches/README.md` 是移植说明
- **draw_fn 的 M119 适配不做成 patch，已直接并入仓库 `java/src/draw_fn/`**（M132 构建不再保留，见下"C++ 编译是第三道验收关口"）

```bash
cd /path/to/chromium/src
git apply /root/agree-webview/patches/001.java_port.patch
git apply /root/agree-webview/patches/002.build_gn.patch
git apply /root/agree-webview/patches/003.boundary_interfaces.BUILD.gn.patch
git apply /root/agree-webview/patches/004.callback_java.BUILD.gn.patch
git apply /root/agree-webview/patches/005.webview_delegate_wrapper_import.patch
git apply /root/agree-webview/patches/006.glue_javac.patch
# 应用后 git status --short | wc -l = 71（64 Java + 5 GN + dist_aar.py + rules.gni）
```

目录布局（**两处拷贝，缺一 gn gen 报缺文件**，详见 references/m119-baseline-build.md）：
1. 仓库整体拷到 `src/android_webview/agree/`（BUILD.gn、java/、AndroidManifest.xml、proguard.flags）——draw_functor.cc 的 include 写死 `"android_webview/agree/java/src/draw_fn/xxx.h"`，jni 头 include 写死 `"android_webview/agree/draw_fn_impl_jni_headers/MyDrawFunctor_jni.h"`
2. 仓库 `java/res_webkit/` 并入 `android_webview/java/`——002 patch 的 `webkit_glue_resources` sources 是 `"java/res_webkit/..."`（相对 android_webview/）。**不要整目录覆盖合并 java/**：仓库 `java/src/org/chromium/android_webview/ProductConfig.java` 会与树内生成逻辑冲突（M119 树该目录没有它）

**gn gen 是验收关口**（移植作者只验证了 git apply --check / gn format / javac 静态扫描，7 个阻断全是 gn gen 才暴露的；全部已修并写回仓库）：
1. **skia 依赖用 `//skia`，不用 `//third_party/skia`**：M119 的 skia 集成在根目录 `//skia`（只 import shared_sources.gni）；`//third_party/skia` 的 BUILD.gn import 的 `gn/skia.gni` 在 declare_args 里无条件引用整棵树从未定义的 `is_wasm` → Undefined identifier。**别在 BUILDCONFIG.gn 定义 is_wasm=false**：`tools/binary_size/BUILD.gn` 的 `if (defined(is_wasm))` 会激活 wasm 分支，加载不存在的 `//build/toolchain/wasm/BUILD.gn`，这棵树刻意不定义它。正解 = 换 dep 标签
2. **`//android_webview:webkit_glue_java` 引用不解析**：patch 的 glue/support_library deps 沿用了 M130 时代的 label，但移植时 target 已移进 `agree/BUILD.gn`。改为 `//android_webview/agree:webkit_glue_java`。**group() 转发不行**：java 模板要求目标自身生成 `__header`/`__compile_java`/`__validate` 等伴随 target，只有 android_library/java_library 才生成
3. **abi_mapping 用 scope 列表**：GN 2121 的 foreach 只支持列表（scope 报 "This is not a list. Instead I see a scope"），变量下标非法（"May only subscript identifiers"）。写法见 references/m119-baseline-build.md；dist_aar.py 的 "--abi-mapping"（GN list of "path=abi"）解析不用动
4. **删 `//components/sensitive_content`**（M130+ 才有，从新版 BUILD.gn 照抄的依赖，M119 目录不存在）
5. **`jni_zero_java` 换 M119 三件套**：`//third_party/jni_zero:jni_zero_java` 是 M126+ 的 target（M119 的 jni_zero/BUILD.gn 只有 test_mocker_java 与 native_library_loaded_status_java）。M119 的 `@JNINamespace`/`@NativeMethods` 注解在 **独立的 `//base:jni_java`**（不在 base_java 里，别只换 base_java——javac 会报 symbol not found）；生成代码 `MyDrawFunctorJni.java` 还引用 `org.jni_zero.JniStaticTestMocker`（`//third_party/jni_zero:test_mocker_java`）与 `org.chromium.build.annotations.CheckDiscard`（`//build/android:build_java`）。draw_fn_impl_java 与 webkit_glue_java 的 deps 都要补齐这四个
6. **删 `android_sdk_version = "35"`**：M119 的 dist_aar 模板不消费该变量 → "Assignment had no effect"；模板不转发的变量直接删，别改成 34（树的 SDK 也只有 android-34）
7. **删空 `srcjars = []`**：同样报 Assignment had no effect

**javac 是第二道验收关口**（gn gen 通过后 Java 编译还会暴露 4 类问题，全部已修并同步回仓库）：
1. **patch 改了 import 却没给 target 加 dep**：001 把 `ProfileBoundaryInterface` 的 import 改成 `agree.webkit.*`（5 个类），但 `boundary_interface_java` 的 deps 没加 webkit_glue_java → javac 报 symbol not found。**对 Chromium 树文件的这种修复必须做成独立 patch**（`git diff <单文件> > patches/00X.patch`），否则下次重放 patch 后修复丢失
2. **BUILD.gn sources 漏文件**：`WebViewApi26/28/Q` 三个隔离类被 WebView.java 4 处调用但没进 `webkit_glue_java` 的 sources → 作者"手动 javac 编译全部 60 文件"的静态验证掩盖了 GN sources 缺漏（手动全量编译 ≠ GN 构建）。**判孤儿文件时 grep 调用点别用 `grep -v` 排除含类名的行**——会把调用行一起过滤掉，误判为孤儿
3. **text block 语法**：从新版 AOSP 拷贝的 `URLUtil.java` 用 Java 15 text block，M119 javac `-source 11` 报 "text blocks are not supported"。修复 = 用 Python 模拟 Java text block 语义（剥公共缩进 + `\\`/`\"` 转义解码）生成普通字符串拼接，别手抄（空格/反斜杠极易错）
4. **jni_java 依赖**（见阻断 5）：同一份 MyDrawFunctor.java 在 draw_fn_impl_java 和 webkit_glue_java 两个 target 里都编译，两处 deps 都要补
5. **support_library/callback 的 `callback_java` 也要补 webkit_glue_java dep**：001 不只改了 boundary_interfaces 的 import，`SupportLibWebViewContentsClientAdapter.java` 的 `WebView`/`WebResourceRequest`/`WebResourceResponse` import 也换成了 `agree.webkit.*`，两处都得接 dep（003 只覆盖了 boundary_interfaces，callback 是 004）。**教训：首次成功构建时的树内手工修复若没固化成独立 patch，重建（清树重打 patch / 新机器）时必复现——每次成功构建后把 `git status` 里 Chromium 树文件的改动全部 diff 成 patch 并提交回仓库，一个都不能留**。**对已 patch 覆盖的文件做树内手修时，patch 内容也要同步更新**（只改树不改 patch，清树重打后 gn gen 以矛盾报错暴露旧内容——实测 rules.gni 的 abi_mapping 迭代格式漂移）。**手工编辑 .patch 的 hunk 内容后必须同步 `@@ -a,b +c,d @@` 行数**：加/删了 hunk 里的行却没改计数，git apply 报 `corrupt patch at line N`；首次应用可能碰巧通过（或直接改树绕过了重放），直到清树重打才暴露——修计数或重新 `git diff` 生成 patch
6. **glue 侧 `WebViewChromiumFactoryProvider` 漏 import**：001 把 `WebViewDelegate` 全量换成 `WebViewDelegateWrapper`（仓库 `java/src/android/webkit/WebViewDelegateWrapper.java`，`package android.webkit`），但 import 块只删了 `android.webkit.WebViewDelegate`、没补 `android.webkit.WebViewDelegateWrapper` → javac could not resolve。由 005 补上

**C++ 编译是第三道验收关口**（gn gen + javac 通过后，draw_fn 的 C++ 才暴露问题）：仓库 `java/src/draw_fn/` 是 **M130 合并**（`92211ce merge chromium v130`）时整体替换的 M130 代码，在 M119 树上编译不过。适配点（已全部并入仓库 `java/src/draw_fn/`）：① skia include 布局 `gpu/ganesh/*`→`gpu/*`、`gpu/ganesh/vk/*`→`gpu/vk/*`；② `gpu::CreateSkiaVulkanMemoryAllocator`→`CreateGrVkMemoryAllocator`（头 `skia_vk_memory_allocator_impl.h`→`gr_vk_memory_allocator_impl.h`）；③ `skgpu::VulkanBackendContext`→`GrVkBackendContext`；④ `GrDirectContexts::MakeVulkan(bc)`→`GrDirectContext::MakeVulkan(bc, options)`；⑤ `GrBackendSemaphores::MakeVk(x)`→`GrBackendSemaphore s; s.initVulkan(x);`；⑥ `skgpu::MutableTextureStates::MakeVulkan(l,q)`→`skgpu::MutableTextureState state(l,q)`；⑦ `AwDrawFnFunctionTable` 去掉 M130 的 `report_rendering_threads`（M119 只有 5 字段）；⑧ `NOTREACHED()` 在 M119 非 noreturn，`CreateFunctor` 要补 `return 0;`。这些适配已**直接并入仓库 `java/src/draw_fn/`**（M132 构建不再保留，故不再需要 M130 版本）

## 步骤 3：编译（单 out 双 ABI）

```bash
cd /root/chromium119/src && export PATH=/root/depot_tools:$PATH DEPOT_TOOLS_UPDATE=0
gn gen out/AarRelease --args='target_os="android" target_cpu="arm64" is_official_build=true chrome_pgo_phase=0 use_gio=false'
./third_party/ninja/ninja -C out/AarRelease -j8 webview_aar
```

要点：
- 一个 out（arm64）即可：`enable_agree_arm`（默认 true）+ abi_mapping 一次产出双 ABI AAR；M119 的 `android_secondary_abi_toolchain` 对 arm64 无条件定义（abi.gni:96-108），无 is_official_build 门控。**不需要第二个 out、不需要 merge_aars.py**（merge_aars.py 是 M132 双 out 时代的产物，M119 用不到）
- 构建前验证双 ABI 在图里：`ninja -C out/X -t targets all | grep libwebviewchromium` 应同时看到 `libwebviewchromium.so: solink` 和 `android_clang_arm/libwebviewchromium.so: android_clang_arm_solink`
- is_official_build=true 才是 release；chrome_pgo_phase=0 跳过 PGO；use_gio=false 减 host 依赖。**M119 官方构建默认 android_static_analysis="off"**（config.gni:84），args 里不用设（"不要设 off"是 M132 语境，M119 的 off 就是默认且不翻转 errorprone）
- 必须 systemd-run 起服务编译（Hermes 后台任务有 4GiB cgroup 硬顶会被 OOM 杀；systemd-run 落 system.slice 无限制）：
  `systemd-run --unit=agree119 --collect --property=StandardOutput=append:/root/chromium119/aar_build.log --property=StandardError=append:/root/chromium119/aar_build.log --property=Environment=PATH=/root/depot_tools:/usr/local/bin:/usr/bin:/bin .../ninja -C out/AarRelease -j8 webview_aar`
  - unit 不继承 PATH，环境变量用 `--property=Environment=PATH=...`（`-p PATH=...` 报 Unknown assignment）；**PATH 必须含 /usr/local/bin**（gperf 在那）
  - 失败 unit 重跑前 systemctl reset-failed；ninja 可续跑，进度显示 [N/剩余] 会重计数（88555 首次 → 84737 续跑 = 88555−已完成的 3818）
- 产物：out/AarRelease/agree.webkit.webview-v1.0.0.aar（该阶段只有 classes.jar + jni/ 双 ABI，R.txt 0 字节、无 assets/、无 res/——dist_aar 特性，正常）
- release 全量链接约 2-6 小时/ABI；磁盘最坏 100G/树（双 out），单 out 双 ABI 实测 out 峰值 ~24G（99G 盘 + 源码树 34G，清 out 后 35G 可用即跑完全量 88555 edges）——判断全量重建可行性用「源码 + ~24G」估，别拿 100G 最坏值吓退；长构建的存活检查与完成确认（三件套）见附录 A
- **ninja 并发执行（`-j8` = 8 条 edge 同时跑），但状态行 `[N/M]` 按 edge 启动顺序打印**（打印点在 `Status::BuildEdgeStarted`），所以 N 单调递增、看着像顺序执行；**N 是启动计数不是完成计数**，任意时刻 `N ≈ 已完成 + 8`（最后几条长任务会出现"N 已到 M 但命令还在跑"）。看日志时 N 的增速 = 吞吐，不代表完成速率

## 步骤 4：assets 打包

dist_aar 不打包 android_assets → 产物缺 resources.pak/icudtl/locales/快照，App 启动 WebView 初始化即崩（aw_resource_bundle.cc 硬编码 assets/resources.pak 等路径）。机制与陷阱详解见 references/aar-assets-packaging.md。

```bash
python3 scripts/add_aar_assets.py --aar out/AarRelease/agree.webkit.webview-v1.0.0.aar --out out/AarRelease
```

脚本行为：补 chrome_100_percent.pak、resources.pak、icudtl.dat、stored-locales/*.pak（全部 STORE 不压缩）。快照按 out/args.gn 的 target_cpu（arm64 → snapshot_blob_64.bin + v8_context_snapshot_64.bin）。

**M119 实测（已验证）**：单 out 双 ABI 下 32 位进程需要 `assets/snapshot_blob_32.bin`（缺则 FATAL: Error loading V8 startup snapshot file）。64 位快照在 `gen/android_webview/agree/snapshot_blob_64.bin`（仓库 copy_snapshot_blob 的 target_gen_dir），32 位在 `out/AarRelease/android_clang_arm/snapshot_blob.bin`（secondary toolchain 目录）——add_aar_assets.py 已支持多路径查找 + 自动补 32 位。本构建 `gen/tools/v8_context_snapshot/buildflags.h` 的 `USE_V8_CONTEXT_SNAPSHOT()=0`，**不需要** v8_context_snapshot_64.bin（arm32 恒关，arm64 视构建参数）。

## 步骤 5：打包 4 个辅助资源 AAR

背景：主 AAR 的 R.txt 0 字节、无 res/、classes.jar 无 R 类（dist_aar 不跑 aapt2 link），而内核 getstatic 引用多个 org.chromium.* R 包。AGP 只为 AAR manifest package 生成一个 R 类包，单 AAR 结构上无法覆盖 → 5-AAR 拆包（机制限制的完整推导见附录 B §5）。

- agree-res-ui.aar → org.chromium.ui
- agree-res-content.aar → org.chromium.content
- agree-res-android_webview.aar → org.chromium.android_webview
- agree-res-embedder_support.aar → org.chromium.components.embedder_support.delegate

生成：
1. 前置：全量真实 R.txt（aapt2 link 一次；R.txt 与 CPU 无关。完整命令见附录 B §2，**M119 用 build-tools 34.0.0 + android-34**，不是 35。**必须用 `/usr/local/bin/python3`（3.11）跑**——终端默认 python3 是 Hermes venv 的 3.14，compile_resources.py 的 parallel.py 会报 `'NoneType' object is not subscriptable`）
2. `python3 scripts/make_res_aars.py --out out/AarRelease --r-txt <全量R.txt> --dist <输出目录>`：从 `gen/android_webview/agree/webview_aar.build_config.json` 的 dependency_zips 按 obj/ 前缀分组（ui/content/android_webview/embedder_support）→ 拆 res 到 _res_<module>/（去 N_ 前缀，overlay 优先）→ R.txt 用资源名清单筛全量真实 R.txt → 空 AndroidManifest(package=对应包) + R.txt + public.txt + res/ 打包。**脚本已内置 M119 修正**：build_config 路径在 `agree/` 下；作者参考 AAR 不在本机时退回用 res 目录资源名（collect_res_names）。

   **R.txt 必须覆盖代码引用的全部资源类型，否则 AGP 不生成对应 R 内部类 → 运行期 `ClassNotFoundException: org.chromium.<module>.R$X` → JNI 注册失败 → 进程 abort**（实测：content 缺 `array`/`layout` 导致 `R$array` 找不到，闪退栈 `jni_android.cc(290)`）。资源名收集四个来源缺一不可：① 文件名型（`layout/*.xml`、`drawable/*.xml`、png、9-patch 的 `.9` 后缀要去掉）；② xml 的 `name="..."` 属性；③ 布局里的 `@+id/xxx`；④ 名称 mangle（aapt2 把 `.`/`-` 转 `_`，如 `TextAppearance.X` → `TextAppearance_X`）。另外 `int[] styleable` 条目也要收（旧版只收 `int` 行会漏）。**跨模块引用**（如 content 的 `AndroidFontLookupImpl` 用 `org.chromium.content.R` 引用 ui 模块的 `array.ui_com_google_android_gms_fonts_certs`）由脚本扫描各模块 Java 源码的 `R.<type>.<name>`，从别的模块的 dependency zip 补复制进本模块 res/。验证：`unzip -p <aux.aar> R.txt | grep -c 'int array\|int layout'` 与代码引用数对齐，且 `res/` 里有对应文件

## 验证清单

- 主 AAR：jni/arm64-v8a + jni/armeabi-v7a 双目录、assets 86 项（含 snapshot_blob_64.bin + snapshot_blob_32.bin；本构建 `USE_V8_CONTEXT_SNAPSHOT()=0` 故无 v8_context_snapshot）、zipfile.testzip()==None
- 辅助 AAR：manifest package 正确、R.txt 资源名与作者版 0 缺失、zipfile.testzip()==None
- 内核 NDK api level：`readelf -x .note.android.ident libwebviewchromium.so` 应为 0x18（24）；若是 0x1a（26）说明 args 覆盖过或缓存没清
- 装机实测：32 位进程不再 FATAL（快照），App 正常加载 resources.pak；宿主 App build.gradle 必须设 androidResources { noCompress 'bin', 'pak' }，否则 assets 被压缩、WebView mmap 加载失败

## 附录 A：通用 Chromium Android 构建参考

### A1. 源码 checkout & sync
- **同步完成的判定 = 进程退出 + 日志出现 `SYNC_EXIT=0` + `third_party/android_toolchain/ndk/` 存在，三者齐**。`.gclient_entries` **不能**作为完成信号：gclient 在同步**开始前**就整份写出（本次实测开始几分钟后 78KB 已落盘，当时 src 只有 6GB、NDK 完全没到），拿它判完成会误报。另外 `.gclient` 放在 `workspace/` 而 `src/` 作为子目录时，日志会反复打印 `WARNING: ... .gclient_entries missing, .gclient file in parent directory ...`，这是父目录 .gclient 的常规提示，**不是失败**。
- 进度只能看 `du -sm src` 的增量（M119 全量约 18GB+ 且仍在涨 → 未完成）与 `pgrep -f "gclient sync"`；DEPS 有 300+ 依赖，按目录逐个拉，单个大 dep 拉完 17GB 后还会继续。
- 中断后重跑直接 `gclient sync -D --no-history -j4`：`rm -f <workspace>/.gclient_entries` 再跑即可续，别删 src（已下的 git 对象全部可复用）。`--depth=1` 手工 `git fetch` 的 tag 引用只会写进 `FETCH_HEAD`，必须 `git checkout FETCH_HEAD` 才有工作区，`git log` 报 "branch 'main' does not have any commits yet" 时就是这个状态。
- 内存受限主机的 sync：先加 swap；单个大 dep（VK-GL-CTS）手动 fetch + 续跑；全量 fetch 反复被杀 → gitiles-archive 快照方案。全部见 references/sync-recovery.md。

### A2. depot_tools bootstrap
- DEPOT_TOOLS_UPDATE=0 安装的 depot_tools 未 bootstrap，gn gen 报 python3_bin_reldir.txt not found → cd $HOME/depot_tools && ./ensure_bootstrap。

### A3. gn gen 参数语义
- 无参数 gn gen 默认构建 host（Linux 桌面），headless 服务器必挂 pkg-config/atk → 必须显式 target_os="android"，并预装 dev 库（见步骤 1 apt 清单）。
- 默认 is_debug=true（is_debug = !is_official_build）。
- official 构建：is_official_build=true 单独生效（is_debug=false、R8、APK 不可调试）；勿与 is_java_debug 混用（config.gni assert）。
- secondary ABI：M119 同 M132，arm64 下无条件定义 android_secondary_abi_toolchain（abi.gni:96-108，无 is_official_build 门控、无 skip 开关）；仅 64 位主 target_cpu 能 fat（arm64→arm，x64→x86）；32 位主 target 无法 fat。详见 references/fat-multi-abi-builds.md。
- android_static_analysis：M119 官方构建默认 "off"；非 official 默认 "build_server"（M132+ 语境），plain ninja 会在 java 分析步骤死（AUTONINJA_BUILD_ID is not set），设 "on" 转本地 action。
- 改 gn 参数前做 blast-radius 检查：grep 参数在 build/ 的消费处，判断 gated 方式；改后 ninja -n 的 edge 数就是失效规模。

### A4. APK/目标命名
- GN target 标签不是文件路径；验证 target 用 gn ls 或 grep 所在 BUILD.gn。
- WebView APK：system_webview_64_apk（→apks/SystemWebView64.apk）、system_webview_apk（64 位主 + secondary 时别名 32_64 fat）；chrome_public_apk 等。webview_apk 不存在。
- 与 agree 的关系：这是系统 WebView provider 路线（有签名/provider 门禁），agree AAR 是 App 内嵌引擎路线（无这些门禁），两者目标不同，别混。

### A5. 长构建存活与内存
- 进度 = 两次计数差值；但 step 数≠状态：必须同时查 ninja 进程活着 + 日志尾无 FAILED/ninja: build stopped。
- 完成确认三件套：systemctl show <unit> 的 Result=success + ninja -n 打印 no work to do + AAR 完整性（zipfile.testzip()==None、payload 在、mtime 新于所有输入）。
- **长构建的完成等待用后台轮询，别用前台 sleep 循环**：`while systemctl is-active <unit>; do sleep 60; done` 放 terminal(background=true, notify=true)（会话级 cgroup 限制只影响编译本身，sleep 循环没事）；前台轮询会被工具超时（~420s）切断，等不到结果。监听脚本退出时把 Result=/日志尾/AAR 存在性一起打印，通知即完成报告。
- ninja 可续跑；中断杀掉的 .o 在 20 分钟内删除再续（防截断对象毒化链接）。
- 后台任务 4GiB cgroup 上限（Hermes/worker scope）→ 一律 systemd-run 起服务编译，system.slice 无此限制。**gclient sync 同样要 systemd-run**：Hermes 跟踪的后台进程被 SIGTERM 杀过两次（日志尾 SYNC_EXIT=143）。
- 两个 ABI 的 ThinLTO 链接不要并发（内存峰值叠加会 OOM）——单 out 双 ABI 是同一 ninja 图，链接阶段若内存吃紧可临时降 -j 串行化。

### A6. 系统 WebView APK 装机验证（仅 APK 路线需要）
- 多 ABI 设备装单 ABI WebView APK → INSTALL_FAILED_INTERNAL_ERROR（multiArch manifest 设计如此），用 adb install --abi arm64-v8a。
- provider 签名门禁：debug key（chromium-debug.keystore）装得上但 dumpsys webviewupdate 报 Incorrect signature → AOSP 镜像用 AOSP platform key 重签；零售 Google/OEM 机无解（私钥）。
- 无 java 提取证书：scripts/jks_dump_cert.py + openssl。命令细节见 references/installing-webview-apks.md。

## 附录 B：AAR 资源链路深度修复

agree 用 dist_aar 模板打 AAR。dist_aar 只拼 jar/assets，不跑 aapt2 link，产物天然缺真实资源：R.txt 空或占位 ID、无 res/、classes.jar 无 R 类。以下为完整修复流程。

### B1. 先修 BUILD.gn（资源冲突与过滤）

dist_aar("webview_aar") 的 resource_included_patterns 必须为 []（原来是 ["not_include_any_resources"]，会把所有 R.txt 和资源 zip 全滤掉 → R.txt 0 字节、无 res/）。同名资源冲突 → resource_overlay = true（webkit_glue_resources；agree_ui_strings_grd 与官方 ui_strings_grd 重复）。

改完重建 build_config：

```bash
cd /root/chromium119/src && export PATH=/root/depot_tools:$PATH DEPOT_TOOLS_UPDATE=0
ninja -C out/AarRelease webview_aar__build_config_crbug_908819
```

### B2. aapt2 link（官方 compile_resources.py）

在 out 目录内执行（路径相对 out；**M119 用 34.0.0 / android-34**，build_config 路径在 agree/ 下）：

```bash
cd /root/chromium119/src/out/AarRelease
python3 ../../build/android/gyp/compile_resources.py \
  --aapt2-path ../../third_party/android_sdk/public/build-tools/34.0.0/aapt2 \
  --android-manifest ../../android_webview/agree/AndroidManifest.xml \
  --include-resources ../../third_party/android_sdk/public/platforms/android-34/android.jar \
  --dependencies-res-zips "@FileArg(gen/android_webview/agree/webview_aar.build_config.json:deps_info:dependency_zips)" \
  --dependencies-res-zip-overlays "@FileArg(gen/android_webview/agree/webview_aar.build_config.json:deps_info:dependency_zip_overlays)" \
  --extra-res-packages "@FileArg(gen/android_webview/agree/webview_aar.build_config.json:deps_info:extra_package_names)" \
  --min-sdk-version 24 --target-sdk-version 34 \
  --arsc-path /tmp/xxx.arsc --r-text-out /tmp/xxx_R.txt --srcjar-out /tmp/xxx_R.srcjar
```

产物：全量 R.txt（唯一 ID）和 R.java srcjar（46 包）。depfile 报 "Found abs path in depfile" 无害，去掉 --depfile 即可。**不要在 execute_code 里跑 compile_resources.py**（Hermes Python 3.14 与树 protobuf 不兼容，Descriptors cannot be created directly），用 terminal python3。

### B3. 编译 R 类（只编 org/** 和 gen/**）

从 srcjar 提取 org/** 和 gen/** 的 R.java（跳过 androidx 等第三方包，App 自带 androidx，塞进去会冲突），javac 编译成 r.jar。R.java 是继承模式（各包 extends gen.base_module.R，字段在基类、非 final → 字节码 getstatic 引用，运行时解析）。

### B4. 重组 res/（标准布局）

依赖资源 zip（build_config 的 dependency_zips）解包：去掉 N_ 前缀（如 0_res_webkit/layout/ → layout/），overlay 优先（先放非 overlay，再放 overlay 覆盖同名）。得 1116 个文件，js_prompt/webview_find 各一份。

### B5. 组装 AAR 与单 AAR R 类机制限制

```bash
python3 scripts/assemble_aar.py --aar <out目录的.aar> \
  --r-txt /tmp/xxx_R.txt --r-jar /tmp/r.jar --res-dir /tmp/aar_res -o <输出.aar>
python3 scripts/add_aar_assets.py --aar <输出.aar> --out <build_out>
```

机制限制（决定性）：AGP 集成 AAR 时只为一个 AAR 生成一个 R 类包，包名取自该 AAR 的 manifest package，与 R.txt 里列了多少资源包无关。agree 内核 getstatic 引用多个 org.chromium.* R 包（ui、content、android_webview、components.embedder_support.delegate 等），单 AAR 结构上不可能覆盖全部 → 正确交付方式就是 5-AAR 拆包（主 AAR + 4 辅助，各自 package 对应一个内核引用包）。res/ 放主 AAR 里没用：AGP 只为主包的 manifest package 生成 R 类，内核代码不指向那个包。

验证陷阱：在 dex 里 grep 到 Lorg/chromium/ui/R$integer 只说明 getstatic 字符串存在，不能证明 R 类存在——必须看 R.jar 里的定义，最终装机实测。

### B6. 5-AAR 交付形态与生成脚本

- 主 AAR：classes.jar + jni（双 ABI）+ assets，R.txt 0 B、无 res/、无 R 类。AGP 从辅助 AAR 生成全部 R 类。
- 4 个辅助 AAR（~0.1MB 纯资源）：AndroidManifest package=对应包 + R.txt（该包资源清单）+ res/。
- 辅助 AAR 的 R.txt ID 值无关紧要（最终 ID 由 App 打包时 AGP 分配）；我们构建产物的全量 R.txt（真实 ID）100% 覆盖作者 4 个辅助 AAR 的全部资源。
- scripts/make_res_aars.py：从 dependency_res_zips 按模块拆分（ui→obj/ui/、content→obj/content/、android_webview→obj/android_webview/、embedder_support→obj/components/embedder_support/）；R.txt 用作者 AAR 的资源名清单筛全量真实 R.txt。
- 与我们版的差异（已核对，功能等价）：作者版是资源混淆后的发布态（yy_/xx_ 前缀引用），我们版未混淆（@string/xxx 真实名）；drawable 密度目录 -v4 后缀 vs 无后缀；values 组织不同（作者单文件 vs 我们按来源拆分加序号后缀）。
- 主 AAR 的正确形态 = dist_aar 原始产物 + add_aar_assets 补 assets + 32 位快照（M119 单 out 下从 arm 工具链产物取，见步骤 4）。

## Pitfalls

- **patch 移植验收分三层，逐层都可能出新问题**：`git apply --check`（能打上）→ `gn gen`（构建图无未解析依赖/无 unused variable，如 `needs //...__header` 缺伴随 target、"Assignment had no effect"）→ `javac`（Java 编译过，如 dep 漏接、sources 漏文件、语法超版本）。作者只验证到 javac 静态扫描（手动编全部文件）都漏了 GN sources 缺文件。报错归属用 `git stash` + 无 patch gn gen 对照，分清树本身问题与移植引入问题（M119 干净树 gn gen 直接通过，is_wasm 报错是移植的 skia dep 引入的）
- **`group()` 转发满足不了 java 模板的 deps**：java 模板要求目标自身生成 `__header`/`__compile_java`/`__validate` 等伴随 target，只有 `android_library`/`java_library` 才生成。要换实现位置就把 deps 直接指向真实 java target，别用 group 中转
- **skia 依赖标签随 Chromium 版本不同**（M119 用根目录 `//skia`，M132 用 `//third_party/skia`）：先确认该版本树里哪个存在、哪个会加载出问题的 gni。M119 的 `third_party/skia/BUILD.gn` import 的 skia.gni 在 declare_args 里无条件引用从未定义的 `is_wasm`；**不要用定义 is_wasm 来修**——`tools/binary_size/BUILD.gn` 的 `if (defined(is_wasm))` 会激活 wasm 分支并加载不存在的 `//build/toolchain/wasm/BUILD.gn`，这棵树刻意不定义它
- `gn format --dry-run` 的 rc 别误读：rc=0 通过，**rc=2 只是格式差异**，只有输出含 `ERROR at :<行号>` 才是语法错；GN 的 `foreach` 只支持列表（scope 报 "This is not a list. Instead I see a scope"），且用变量下标 scope/列表都非法（"May only subscript identifiers"）。要传映射给模板就用 **scope 列表 + 成员访问**：`abi_mapping = [ { lib = _l, abi = "x" }, ... ]`，消费侧 `foreach(_e, invoker.abi_mapping) { _e.lib ... }`
- **gperf 3.1**：blink 必需（color_data.gperf），apt 3.3 不行（M132 实测）；ftp.gnu.org 常被墙，用 https://mirror.sjtu.edu.cn/gnu/gperf/gperf-3.1.tar.gz 源码构建装 /usr/local/bin。**systemd-run 单元 PATH 必须含 /usr/local/bin**（unit 不继承 shell PATH，漏了 ninja 跑起来后第一个 FAILED 就是 FileNotFoundError: 'gperf'）
- 导入的压缩包里的 `/root`、`systemd-run` 是原构建主机的路径与 Linux 设施，**照抄到 macOS 上必失败**；导入时按"本机适配"替换，别把原文当权威
- scripts/make_res_aars.py 的模块顶部硬编码了原主机的作者版 AAR 路径（`/root/dist/agree-res-ui.aar` 等）；换机器先改这些常量或改成由 `--dist` 推导，否则脚本在导入后直接崩
- ninja 重建 webview_aar 后必然回到无 assets/无 res/ 状态，发布流程 = ninja → 补 assets（add_aar_assets.py）→ 32 位快照核对 → 资源 AAR，每一步都要重跑
- dist_aar 产物 R.txt 0 字节是设计使然不是失败；资源靠 4 个辅助 AAR，别往主 AAR 塞 res/
- 32 位快照命名每次重打包后都要重做，否则 32 位崩溃复发；识别快照归属用 MD5 对 out/<dir>/snapshot_blob.bin，不看文件名
- **`make_res_aars.py` 的"作者参考 AAR"就是本脚本的上一版输出**（`TARGETS` 的路径与 `--dist` 相同）：它只能用来兜底资源名，**不能作为"该资源已存在"的判据**——跨模块补复制的条件必须检查 res/ 目录的实际内容（`collect_res_names` 的结果），否则会出现"R.txt 里没有、res/ 里也没有"的静默缺口；补复制后要重新收集资源名再生成 R.txt
- **交付目录 /root/dist 只放产物（AAR）**：脚本、中间产物（`*.dist_aar_raw`、`_res_*` 拆分目录）不要留在那里——打包脚本的权威副本在本技能 scripts/（`/root/dist/recompress_aar.py` 这类拷贝是冗余，删掉）
- 后台构建必须 systemd-run（Hermes bg 有 4GiB cgroup 上限，且 `terminal(background=true)` 的 ninja 会被会话生命周期 SIGTERM 杀——实测 exit 143 / -15 "interrupted by user"，不是只有 cgroup 触发）；重跑失败 unit 前 systemctl reset-failed；unit 传环境变量用 `--property=Environment=PATH=...`，`-p PATH=...` 报 Unknown assignment
- 32 位构建缺 libc6-i386 报 FileNotFoundError（clang_x86_v8_arm/*）
- 在 `execute_code` 里不要用 `find . -name '*.rej' -delete` 这类删除句清理构建树：被 Hermes hardline 安全规则拦截（误匹配 Python 解释器路径）。改用 `find ... -print0 | xargs -0 rm -f`，或直接 `git checkout -- .`
- **清理工具生成的备份/残留时，限定在改动文件列表内，绝不按扩展名全树匹配**：`find . -name '*.orig'` 这类删除会误伤第三方源码里的同名真实文件——Chromium 的 `third_party/rust/*/crate/Cargo.toml.orig` 就是 crates.io 打包自带的源文件（61 个），删了得 `git checkout -- third_party/rust/` 全量恢复。正确做法是拿 `git diff --name-only` 的输出作为删除范围
- **`@RequiresApi(Build.VERSION_CODES.X)` 的注解参数是真编译阻断，和代码里的裸常量同等致命**（参数进 class 常量池，目标 API 的 android.jar 里没有该字段）。清扫 `VERSION_CODES` 时必须覆盖注解位置，改成 `@RequiresApi(29)` 这种整数形式；只扫 `if (SDK_INT >= ...)` 会漏掉一大半。详见 references/min-sdk-and-platform-support.md D3
- **`android.app.compat.CompatChanges`（API 31+）是独立的类级缺口**，不含 `VERSION_CODES` 字样所以清扫时扫不到，运行期 `NoClassDefFoundError`。靠"按 android.* import 在目标 android.jar 里查类存在性"兜底发现，降级为等价的 `targetsAtLeastT()` 判断
- **做 API 扫描时不要把 `agree/java/` 和 chromium 的 `base/android/java/src/` 联合编译**：包名空间对不上，会产出上百条与 API 无关的内部依赖错误把真问题淹没。只看目标文件自己的报错并按文件名分组筛选
- **校验 GN 依赖 label 时，"找不到" 大多数是误报**：target 常由 template/生成器宏定义（`libwebviewchromium_tmpl`、`androidx_android_aar_prebuilt`、`mojom` 自动产出的 `<name>_java`、`<lib>__jni_registration`）。用一个只匹配 `android_library`/`java_library` 的正则会把这批全判成缺失。先 grep 宏名再下结论，否则会拿到一份大半是假的"缺失依赖"清单
- **拷旧 patch 的 `android_resources` `sources` 清单前，逐个条目在「目标树」和「外部仓库」两处都查一遍存在性**：源码版本自己的清单里也可能有一半是幻觉引用。同时在 `custom_package` 不同的两个资源块里列同一批 XML = 同一个资源 id 生成两套 R 类，先按 Java 代码引用的 `R.id.*` 反推归属块再删掉重复那份；裸 `R.*` 无显式 import 的类属于它自己包的 R，这是定归属的决定性证据
- **资源 target 和 native `source_set` 都定义完了不等于接进构建**：`gn gen` 对「定义了但没人 deps」的 target 完全沉默（不是错误），产物里就是没这批资源/符号，崩在运行期而不是构建期。每个移植进来的 target 都要单独 grep 一次它的**被引用**位置（`grep -n "deps.*:target"`），把「有定义、无引用」的孤岛揪出来，再逐个决定接上还是删掉。另：`deps` 里带仓库前缀（`agree_*`）的 target 先查目标版本有没有**无前缀**的上游同名等价物（grep 它所依据的 `.grd` 文件名定位），是改名就改 dep，别新建一个重复定义。**孤岛还要再判一层是「接上」还是「删掉」**：目标版本可能已有内容等价、已接入构建的上游块（`custom_package` 相同 = 重复 R 类），且仓库自己的 Java 对该包 `R` 引用为 0 → 整个块删掉，别无脑接线；判定方法见 references/evaluating-external-build-repos.md 的「Before deciding a ported resource block is "needed"」
- **native 源码该拷到哪，由 `.cc` 里的 `#include` 字面量决定，不是由目录名直觉决定**：树相对 include（`"android_webview/agree/java/src/draw_fn/x.h"`）锁定拷贝目的地；`jni_headers/<path>/<target>_jni.h` 形式的 include 锁定 `generate_jni` target 必须定义在哪个目录（jni_zero 的输出路径镜像 BUILD.gn 自身所在目录）。先读 include 再写 `source_set`，反过来会在长时间 configure 后才报 file not found
- 长构建前先把自研改动备份到持久目录，不要停留在 `/tmp`（重启即清）；**构建中每修一处立即同步回仓库**（M119 已按此分两次提交：gn gen 阶段、javac 阶段）：仓库内文件（BUILD.gn、java/）直接 cp 覆盖；对 Chromium 树文件的修复（patch 范围外）用 `git diff <单文件> > patches/00X.patch` 做成独立 patch 并更新 README，否则重放 patch 后修复丢失，重建时又踩一遍
- **patch 只用于改 Chromium 树文件；仓库自己的文件直接改仓库，别做成 patch**：patch 的 `+++` 路径形如 `android_webview/...`、`build/...`（仓库里没有这些文件，只能 patch）是正常的树 patch；如果某个"修复"改的是仓库自己的文件（`java/src/draw_fn/`、`java/src/org/...`、`BUILD.gn`），**直接改仓库并删掉该 patch**——用户明确要求过，仓库代码不以 patch 形式间接维护。判断标准：patch 的 `+++` 路径在仓库 `git ls-files` 里有对应源文件吗？没有=树 patch（正常），有=该直接改仓库
- 用户会在自己终端操作本机：长构建可能被外部删 out 目录/脚本打断，链接失败先查 ninja 日志是否外部删除
- 部分 sync 不可信：验证用 §A1 的三者齐（进程+/SYNC_EXIT+NDK），不看 `.gclient_entries` 也不看日志 OK 行；删 out 目录 = 全量重建（.ninja_deps/.ninja_log/.o 全在里面）
- **不要对 gclient 管理的根目录手跑单独的 `cipd ensure`**：实测用 `-root <gclient根>` + 只含单个包的最小 ensure 文件重装 NDK，把整个 `.cipd/pkgs` 状态库冲掉（几十个包标记只剩一个空目录），SDK/gn/ninja/JDK 等已装包的标记和内容全部丢失。要修单个缺失包，直接重跑完整 `gclient sync -D --no-history`（git 依赖全是 no-op，cipd ensure 自动重装缺失包，hooks 幂等跳过）；诊断期间绝不并发跑第二个 gclient/cipd
- NDK 目录存在且体积合理不等于完整：**M119 的 CIPD NDK 是精简版**（~913MB，bin/ 只有 lldb，无 clang——编译器用 Chromium 自带 llvm-build），完整性判据是包能干净重装 + sysroot/usr/include 存在，不能用 bin/clang* 判（那是 M132 全量 NDK 的判据）
- 保留构建 out 目录：AAR 备份没有对应 out 目录就无法补 assets（没有源文件）；debug AAR 用 debug 的 out 目录，别拿 release out 补
- v8 快照是构建专属产物，永远用本地 out/ 的副本，别用上游 release 的（大小合法不同，错配必崩）
- 用户报"不支持低版本设备"时，**先定位限制层再动手**：AAR manifest 通常不写 minSdk，App 的 build.gradle 才是常见真因；只在 `readelf -n` 的 `.note.android.ident` 确认内核 NDK api level 后，才考虑改 `default_min_sdk_version` 重编（详见 references/min-sdk-and-platform-support.md）
- **Android 8/9（API <29，Vulkan 1.0）启动即 SIGTRAP 崩溃**：M119 的 Vulkan 系统最低要求 1.1（`gpu/vulkan/vulkan_function_pointers.h` 的 `kVulkanRequiredApiVersion = VK_API_VERSION_1_1`），Android 8.0 的 `libvulkan.so` 是 1.0，`vkGetInstanceProcAddr(nullptr, "vkEnumerateInstanceVersion")` 返回 null → `VulkanImplementation::InitializeVulkanInstance` 失败 → `draw_functor.cc` 的 `JNI_MyDrawFunctor_GetDrawFnFunctionTable` 里 `CHECK(...)` 崩溃。症状：`Fatal signal 5 (SIGTRAP)`，栈顶 `Java_J_N_MPLJeS1v`（= `MyDrawFunctor.getDrawFnFunctionTable` 的 jni_zero 哈希名）+0x66；崩溃前日志 `invalid vkGetInstanceProcAddr(VK_NULL_HANDLE, "vkEnumerateInstanceVersion")`。API 29+（Vulkan 1.1+）不崩。**修复（方案 A，已并入仓库）**：恢复 GL/EGL 渲染路径——`draw_functor.cc` 新增 `MyDrawFunctorGL`（从官方 `android_webview/test/shell/src/draw_fn/context_manager.cc` 的 `ContextManagerGL` 移植：EGL 动态绑定 libEGL.so + `draw_gl` 回调 + `eglSwapBuffers`，不走 Skia）；`allocator.cc` 的 `QueryRenderMode` 改回 `g_use_vulkan ? VULKAN : OPENGL_ES`；`JNI_MyDrawFunctor_GetDrawFnFunctionTable`/`Init` 按 `use_vulkan` 分支；`MyDrawFunctor.java` 按 `Build.VERSION.SDK_INT >= 29` 选渲染路径（API>=29 用 Vulkan，<29 用 GL）。Android 的 `CreateVulkanImplementation` 不支持 SwiftShader（`DCHECK(!use_swiftshader)`），别指望软件 Vulkan 降级。**调试辅助**：崩溃函数是 jni_zero 哈希名，用 `grep -rn "<哈希>" out/AarRelease/gen/` 反查真实 Java 方法（`MPLJeS1v` → `MyDrawFunctor.getDrawFnFunctionTable`）；`llvm-objdump -d --triple=thumbv7-linux-gnueabi` 才是 arm32 的正确反汇编（不加 triple 全错）
- **ninja 是一次性规划：构建运行中改的源码不会进本次产物**。ninja 启动时就把整份计划算好（哪些 edge 要跑），运行期间不重新检查输入 mtime。构建启动后才改的仓库/树内源码，本次构建用的仍是旧版——必须等构建结束（或中断）后**重跑一次增量 ninja**（只重编受影响的 edge，通常几分钟），再重新打包。判据：`grep <target> aar_build.log`，若该 target 的行出现在构建早期、而你的改动时间在其之后，改动就没进包。**打包后必须解压 classes.jar 验证修复是否真的进去了**（查字段名/常量值/字节码），别只看源码改了就当进包了——M119 实测踩过：ProductConfig 补 IS_BUNDLE、BuildConfig 改 24 都因构建中改源码而漏进第一次产物。**查字符串常量（如日志 tag 改名是否进包）用 CONSTANT_Utf8 字节格式：`\x01 + 2 字节大端长度 + 内容`（`b'\x01\x00\x05agree'` 才是 "agree"）——长度按单字节搜会误报「没编进去」，先写对格式再下结论
- **仓库手写的 Java stub 是 AAR 的最终版，字段必须与树内生成版对齐**：`java/src/org/chromium/build/BuildConfig.java`、`java/src/org/chromium/android_webview/ProductConfig.java`、`java/src/org/chromium/build/NativeLibraries.java` 是手写 stub，而树内生成的同名类要么被 `jar_excluded_patterns` 排除（ProductConfig）、要么是占位值（BuildConfig 的 `MIN_SDK_VERSION = 1`）——**AAR 的 classes.jar 用仓库 stub**。stub 缺字段（如 `ProductConfig.IS_BUNDLE`）编译期不报（glue 编译期看到的是树内生成版），运行期读该字段就 `NoSuchFieldError` 崩在启动。改这些 stub 时对照 `build/android/java/templates/*.template` 的字段集合；stub 里的常量值也要与实际构建一致（`MIN_SDK_VERSION` 要等于 `.note.android.ident` 的 api level，别留作者旧 AAR 的残留值）
- **改 API 包名（`agree.webkit`）必须重编 C++ 并重链 .so**：jni_zero 的 JNI 符号名是 `md5(escape_class_name(包名/类名/方法名))` 的哈希（`third_party/jni_zero/proxy.py`），**包名进了哈希** → 改包名后生成的 `gen/jni_headers/.../<类>_jni.h` 里所有 `Java_J_N_*` 符号全变 → 引用该头的仓库 C++（`draw_fn/draw_functor.cc`）重编 → .so 重链（ThinLTO，1-2 小时）。范围只到仓库自己的 `draw_fn`；Chromium 内核与树内 glue 的 C++ 不引用仓库包名（grep 确认 0 命中），不受影响。Java 侧（仓库 API 包名、glue 的 import、`custom_package`、生成的 GEN_JNI）跟着改/重编。验证方法：改包名后 `grep Java_J_N_ gen/jni_headers/.../<类>_jni.h` 符号应全变。完整文件面清单（哪些文件、哪些 patch、哪些绝不能动）与构建验证流程见 references/package-rename.md
- Apple Silicon/macOS 主机评估构建能力时，**Android 目标一律判不可行**（官方 `docs/android_build_instructions.md`：`Building the Android client on Windows or Mac is not supported and doesn't work.`；症状是 gclient sync 拉 CIPD NDK 包时 `prebuilt/linux-x86_64/...` 报 no such file → `SYNC_EXIT=1`）。别在方案里留"换参数试试"的余地，直接给 Linux 云主机方案
- **用户约定的最终验收 = 清树重放**：`git checkout -- .` + `git clean -fd`（只删非 ignored 的 untracked，out/ 安全）还原整树到 0 改动 → 从仓库重新落位 + 重放全部 patch → gn gen + ninja 全绿，才算仓库自足。任何未固化的树内手修、patch 计数错误都在这一步暴露；这是本用户验收「改动是否正常」的标准流程，别只做增量验证

## 支持文件

- scripts/add_aar_assets.py：补 assets（权威版，按 args.gn target_cpu 自动命名快照；幂等）
- scripts/merge_aars.py：64 位基底 + 32 位 jni → allabi（**M119 单 out 双 ABI 用不到**，M132 双 out 时代遗留）
- scripts/assemble_aar.py：R 类合并 + 换 R.txt + 写 res/ 组装 AAR
- scripts/make_res_aars.py：从构建产物生成 4 个辅助资源 AAR
- scripts/recompress_aar.py：把 AAR 里的 `.so`/`classes.jar` 改 DEFLATE（体积优化，见 references/aar-size-reduction.md）
- scripts/rebuild_res.py：资源重建辅助
- scripts/jks_dump_cert.py：无 java 提取 JKS 签名证书（APK 路线用）
- scripts/smoke_packaging_scripts.py：无构建树的打包脚本冒烟（合成 AAR + 假 out，断言 STORE/快照改名/CLI 契约）
- scripts/port_agree_patch.py：**跨版本移植 agree patch**（按语义重做包名替换，绕开 hunk 上下文不匹配；BUILD.gn 类只报 MANUAL 不擅改）。先 `--dry-run` 看分类再 `--apply`
- references/sync-recovery.md：sync 恢复 playbook（gitiles-archive、卡死 dep、完成度三查、NDK 存在但被截断的探测法）
- references/tree-migration-to-build-host.md：**换机器/上云主机时该带什么**（可再生 vs 不可再生分类表、目标机恢复脚本、验证顺序；末节「绝对最小集」解释为何 `.gclient_entries` 钉不住主树、`git rev-parse HEAD` 才是必带项）
- references/fat-multi-abi-builds.md：多 ABI 构建（32 位 host 依赖、secondary ABI 门控、fat APK vs dist_aar、合并方案）
- references/aar-assets-packaging.md：assets 缺失机制、清单表、per-ABI 快照命名陷阱、MD5 识别规则
- references/runtime-js-dialog-chain.md：**JS 对话框运行链路与白屏排查**（同步 mojo 机制、confirm/cancel 全链、4 个结果丢弃守卫、logcat 关键字）
- references/aar-size-reduction.md：**AAR 体积优化**（构成实测、编译参数 exclude_unwind_tables 等、DEFLATE 压缩率、extractNativeLibs 约束）
- references/installing-webview-apks.md：系统 WebView APK 装机验证（ABI/签名/provider）
- references/evaluating-external-build-repos.md：评估外部 Chromium 构建仓库（patch 兼容性、版本提取、把 patchset 移植到另一个大版本并产出可复用的新 patch 目录的完整流程与验收标准、GN `resources` 块最易飘的位置、「孤岛 target」与「前置名 target 实为改名」两类静默缺口、用 `.cc` 的 `#include` 字面量反推拷贝目的地/`generate_jni` 所在目录、「手写 AndroidManifest 对比 jinja 模板」第三层移植面、`proguard_configs` 接线检查）
- references/min-sdk-and-platform-support.md：**支持 Android 7+ 的完整方案**（限制四层定位、gn 参数降 NDK api level、无构建机的 javac 局部重编（方案 D，含桩依赖/字面量门控/跨包反射三个坑）、D4b 的「`@Override` 必删 / 非 `@Override` 放宽 Object」分流与档位 B 六步落地顺序、agree 自研层成分表、native 运行期诊断、iOS 对照、集成侧三处同步）
- references/m119-baseline-build.md：**M119 基线构建**（patches/ 六个 patch 内容与预期结果、两处拷贝布局、gn gen 阻断 + javac 阻断两级修复清单、单 out 双 ABI 流程、M119 环境事实（含 Python 3.11）、gitiles 对比验证）
- references/package-rename.md：**改 API 包名 / dist_aar target 名的完整文件面**（56 文件 + 6 处 import、BUILD.gn、patches 001/002/003/005、manifest、proguard 免改、技能脚本、绝不能动的清单、两种包名形式的残留陷阱、.so 重链预期、target 名级联到 build_config 路径）

### 硬性限制：macOS host 编不出 Android 目标（任何 ABI）

**Chromium 官方文档 `docs/android_build_instructions.md` 的 System requirements 原文：`Building the Android client on Windows or Mac is not supported and doesn't work.`** 这不是配置问题、可以调参数绕过，而是官方不支持路径。

具体的失败面不是 `gn gen`（几秒就能跑过），而是**依赖拉取阶段**：`gclient sync` 拉 `third_party/android_toolchain/ndk` 这个 CIPD 包时，解压 `toolchains/llvm/prebuilt/linux-x86_64/...` 下的文件会 `lstat ... no such file or directory` → cipd 返回非零 → `SYNC_EXIT=1`。包内是 Linux host 的 NDK 工具链，macOS 上拿不到可用的 native 编译工具。

所以判断顺序要反过来：

1. **先查官方文档那一行**（`curl` 上面那份 doc，grep `not supported`），而不是先拉 27GB 源码去试。macOS 编 Android 在任何 ABI 上都不可行——不只 32 位。
2. 用户问"Chromium 不是有 mac 版本吗"时，答案是：**macOS 能编的是 Mac 桌面 Chrome / iOS Chrome，Android 目标的 host 必须是 Linux**。两者不矛盾，别用"Chromium 没有 macOS 版"这种错说法。
3. 已经把源码树拉下来了不浪费：按 references/tree-migration-to-build-host.md 的清单打包（只管 `.gclient`/`.gclient_entries`、自研源码、patch、本地改动；**`depot_tools/` 与 NDK 一律不带走**，让目标机重新 sync/拉取）传到 Linux 云主机继续用，git 对象与 `.gclient` 配置都可复用。
4. Apple Silicon 上即便只求编 armeabi-v7a 也**再叠一层**硬限制：v8 的 clang_x86_v8_arm 宿主工具是 i386 ELF，macOS 无运行层（见 `references/fat-multi-abi-builds.md`）。

评估机器能力时把这两条放在最前面，别承诺"macOS 可以先编 64 位试试"。

### macOS 内存现实

16 GiB 统一内存（M4）+ 系统动态 swap：ThinLTO 链接峰值 8-14 GiB/ABI，**两 ABI 必须串行**；macOS swap 由系统管理，无法像 Linux 那样手工建 /swapfile 占位，所以内存预算只能靠"串行 + 低 -j"控制。磁盘按 100 GiB 保守估算（源码+deps ~45、最坏 2 个 out ~70）。

### 工具链自检（macOS）

`gclient --version`、`gn --version`、`ninja --version`、`python3 --version`(3.9+)、`ls ~/chromium119/src/third_party/android_toolchain/ndk/`、`brew install pkg-config gperf`（gperf 是 blink 必需，CLT 可能自带但版本要 3.1）；Android SDK/NDK 优先用树内 third_party/android_toolchain/ndk/，系统 NDK 仅兜底。

打包技能包导入的验证配方（合成 AAR、STORE 断言、arm32 快照改名断言）不写进 references/ —— 直接跑 scripts/smoke_packaging_scripts.py，输出即报告。
