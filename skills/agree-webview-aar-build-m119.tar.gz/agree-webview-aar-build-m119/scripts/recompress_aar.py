#!/usr/bin/env python3
"""把 agree AAR 里的大 entry（.so / classes.jar）改成 DEFLATE 压缩。

dist_aar 产物默认全部 STORE（未压缩），AAR 体积 = 各 entry 之和。其中
jni/<abi>/libwebviewchromium.so 与 classes.jar 占了 ~95%，且都能被 DEFLATE
大幅压缩（.so ~2.6x，classes.jar ~5.3x）。

约束（必须告知宿主 App）：
  - jni/ 的 .so 改成 DEFLATE 后，APK 里它也是压缩的，宿主必须设
    android:extractNativeLibs="true"（或 AGP 的 androidResources { useLegacyPackaging true }），
    否则系统会尝试直接 mmap APK 内的 .so 而失败。
  - assets/*.pak|bin 必须保持 STORE（mmap 加载），本脚本不动它们。
  - classes.jar 压缩无副作用：AGP 集成时会重新 dex。

用法：
  recompress_aar.py --aar <AAR> [-o <输出>]      # 默认原地替换
"""
import argparse
import os
import sys
import zipfile

# 这些后缀的 entry 改成 DEFLATE；其余保持原压缩方式
DEFLATE_SUFFIXES = (".so", ".jar", ".dex")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--aar", required=True)
    ap.add_argument("-o", "--output")
    args = ap.parse_args()

    aar = os.path.abspath(args.aar)
    dest = os.path.abspath(args.output) if args.output else aar
    tmp = dest + ".tmp"

    total_raw = 0
    try:
        with zipfile.ZipFile(aar) as zin, \
             zipfile.ZipFile(tmp, "w", allowZip64=True) as zout:
            for info in zin.infolist():
                data = zin.read(info.filename)
                zi = zipfile.ZipInfo(info.filename, date_time=info.date_time)
                if info.filename.endswith(DEFLATE_SUFFIXES):
                    zi.compress_type = zipfile.ZIP_DEFLATED
                else:
                    zi.compress_type = info.compress_type
                zi.external_attr = info.external_attr
                zout.writestr(zi, data)
                total_raw += len(data)
        if dest == aar:
            os.replace(tmp, aar)
        else:
            os.replace(tmp, dest)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)

    with zipfile.ZipFile(dest) as z:
        bad = z.testzip()
        if bad:
            raise RuntimeError(f"zip 校验失败: {bad}")
    print(f"OK: {dest}")
    print(f"    {total_raw / 1048576:.1f} MB -> {os.path.getsize(dest) / 1048576:.1f} MB")
    return 0


if __name__ == "__main__":
    sys.exit(main())
