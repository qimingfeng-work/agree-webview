#!/usr/bin/env python3
"""Dump the first signer cert from a Java keystore (JKS) without java.

Usage: jks_dump_cert.py <keystore> [out.der]   # out.der defaults to /tmp/jks_cert.der

Chromium android debug builds sign with //build/android/chromium-debug.keystore
(alias chromiumdebugkey) — confirm via 'default_android_keystore_path' in
build/config/android/config.gni. Pipe the DER into:
  openssl x509 -inform DER -in out.der -noout -subject -issuer -fingerprint -sha256
"""
import struct
import sys

if len(sys.argv) < 2:
    print("usage: jks_dump_cert.py <keystore> [out.der]   # out.der defaults to /tmp/jks_cert.der")
    sys.exit(1)

path = sys.argv[1]
out = sys.argv[2] if len(sys.argv) > 2 else '/tmp/jks_cert.der'

data = open(path, 'rb').read()
assert data[:4] == b'\xfe\xed\xfe\xed', "not a JKS"
_, count = struct.unpack('>iI', data[4:12])
pos = 12
certs = []
for _ in range(count):
    tag = struct.unpack('>i', data[pos:pos + 4])[0]
    pos += 4
    alen = struct.unpack('>H', data[pos:pos + 2])[0]
    pos += 2
    alias = data[pos:pos + alen].decode('utf-8', 'replace')
    pos += alen
    pos += 8  # timestamp
    if tag == 1:  # private-key entry: encrypted key + cert chain
        klen = struct.unpack('>i', data[pos:pos + 4])[0]
        pos += 4 + klen
        chain = struct.unpack('>i', data[pos:pos + 4])[0]
        pos += 4
        for _ in range(chain):
            tlen = struct.unpack('>H', data[pos:pos + 2])[0]
            pos += 2 + tlen
            clen = struct.unpack('>i', data[pos:pos + 4])[0]
            pos += 4
            certs.append((alias, data[pos:pos + clen]))
            pos += clen
    elif tag == 2:  # trusted-cert entry
        tlen = struct.unpack('>H', data[pos:pos + 2])[0]
        pos += 2 + tlen
        clen = struct.unpack('>i', data[pos:pos + 4])[0]
        pos += 4
        certs.append((alias, data[pos:pos + clen]))
        pos += clen
    else:
        break

assert certs, "no cert found in keystore"
open(out, 'wb').write(certs[0][1])
print(certs[0][0], out, len(certs[0][1]), 'bytes')
