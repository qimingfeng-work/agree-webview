#!/usr/bin/env python3
"""Merge WebView runtime assets into a agree-style dist_aar AAR.

dist_aar (build/android/gyp/dist_aar.py) never packages android_assets deps, so the
built AAR lacks assets/ (resources.pak, icudtl.dat, v8 snapshots, stored-locales/*.pak)
and the host app crashes at startup. This script rebuilds the AAR appending those files
as STORE (uncompressed) entries, matching the upstream release layout.

Usage:
  add_aar_assets.py --aar <AAR> --out <build_out_dir> [-o <output>]
  Without -o the input AAR is replaced in place. Idempotent: already-present entries
  are skipped, so re-running on a patched AAR is safe.

  Snapshot asset is named PER-ABI from args.gn target_cpu: arm32 ->
  assets/snapshot_blob_32.bin (and any stale _64 entry is dropped), arm64 ->
  snapshot_blob_64.bin + v8_context_snapshot_64.bin.
"""
import argparse
import os
import re
import shutil
import sys
import zipfile

MAIN_ASSETS = [
    ("gen/android_webview/chrome_100_percent.pak", "assets/chrome_100_percent.pak"),
    ("gen/android_webview/resources.pak", "assets/resources.pak"),
    ("icudtl.dat", "assets/icudtl.dat"),
]
# The v8 snapshot asset name is decided PER-ABI at packaging time: the runtime
# selects by process arch (content/app/content_main_runner_impl.cc __LP64__ ->
# descriptor v8_snapshot_32_data/64_data -> v8_snapshot_files.cc binding to
# assets/snapshot_blob_32.bin/_64.bin). A 32-bit process reads ONLY the _32
# name. gen/android_webview/snapshot_blob_64.bin is a fixed _64 name for every
# arch (android_webview copy_snapshot_blob) whose CONTENT is the arch's own
# snapshot_blob.bin.
SNAPSHOT_64_SRCS = [
    "gen/android_webview/snapshot_blob_64.bin",
    # agree 的 copy_snapshot_blob 定义在 android_webview/agree/BUILD.gn，
    # 其 target_gen_dir 是 gen/android_webview/agree/
    "gen/android_webview/agree/snapshot_blob_64.bin",
]
LOCALES_SRC = "android_webview/locales"
LOCALES_DST = "assets/stored-locales"


def target_cpu(out_dir):
    """target_cpu from out/args.gn ('arm' | 'arm64' | ...), or None."""
    try:
        with open(os.path.join(out_dir, "args.gn")) as f:
            m = re.search(r'target_cpu\s*=\s*"([^"]+)"', f.read())
        return m.group(1) if m else None
    except OSError:
        return None


def snapshot_assets(out_dir, cpu):
    """Per-ABI v8 snapshot entries [(src, dst), ...].

    M119 单 out 双 ABI（target_cpu=arm64 + secondary arm）下，32 位进程读的
    assets/snapshot_blob_32.bin 必须从 secondary toolchain 目录
    （out/<out>/android_clang_arm/snapshot_blob.bin）取——64 位快照不能改名冒充。
    Context snapshot 只在 use_v8_context_snapshot 打开时存在（arm32 恒关）。"""
    src = None
    for rel in SNAPSHOT_64_SRCS:
        p = os.path.join(out_dir, rel)
        if os.path.isfile(p):
            src = p
            break
    if src is None:
        return []
    items = []
    if cpu in ("arm", "x86"):
        items.append((src, "assets/snapshot_blob_32.bin"))
        return items
    items.append((src, "assets/snapshot_blob_64.bin"))
    arm32 = os.path.join(out_dir, "android_clang_arm", "snapshot_blob.bin")
    if os.path.isfile(arm32):
        items.append((arm32, "assets/snapshot_blob_32.bin"))
    ctx = os.path.join(out_dir, "v8_context_snapshot_64.bin")
    if os.path.isfile(ctx):
        items.append((ctx, "assets/v8_context_snapshot_64.bin"))
    return items


def collect(out_dir):
    items, missing = [], []
    for rel, dst in MAIN_ASSETS:
        src = os.path.join(out_dir, rel)
        if os.path.isfile(src):
            items.append((src, dst))
        else:
            missing.append(rel)
    cpu = target_cpu(out_dir)
    if cpu is None:
        print("[WARN] no target_cpu in args.gn; assuming 64-bit snapshot naming")
    items += snapshot_assets(out_dir, cpu)
    ldir = os.path.join(out_dir, LOCALES_SRC)
    if os.path.isdir(ldir):
        for f in sorted(os.listdir(ldir)):
            if f.endswith(".pak") and not f.endswith(".pak.info"):
                items.append((os.path.join(ldir, f), f"{LOCALES_DST}/{f}"))
    else:
        missing.append(LOCALES_SRC + "/")
    return items, missing, cpu


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--aar", required=True, help="input AAR (modified in place unless -o)")
    ap.add_argument("--out", required=True, help="build out dir with the built assets")
    ap.add_argument("-o", "--output", help="output path; default overwrites --aar")
    args = ap.parse_args()

    aar = os.path.abspath(args.aar)
    out = os.path.abspath(args.out)
    dest = os.path.abspath(args.output) if args.output else aar

    items, missing, cpu = collect(out)
    for m in missing:
        print(f"[WARN] missing {m} (skipped)")
    if not items:
        print("no assets found, aborting", file=sys.stderr)
        return 2

    tmp = dest + ".tmp"
    try:
        with zipfile.ZipFile(aar) as zin, \
             zipfile.ZipFile(tmp, "w", allowZip64=True) as zout:
            existing = set(zin.namelist())
            drop = {"assets/snapshot_blob_64.bin"} if cpu in ("arm", "x86") else set()
            for info in zin.infolist():
                if info.filename in drop:
                    continue
                zout.writestr(info, zin.read(info.filename))
            added = skipped = total = 0
            for src, dst in items:
                if dst in existing:
                    skipped += 1
                    continue
                zi = zipfile.ZipInfo(dst)
                zi.compress_type = zipfile.ZIP_STORED
                zi.external_attr = 0o644 << 16
                with open(src, "rb") as f:
                    zout.writestr(zi, f.read())
                added += 1
                total += os.path.getsize(src)
        with zipfile.ZipFile(tmp) as z:
            names = z.namelist()
            missing_in = [d for _, d in items if d not in names]
        if missing_in:
            raise RuntimeError(f"verify failed, missing {missing_in}")
        if dest == aar:
            os.replace(tmp, aar)
        else:
            shutil.move(tmp, dest)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    print(f"OK: +{added} assets ({total / 1048576:.1f} MB), {skipped} already present -> {dest}")
    print(f"    AAR entries: {len(names)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
