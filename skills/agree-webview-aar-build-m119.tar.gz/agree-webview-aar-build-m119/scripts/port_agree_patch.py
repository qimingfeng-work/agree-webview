#!/usr/bin/env python3
"""
agree patch 跨版本移植工具

用途
----
agree 的 3 个 patch 是针对某一 Chromium 大版本（2.0.0 = M132）生成的。
换到别的版本（如 M119）时，`git apply` 会因 hunk 上下文不匹配而失败。
但实测这些 patch 的改动大部分是机械的包名替换：

    android.webkit.X  →  agree.webkit.X

因此可以用「按语义重做」代替「按上下文打补丁」：不复用 patch 的 hunk 上下文，
而是在目标版本的源文件上直接做替换。这样无论目标版本的文件结构差多少，
只要替换目标存在就能成功。

为什么必须先分类
----------------
不是所有失败文件都能机械重做。BUILD.gn / *.gni 的 target 标签与 deps
在大版本之间会变，必须手工对照目标版本的 GN 结构重写。
本工具对 .gn 文件只报告 MANUAL，不尝试修改。

核心约束：白名单
----------------
只替换 agree 真正提供的类（扫描它的 java/ 目录得出）。
盲目替换所有 android.webkit.* 会引用到不存在的类，编译必挂。

用法
----
    # 先看会改什么（不落盘）
    python3 port_agree_patch.py --chromium /path/to/chromium/src \\
        --agree /path/to/agree --dry-run

    # 实际执行（每个文件先备份为 <file>.pre-port）
    python3 port_agree_patch.py --chromium /path/to/chromium/src \\
        --agree /path/to/agree --apply

输出三类动作：
    REWRITE  已按语义重做包名替换（附替换处数）
    NOOP     文件存在但无需改动（patch 那块是空改）
    MANUAL   BUILD.gn 类，需人工处理
    SKIP     目标文件在目标版本中不存在

事后应配合 javac + 目标 API android.jar 全量扫描验证纯 Java 部分
（见 references/min-sdk-and-platform-support.md 方案 D）。
"""

import argparse
import os
import re
import shutil
import sys


def collect_agree_classes(agree_dir):
    """扫描 agree 仓库，返回它提供的 webkit 类名集合。

    包名目录因 agree 版本而异，这里从 java/src 下递归找
    最后一个名为 webkit 的包目录，避免硬编码 android_agree。
    """
    src_root = os.path.join(agree_dir, "java", "src")
    if not os.path.isdir(src_root):
        raise SystemExit(f"找不到 agree java 源码目录: {src_root}")

    candidates = []
    for root, dirs, files in os.walk(src_root):
        if os.path.basename(root) == "webkit":
            java_files = [f for f in files if f.endswith(".java")]
            if java_files:
                candidates.append((root, java_files))

    if not candidates:
        raise SystemExit(f"在 {src_root} 下没找到任何 webkit 包目录")

    # 取类最多的那个（agree 的 API 层），可能有多个同名目录
    root, java_files = max(candidates, key=lambda c: len(c[1]))
    classes = {f[:-5] for f in java_files}
    print(f"从 {root} 收集到 {len(classes)} 个类")
    return classes


def extract_patch_targets(patch_path):
    """从 patch 中提取每个被改文件的相对路径。

    返回有序的路径列表（保持 patch 内顺序，便于对照）。
    """
    targets = []
    seen = set()
    with open(patch_path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if line.startswith("diff --git"):
                m = re.search(r" b/(\S+)\s*$", line.rstrip())
                if m and m.group(1) not in seen:
                    seen.add(m.group(1))
                    targets.append(m.group(1))
    return targets


def build_import_map(agree_classes):
    """构造 旧全限定名 → 新全限定名 映射，按类名长度倒序。

    倒序保证 WebViewClient 先于 WebView 被替换，
    避免短名把长名的前缀吃掉。
    """
    return [
        (f"android.webkit.{cls}", f"agree.webkit.{cls}")
        for cls in sorted(agree_classes, key=len, reverse=True)
    ]


def rewrite_java(content, mapping):
    """对 Java 源码执行包名替换。

    只替换完整限定名并带词边界，避免 android.webkit.WebView
    误匹配 android.webkit.WebViewClient 之类。

    裸类型名（extends X / new X(...)）不处理 —— 由 import 语句覆盖，
    这与 agree 官方 patch 的做法一致。
    """
    hits = 0
    out = content
    for old, new in mapping:
        pattern = re.compile(re.escape(old) + r"\b")
        out, n = pattern.subn(new, out)
        hits += n
    return out, hits


def port(chromium_dir, agree_dir, patch_files, dry_run):
    classes = collect_agree_classes(agree_dir)
    mapping = build_import_map(classes)
    print(f"构造 {len(mapping)} 条替换规则\n")

    summary = []
    for patch_path in patch_files:
        patch_name = os.path.basename(patch_path)
        print(f"{'=' * 70}\n{patch_name}\n{'=' * 70}")

        for rel_path in extract_patch_targets(patch_path):
            abs_path = os.path.join(chromium_dir, rel_path)
            if not os.path.exists(abs_path):
                summary.append((patch_name, rel_path, "SKIP", "目标版本无此文件"))
                continue

            if rel_path.endswith((".gn", ".gni")):
                summary.append((patch_name, rel_path, "MANUAL", "GN 结构需手工对照"))
                continue

            with open(abs_path, encoding="utf-8", errors="replace") as fh:
                content = fh.read()

            new_content, hits = rewrite_java(content, mapping)
            if hits == 0:
                summary.append((patch_name, rel_path, "NOOP", "无 agree 类引用"))
                continue

            summary.append((patch_name, rel_path, "REWRITE", f"替换 {hits} 处"))
            if not dry_run:
                shutil.copy2(abs_path, abs_path + ".pre-port")
                with open(abs_path, "w", encoding="utf-8") as fh:
                    fh.write(new_content)

    print(f"\n{'=' * 70}\n汇总\n{'=' * 70}")
    counts = {}
    for _, _, action, _ in summary:
        counts[action] = counts.get(action, 0) + 1
    for action in ("REWRITE", "NOOP", "MANUAL", "SKIP"):
        if action in counts:
            print(f"  {action:8s}: {counts[action]}")

    print(f"\n{'文件':<66} {'动作':<8} 说明")
    for _, rel_path, action, detail in summary:
        short = rel_path if len(rel_path) <= 64 else "..." + rel_path[-61:]
        print(f"{short:<66} {action:<8} {detail}")

    manual = [s for s in summary if s[2] == "MANUAL"]
    if manual:
        print(f"\n需要人工处理的 GN 文件 {len(manual)} 个：")
        for _, rel_path, _, _ in manual:
            print(f"  {rel_path}")

    if dry_run:
        print("\n[dry-run] 未写入任何文件。加 --apply 实际执行。")


def main():
    ap = argparse.ArgumentParser(
        description="agree patch 跨版本语义移植",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__)
    ap.add_argument("--chromium", required=True, help="Chromium 源码树 src/ 路径")
    ap.add_argument("--agree", required=True, help="agree 仓库根路径")
    ap.add_argument("--dry-run", action="store_true", help="只报告不落盘")
    ap.add_argument("--apply", action="store_true", help="实际执行")
    args = ap.parse_args()

    if not args.dry_run and not args.apply:
        ap.error("必须指定 --dry-run 或 --apply 之一")

    patches_dir = os.path.join(args.agree, "patches")
    if not os.path.isdir(patches_dir):
        raise SystemExit(f"找不到 patches 目录: {patches_dir}")

    patch_files = sorted(
        os.path.join(patches_dir, f)
        for f in os.listdir(patches_dir) if f.endswith(".patch"))
    if not patch_files:
        raise SystemExit(f"{patches_dir} 下没有 .patch 文件")

    port(args.chromium, args.agree, patch_files, args.dry_run)


if __name__ == "__main__":
    main()
