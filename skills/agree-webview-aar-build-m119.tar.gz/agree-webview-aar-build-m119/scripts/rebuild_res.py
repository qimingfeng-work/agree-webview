#!/usr/bin/env python3
"""重组 48 个依赖资源 zip 为 AAR 标准 res/ 布局。

关键规则（复刻 dist_aar.py 的 _AddResources + 修正其问题）:
  1. values* 目录下的文件必须**全部保留**并加序号后缀（values_0.xml, values_1.xml...），
     因为 35+ 个库都提供 values.xml/values-v21.xml 等同名文件，直接覆盖会只剩最后一
     份 → appcompat 等库的资源残缺（style/Base.V21.Theme.AppCompat.Dialog not found）。
  2. 非 values 文件（layout/drawable/menu/anim...）按 overlay 语义去重：
     先放非 overlay，再放 overlay 覆盖同名。

用法:
  rebuild_res.py --out <build_out目录> --res-out <输出res目录>
"""
import argparse
import os
import shutil


def add_zip(out, zpath, zip_index, overlay_flag, overlay_prio):
    """把单个资源 zip 合并进 res 目录。zip_index 用于 values 序号后缀。"""
    import zipfile
    with zipfile.ZipFile(zpath) as z:
        for n in z.namelist():
            if n.endswith("/"):
                continue
            parts = n.split("/")
            # 去掉 N_ 前缀（0_res_webkit/ -> res_webkit/）
            if parts[0][:2] in [f"{i}_" for i in range(10)]:
                parts = parts[1:]
            # 目标路径 = res/ 下
            first = parts[0]
            is_values = first.startswith("values")
            if is_values:
                # values* 目录：文件名加序号后缀全保留（避免库间覆盖）
                if len(parts) >= 2:
                    fn = parts[-1]
                    root, ext = os.path.splitext(fn)
                    parts = parts[:-1] + [f"{root}_{zip_index}{ext}"]
            target = os.path.join(out, *parts)
            os.makedirs(os.path.dirname(target), exist_ok=True)
            if not is_values:
                # 非 values：overlay 覆盖。非 overlay 先放；overlay 后放覆盖。
                if not overlay_flag and os.path.exists(target):
                    # 已被 overlay 占位或已有？非 overlay 若已存在则跳过（避免互相覆盖）
                    # 这里逻辑：先全部非 overlay，再 overlay 覆盖
                    continue
            with z.open(n) as f, open(target, "wb") as fo:
                fo.write(f.read())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, help="build out 目录")
    ap.add_argument("--res-out", required=True, help="输出 res 目录")
    args = ap.parse_args()

    import json
    bc = json.load(open(os.path.join(
        args.out, "gen/android_webview/agree/webview_aar.build_config.json")))
    di = bc["deps_info"]
    zips = di["dependency_zips"]
    overlays = set(di["dependency_zip_overlays"])

    if os.path.exists(args.res_out):
        shutil.rmtree(args.res_out)
    os.makedirs(args.res_out)

    # 第一遍：所有非 overlay
    zi = 0
    for zp in zips:
        if zp in overlays:
            continue
        add_zip(args.res_out, os.path.join(args.out, zp), zi, False, 0)
        zi += 1
    # 第二遍：overlay 覆盖
    for zp in zips:
        if zp in overlays:
            add_zip(args.res_out, os.path.join(args.out, zp), zi, True, 1)
            zi += 1

    n = sum(len(fs) for _, _, fs in os.walk(args.res_out))
    print(f"OK: {args.res_out} 共 {n} 个文件")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
