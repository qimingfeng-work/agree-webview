#!/usr/bin/env python3
"""第 2 步：给 agree AAR 补全资源链路。

dist_aar 只拼 jar/assets，不跑 aapt2 link，导致:
  - R.txt 0 字节 / res/ 是带 0_ 前缀的无效布局
  - classes.jar 无 R 类（Java 代码里 getstatic 引用 R 字段会 NoClassDefFoundError）

本脚本做三件事（后处理，不改 gn/ninja 构建）:
  1. 把 link 出的真实 R.txt 替换进 AAR（唯一 ID）
  2. 把编译好的 R 类（org.chromium.*.R 等）合并进 classes.jar
  3. 把重组后的标准 res/ 目录写进 AAR（覆盖 dist_aar 的无效 res/）
  4. 复用 add_aar_assets.py 的逻辑补 assets（icudtl/pak/snapshot/locales）

用法:
  assemble_aar.py --aar <AAR路径> --out <build_out目录> \
      --r-txt <真实R.txt> --r-jar <R.jar> --res-dir <标准res目录>
"""
import argparse
import os
import shutil
import sys
import zipfile


def rebuild_aar(aar_path, out_path, r_txt_path, r_jar_path, res_dir):
    """复制原 AAR 全部条目，替换 R.txt、合并 R 类、替换 res/。"""
    tmp = out_path + ".tmp"
    with zipfile.ZipFile(aar_path, "r") as zin, \
         zipfile.ZipFile(tmp, "w", allowZip64=True) as zout:
        rjar = zipfile.ZipFile(r_jar_path)
        rjar_names = set(rjar.namelist())
        # 复制原条目，跳过旧的 R.txt 和 res/ 和 R 类
        for info in zin.infolist():
            name = info.filename
            if name == "R.txt":
                continue
            if name.startswith("res/") or name.startswith("classes.jar"):
                # classes.jar 特殊处理：合并 R 类
                if name == "classes.jar":
                    data = _merge_rjar(zin.read(name), rjar)
                    zi = zipfile.ZipInfo("classes.jar")
                    zi.compress_type = zipfile.ZIP_DEFLATED
                    zi.external_attr = 0o644 << 16
                    zout.writestr(zi, data)
                continue
            zout.writestr(info, zin.read(info.filename))
        # 新 R.txt
        with open(r_txt_path, "rb") as f:
            zi = zipfile.ZipInfo("R.txt")
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            zout.writestr(zi, f.read())
        # res/ 目录（标准布局）
        for root, _, files in os.walk(res_dir):
            for f in files:
                rel = os.path.relpath(os.path.join(root, f), res_dir)
                dst = os.path.join("res", rel)
                zi = zipfile.ZipInfo(dst)
                zi.compress_type = zipfile.ZIP_STORED
                zi.external_attr = 0o644 << 16
                with open(os.path.join(root, f), "rb") as fh:
                    zout.writestr(zi, fh.read())
    os.replace(tmp, out_path)


def _merge_rjar(classes_jar_data, rjar):
    """把 R 类合并进 classes.jar（跳过已存在的，R 类不应重复）。

    排除 manifest 本体包 org/chromium/android_agree/R* 的 R 类：
    AGP 集成 AAR 时会从 R.txt 为 library namespace 自动生成同包 R 类，
    classes.jar 里再带一份必然撞名（"already contains entry ... cannot overwrite"）。
    其他包（webkit 子包、android_webview、ui、content 等）AGP 不生成，必须保留。
    """
    from io import BytesIO
    excluded_prefix = "org/chromium/android_agree/R"
    buf = BytesIO()
    with zipfile.ZipFile(BytesIO(classes_jar_data), "r") as zc, \
         zipfile.ZipFile(buf, "w", allowZip64=True) as zout:
        existing = set()
        for info in zc.infolist():
            zout.writestr(info, zc.read(info.filename))
            existing.add(info.filename)
        added = 0
        skipped = 0
        for info in rjar.infolist():
            if info.filename.startswith(excluded_prefix) and \
               not info.filename.startswith("org/chromium/android_agree/webkit/"):
                skipped += 1
                continue
            if info.filename in existing:
                continue
            zout.writestr(info, rjar.read(info.filename))
            added += 1
    return buf.getvalue()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--aar", required=True)
    ap.add_argument("--r-txt", required=True)
    ap.add_argument("--r-jar", required=True)
    ap.add_argument("--res-dir", required=True)
    ap.add_argument("-o", "--output", default=None)
    args = ap.parse_args()

    aar_path = os.path.abspath(args.aar)
    out_path = os.path.abspath(args.output) if args.output else aar_path
    rebuild_aar(aar_path, out_path, args.r_txt, args.r_jar, args.res_dir)

    # 验证
    with zipfile.ZipFile(out_path) as z:
        names = z.namelist()
        rtxt = z.read("R.txt").decode()
        res = [n for n in names if n.startswith("res/")]
        import io
        zj = zipfile.ZipFile(io.BytesIO(z.read("classes.jar")))
        rclasses = [n for n in zj.namelist()
                    if n.endswith("R.class") or "/R$" in n]
        print(f"OK: {out_path}")
        print(f"  R.txt: {len(rtxt)} B, {len(rtxt.splitlines())} 行")
        print(f"  res/ 条目: {len(res)}")
        print(f"  classes.jar R 类: {len(rclasses)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
