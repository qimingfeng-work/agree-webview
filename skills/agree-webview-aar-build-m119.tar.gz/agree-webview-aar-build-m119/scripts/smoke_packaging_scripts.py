#!/usr/bin/env python3
"""冒烟测试 agree 打包脚本（不需要 Chromium 构建树）。

用途：导入/升级本技能后，或改动 scripts/ 后，验证打包链路的行为契约。
只覆盖不依赖真实 out 树的脚本：add_aar_assets.py / merge_aars.py。
assemble_aar.py / make_res_aars.py / rebuild_res.py / jks_dump_cert.py
需要真实构建产物（build_config.json 的 dependency_zips、aapt2、JKS），
只跑到 --help 层，不在此脚本覆盖范围内。

用法（工作目录任意，路径按本机 skill 目录调整）：
    python3 scripts/smoke_packaging_scripts.py --skill-dir ~/.hermes/skills/software-development/chromium-agree-aar-build

退出码 0 = 全部通过；非 0 = 有断言失败（输出会逐条列出）。
所有临时文件写在 <skill-dir>/.smoke/ 下，可重复运行。
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile

# ---------------------------------------------------------------- 断言小工具

_FAILURES: list[str] = []


def check(cond: bool, msg: str) -> None:
    """cond 为假则记一条失败，但不中断（最后统一退出）。"""
    if not cond:
        _FAILURES.append(msg)
        print(f"  [FAIL] {msg}")
    else:
        print(f"  [ok]   {msg}")


def run(cmd: list[str], cwd: str) -> subprocess.CompletedProcess:
    """跑一条命令并原样返回；不抛异常，由调用方判 returncode。"""
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)


# ------------------------------------------------------------ 合成夹具（fixture）

def make_fake_out(root: str, arm32: bool) -> str:
    """造一个最小 out 目录：gen/android_webview/ 的 pak 与快照 + locales + icudtl.dat。

    arm32=True 时额外写 args.gn 的 target_cpu="arm"，用来驱动快照改名分支。
    """
    out = os.path.join(root, "out32" if arm32 else "out64")
    gen_aw = os.path.join(out, "gen", "android_webview")
    locales = os.path.join(out, "android_webview", "locales")
    os.makedirs(gen_aw, exist_ok=True)
    os.makedirs(locales, exist_ok=True)
    files = {
        os.path.join(gen_aw, "resources.pak"): b"PAK",
        os.path.join(gen_aw, "chrome_100_percent.pak"): b"P100",
        os.path.join(gen_aw, "snapshot_blob_64.bin"): b"SNAP-ARM32" if arm32 else b"SNAP-ARM64",
        os.path.join(out, "v8_context_snapshot_64.bin"): b"CTX",
        os.path.join(out, "icudtl.dat"): b"ICU",
        os.path.join(locales, "en-US.pak"): b"L",
    }
    if arm32:
        files[os.path.join(locales, "zh-CN.pak")] = b"T"
        # 驱动 add_aar_assets.py 的 target_cpu 分支
        with open(os.path.join(out, "args.gn"), "w", encoding="utf-8") as fh:
            fh.write('target_cpu="arm"\n')
    for path, blob in files.items():
        with open(path, "wb") as fh:
            fh.write(blob)
    return out


def make_bare_aar(path: str, extra_entries: dict[str, bytes] | None = None) -> None:
    """造一个只有 AndroidManifest.xml + classes.jar 的最小 AAR。"""
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("AndroidManifest.xml", "<m/>")
        zf.writestr("classes.jar", "x")
        for name, blob in (extra_entries or {}).items():
            zf.writestr(name, blob)


def names(aar: str) -> list[str]:
    """列出 AAR 内全部条目名（排序后）。"""
    with zipfile.ZipFile(aar) as zf:
        return sorted(zf.namelist())


def entries(aar: str) -> dict[str, zipfile.ZipInfo]:
    """条目名 -> ZipInfo，用来读 compress_type。"""
    with zipfile.ZipFile(aar) as zf:
        return {info.filename: info for info in zf.infolist()}


# -------------------------------------------------------------------- 用例

def test_add_assets_arm64(scripts: str, work: str) -> None:
    """arm64：补 pak/icudtl/快照，locale 落 stored-locales/，全部 STORE 不压缩。"""
    out = make_fake_out(work, arm32=False)
    aar = os.path.join(work, "t64.aar")
    make_bare_aar(aar)
    res = run([sys.executable, os.path.join(scripts, "add_aar_assets.py"), "--aar", aar, "--out", out], scripts)
    check(res.returncode == 0, f"add_aar_assets(arm64) exit 0（stderr: {res.stderr.strip()[:200]}）")
    got = names(aar)
    for expect in (
        "assets/resources.pak",
        "assets/chrome_100_percent.pak",
        "assets/icudtl.dat",
        "assets/snapshot_blob_64.bin",
        "assets/v8_context_snapshot_64.bin",
        "assets/stored-locales/en-US.pak",
    ):
        check(expect in got, f"arm64 含 {expect}")
    infos = entries(aar)
    # mmap 加载要求 pak/bin 不被压缩：STORED(compress_type==0)
    for name in ("assets/resources.pak", "assets/snapshot_blob_64.bin", "assets/stored-locales/en-US.pak"):
        if name in infos:
            check(infos[name].compress_type == zipfile.ZIP_STORED, f"{name} 为 STORE（compress_type={infos[name].compress_type}）")


def test_add_assets_arm32(scripts: str, work: str) -> None:
    """arm32：按 args.gn 的 target_cpu=arm 改名 _64 -> _32，并清掉误加的 _64 条目。"""
    out = make_fake_out(work, arm32=True)
    aar = os.path.join(work, "t32.aar")
    # 预置一个误加的 _64 快照，验证脚本会删除它
    make_bare_aar(aar, {"assets/snapshot_blob_64.bin": b"OLDMISADDED", "R.txt": b""})
    res = run([sys.executable, os.path.join(scripts, "add_aar_assets.py"), "--aar", aar, "--out", out], scripts)
    check(res.returncode == 0, f"add_aar_assets(arm32) exit 0（stderr: {res.stderr.strip()[:200]}）")
    got = names(aar)
    check("assets/snapshot_blob_32.bin" in got, "arm32 快照改名为 assets/snapshot_blob_32.bin")
    check("assets/snapshot_blob_64.bin" not in got, "arm32 误加的 _64 快照条目被删除")
    check("assets/v8_context_snapshot_64.bin" not in got, "arm32 不需要 v8_context_snapshot")
    with zipfile.ZipFile(aar) as zf:
        check(zf.testzip() is None, "arm32 AAR zip 完整性 testzip()==None")


def test_merge_aars(scripts: str, work: str) -> None:
    """以 64 位 AAR 为基底合并 32 位 jni，得到 allabi。"""
    base64 = os.path.join(work, "base64.aar")
    arm32 = os.path.join(work, "arm32.aar")
    allabi = os.path.join(work, "allabi.aar")
    make_bare_aar(base64)
    make_bare_aar(arm32, {"jni/armeabi-v7a/libwebviewchromium.so": b"SO32"})
    res = run(
        [sys.executable, os.path.join(scripts, "merge_aars.py"), base64, arm32, allabi],
        scripts,
    )
    check(res.returncode == 0, f"merge_aars exit 0（stderr: {res.stderr.strip()[:200]}）")
    got = names(allabi)
    check("jni/armeabi-v7a/libwebviewchromium.so" in got, "allabi 含 32 位 jni")
    check("AndroidManifest.xml" in got, "allabi 保留基底条目")
    with zipfile.ZipFile(allabi) as zf:
        check(zf.testzip() is None, "allabi zip 完整性 testzip()==None")


def test_help_layer(scripts: str) -> None:
    """所有脚本的 CLI 契约：argparse 脚本 --help exit 0；位置参数脚本无参打印 usage。"""
    for script in ("add_aar_assets.py", "assemble_aar.py", "make_res_aars.py", "rebuild_res.py"):
        res = run([sys.executable, os.path.join(scripts, script), "--help"], scripts)
        check(res.returncode == 0, f"{script} --help exit 0")
    for script in ("merge_aars.py", "jks_dump_cert.py"):
        res = run([sys.executable, os.path.join(scripts, script)], scripts)
        usage = (res.stdout + res.stderr).strip().splitlines()
        check(
            res.returncode != 0 and usage and "usage" in usage[0].lower(),
            f"{script} 无参调用打印 usage 并非 0 退出（实测 exit {res.returncode}）",
        )


# ---------------------------------------------------------------------- main

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--skill-dir",
        default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        help="本技能根目录（默认取脚本上一级）",
    )
    ap.add_argument("--keep", action="store_true", help="保留 .smoke 临时目录便于排查")
    args = ap.parse_args()

    scripts = os.path.join(args.skill_dir, "scripts")
    if not os.path.isdir(scripts):
        print(f"找不到 scripts 目录: {scripts}", file=sys.stderr)
        return 2

    work = os.path.join(args.skill_dir, ".smoke")
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work, exist_ok=True)

    print("== CLI 契约层 ==")
    test_help_layer(scripts)
    print("\n== arm64 assets 打包 ==")
    test_add_assets_arm64(scripts, work)
    print("\n== arm32 快照改名 ==")
    test_add_assets_arm32(scripts, work)
    print("\n== allabi 合并 ==")
    test_merge_aars(scripts, work)

    if _FAILURES:
        print(f"\nFAILED（{len(_FAILURES)} 项）：")
        for item in _FAILURES:
            print(f"  - {item}")
        if not args.keep:
            shutil.rmtree(work, ignore_errors=True)
        else:
            print(f"临时目录保留在 {work}")
        return 1

    print("\n全部通过。注意：assemble_aar.py / make_res_aars.py / rebuild_res.py / jks_dump_cert.py 需要真实 Chromium out 树，本冒烟未覆盖。")
    if not args.keep:
        shutil.rmtree(work, ignore_errors=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
