#!/usr/bin/env python3
"""合并 64 位和 32 位 AAR：以 64 位为基底，补入 32 位的 jni/ 条目（armeabi-v7a）。"""
import sys
import zipfile


def main():
    if len(sys.argv) != 4:
        sys.stderr.write("usage: merge_aars.py <base64.aar> <arm32.aar> <out.aar>\n")
        return 1
    base, arm32, out = sys.argv[1:4]
    seen = set()
    added = []
    with zipfile.ZipFile(out, "w") as zout:
        with zipfile.ZipFile(base) as zb:
            for i in zb.infolist():
                zout.writestr(i, zb.read(i.filename))
                seen.add(i.filename)
        with zipfile.ZipFile(arm32) as za:
            for i in za.infolist():
                if i.filename.startswith("jni/"):
                    if i.filename in seen:
                        print("SKIP (dup): %s" % i.filename)
                        continue
                    zout.writestr(i, za.read(i.filename))
                    seen.add(i.filename)
                    added.append(i.filename)
    print("added %d jni entries:" % len(added))
    for a in sorted(added):
        print("  ", a)
    return 0


if __name__ == "__main__":
    sys.exit(main())
