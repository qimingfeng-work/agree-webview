#!/usr/bin/env python3
"""从 chromium 构建产物生成 agree 辅助资源 AAR（跟随原作者 5-AAR 拆包方案）。

作者方案（wuruxu/agree 2.0.0，实测可用）:
  主 AAR（agree.webkit）: classes.jar + jni + assets，R.txt 0 行、无 res/
  4 个辅助 AAR: 每个 = AndroidManifest.xml(package=对应包) + R.txt(该包资源清单) + res/(该包资源)
  AGP 集成时从各 AAR 的 R.txt 为对应 package 生成 R 类，最终 ID 由 App 打包时分配。

本脚本从 build out 目录的 dependency_res_zips 按模块归属拆分重组：
  ui                  -> obj/ui/*
  content             -> obj/content/*
  android_webview     -> obj/android_webview/*
  embedder_support    -> obj/components/embedder_support/*

用法:
  make_res_aars.py --out <build_out> --r-txt <全量真实R.txt> --dist <输出目录>
"""
import argparse
import json
import os
import re
import shutil
import zipfile


def classify(z):
    if z.startswith("obj/ui/"):
        return "ui"
    if z.startswith("obj/content/"):
        return "content"
    if z.startswith("obj/android_webview/"):
        return "android_webview"
    if z.startswith("obj/components/embedder_support/"):
        return "embedder_support"
    return None


# AAR 名 -> (manifest package, 分组, 作者参考 AAR 路径, 该模块 Java 源码目录（相对树根）)
TARGETS = {
    "agree-res-ui.aar": ("org.chromium.ui", "ui",
                     "/root/dist/agree-res-ui.aar", "ui/android/java/src"),
    "agree-res-content.aar": ("org.chromium.content", "content",
                          "/root/dist/agree-res-content.aar",
                          "content/public/android/java/src"),
    "agree-res-android_webview.aar":
        ("org.chromium.android_webview", "android_webview",
         "/root/dist/agree-res-android_webview.aar",
         "android_webview/java/src"),
    "agree-res-embedder_support.aar":
        ("org.chromium.components.embedder_support.delegate", "embedder_support",
         "/root/dist/agree-res-embedder_support.aar",
         "components/embedder_support/android/java/src"),
}

MANIFEST = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="{pkg}">
</manifest>
"""


def group_res_zips(out_dir):
    bc = json.load(open(os.path.join(
        out_dir, "gen/android_webview/agree/webview_aar.build_config.json")))
    zips = bc["deps_info"]["dependency_zips"]
    groups = {}
    for z in zips:
        g = classify(z)
        if g:
            groups.setdefault(g, []).append(z)
    return groups


def filter_rtxt(full_rtxt, res_names):
    """从全量 R.txt 筛出属于 res_names 的行（保持原 ID）。"""
    out = []
    for line in full_rtxt.splitlines():
        parts = line.split()
        if len(parts) >= 3 and parts[2] in res_names:
            out.append(line)
    return "\n".join(out) + ("\n" if out else "")


def mangle(name):
    """aapt2 会把资源名里的 '.'/'-' 转成 '_' 写进 R.txt（如 TextAppearance.X → TextAppearance_X）。"""
    return name.replace(".", "_").replace("-", "_")


def res_file_name(f):
    """文件名型资源名：去掉扩展名，再去掉 9-patch 的 '.9' 后缀（popup_bg.9.png → popup_bg）。"""
    base = os.path.splitext(f)[0]
    if base.endswith(".9"):
        base = base[:-2]
    return base


def collect_res_names(res_dir):
    """从重组后的 res 目录收集资源名。

    三类来源缺一不可：
      1. 文件名（layout/*.xml、drawable/*.xml、png）——文件型资源没有 name 属性；
         values* 目录下的文件名不是资源名（资源名在 name 属性里），跳过；
      2. xml 里的 name="..."（values 下的 string/array/attr/style/id 等）；
      3. 布局里的 @+id/xxx（布局内部定义的 id，只出现在 layout 的 view 属性里）。
    全部 mangle 成 R.txt 里的形式，否则筛选时匹配不上。
    """
    names = set()
    for root, _, files in os.walk(res_dir):
        parts = os.path.relpath(root, res_dir).split(os.sep)
        is_values = parts[0].startswith("values")
        for f in files:
            if not is_values:
                names.add(mangle(res_file_name(f)))
            if f.endswith(".xml"):
                with open(os.path.join(root, f), "rb") as fh:
                    data = fh.read()
                for m in re.finditer(rb'name="([^"]+)"', data):
                    n = m.group(1).decode()
                    if not n.startswith("android:"):
                        names.add(mangle(n))
                for m in re.finditer(rb'@\+id/([A-Za-z_0-9]+)', data):
                    names.add(m.group(1).decode())
    return names


def collect_java_r_refs(src_dir):
    """扫描模块 Java 源码里的 R.<type>.<name> 引用（排除 android.R./androidx.R. 等限定引用）。

    这些是运行期会用到的资源，必须保证对应 R 内部类存在，否则 ClassNotFoundException。
    """
    refs = set()
    if not os.path.isdir(src_dir):
        return refs
    for root, _, files in os.walk(src_dir):
        for f in files:
            if f.endswith(".java"):
                txt = open(os.path.join(root, f), encoding="utf-8", errors="replace").read()
                for m in re.finditer(r'(?<![\w.])R\.([a-z]+)\.([A-Za-z_0-9]+)', txt):
                    refs.add(m.group(2))
    return refs


def build_res_aar(out_path, pkg, res_dir, rtxt):
    with zipfile.ZipFile(out_path, "w", allowZip64=True) as z:
        zi = zipfile.ZipInfo("AndroidManifest.xml")
        zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16
        z.writestr(zi, MANIFEST.format(pkg=pkg))
        zi = zipfile.ZipInfo("R.txt")
        zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16
        z.writestr(zi, rtxt)
        zi = zipfile.ZipInfo("public.txt")
        zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16
        z.writestr(zi, "")
        for root, _, files in os.walk(res_dir):
            for f in files:
                full = os.path.join(root, f)
                rel = os.path.relpath(full, res_dir)
                dst = os.path.join("res", rel)
                zi = zipfile.ZipInfo(dst)
                zi.compress_type = zipfile.ZIP_STORED
                zi.external_attr = 0o644 << 16
                with open(full, "rb") as fh:
                    z.writestr(zi, fh.read())


def author_resource_names(aar_path, res_dir):
    """从作者参考 AAR 的 R.txt 提取该包资源名（权威清单）。

    作者 AAR 不在本机时（换机器/重建），退回用重组后 res 目录里的资源名
    （collect_res_names）——同一批 dependency_res_zips 拆出来的，名称一致。"""
    if os.path.isfile(aar_path):
        with zipfile.ZipFile(aar_path) as z:
            rtxt = z.read("R.txt").decode().splitlines()
        names = set()
        for l in rtxt:
            parts = l.split()
            if len(parts) >= 3 and parts[0] in ("int", "int[]"):
                names.add(parts[2])
        return names
    print(f"[WARN] 作者参考 AAR 不存在: {aar_path}，改用 res 目录资源名")
    return collect_res_names(res_dir)


def build_resource_index(out_dir, groups):
    """所有 dependency zip 里的资源名 -> (zip 相对路径, entry 路径)。

    用于把「被本模块 Java 代码引用、但资源定义在别的模块」的资源复制进来
    （如 content 的 AndroidFontLookupImpl 引用 ui 模块的 gms_fonts_certs array）。
    """
    index = {}
    for grp, zips in groups.items():
        for zp in zips:
            with zipfile.ZipFile(os.path.join(out_dir, zp)) as z:
                for n in z.namelist():
                    if n.endswith("/"):
                        continue
                    parts = n.split("/")
                    if parts[0][:2] in [f"{i}_" for i in range(10)]:
                        parts = parts[1:]
                    is_values = parts[0].startswith("values")
                    if not is_values:
                        index.setdefault(mangle(res_file_name(parts[-1])), (zp, n))
                    if parts[-1].endswith(".xml"):
                        try:
                            data = z.read(n)
                        except Exception:
                            continue
                        for m in re.finditer(rb'name="([^"]+)"', data):
                            name = m.group(1).decode()
                            if not name.startswith("android:"):
                                index.setdefault(mangle(name), (zp, n))
                        for m in re.finditer(rb'@\+id/([A-Za-z_0-9]+)', data):
                            index.setdefault(m.group(1).decode(), (zp, n))
    return index


def copy_resource(out_dir, index, name, res_dir):
    zp, entry = index[name]
    with zipfile.ZipFile(os.path.join(out_dir, zp)) as z:
        data = z.read(entry)
    parts = entry.split("/")
    if parts[0][:2] in [f"{i}_" for i in range(10)]:
        parts = parts[1:]
    target = os.path.join(res_dir, *parts)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "wb") as f:
        f.write(data)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, help="build out 目录")
    ap.add_argument("--r-txt", required=True, help="全量真实 R.txt（link 产物）")
    ap.add_argument("--dist", required=True, help="输出目录")
    args = ap.parse_args()

    full_rtxt = open(args.r_txt).read()
    full_lines = {}
    for l in full_rtxt.splitlines():
        parts = l.split()
        if len(parts) >= 3 and parts[0] in ("int", "int[]"):
            full_lines[parts[2]] = l
    groups = group_res_zips(args.out)
    index = build_resource_index(args.out, groups)
    src_root = os.path.abspath(os.path.join(args.out, "../.."))
    os.makedirs(args.dist, exist_ok=True)

    for aar_name, (pkg, grp, author_aar, src_dir) in TARGETS.items():
        res_dir = os.path.join(args.dist, f"_res_{grp}")
        if os.path.exists(res_dir):
            shutil.rmtree(res_dir)
        os.makedirs(res_dir)
        # 重组该组资源 zip（values 加序号后缀全保留，非 values overlay 去重）
        zi_counter = 0
        for zp in groups.get(grp, []):
            with zipfile.ZipFile(os.path.join(args.out, zp)) as z:
                for n in z.namelist():
                    if n.endswith("/"):
                        continue
                    parts = n.split("/")
                    if parts[0][:2] in [f"{i}_" for i in range(10)]:
                        parts = parts[1:]
                    is_values = parts[0].startswith("values")
                    target = os.path.join(res_dir, *parts)
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    if is_values and len(parts) >= 2:
                        fn = parts[-1]
                        root2, ext = os.path.splitext(fn)
                        parts = parts[:-1] + [f"{root2}_{zi_counter}{ext}"]
                        target = os.path.join(res_dir, *parts)
                    if not is_values and os.path.exists(target):
                        continue
                    with z.open(n) as f, open(target, "wb") as fo:
                        fo.write(f.read())
            zi_counter += 1
        # 资源名 = res 目录里的 + 作者参考清单 + 本模块 Java 代码引用
        res_names = collect_res_names(res_dir)
        names = set(res_names)
        names |= author_resource_names(author_aar, res_dir)
        java_refs = collect_java_r_refs(os.path.join(src_root, src_dir))
        copied = []
        for n in sorted(java_refs):
            # 只看 res/ 实际有没有该文件——作者清单可能残留上次输出的名字，
            # 而 res/ 是每次重建的，不能作为"已存在"的依据
            if n not in res_names and n in index:
                copy_resource(args.out, index, n, res_dir)
                copied.append(n)
        if copied:
            names |= set(copied)
            print(f"[INFO] {aar_name}: 跨模块补齐 {len(copied)} 个资源: {copied[:10]}")
        rtxt_lines = [full_lines[n] for n in sorted(names) if n in full_lines]
        missing = sorted(names - set(full_lines))
        if missing:
            print(f"[WARN] {aar_name}: {len(missing)} 个资源不在全量 R.txt: {missing[:10]}")
        rtxt = "\n".join(rtxt_lines) + ("\n" if rtxt_lines else "")
        out_path = os.path.join(args.dist, aar_name)
        build_res_aar(out_path, pkg, res_dir, rtxt)
        n_res = sum(len(fs) for _, _, fs in os.walk(res_dir))
        print(f"OK: {aar_name}  package={pkg}  res={n_res}  R.txt={len(rtxt.splitlines())} 行")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
